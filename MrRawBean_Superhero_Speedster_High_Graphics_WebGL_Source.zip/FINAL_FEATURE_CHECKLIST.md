# MrRawBean Superhero Speedster — Final Feature Checklist

This source package implements the requested offline runner feature set:

- Home screen with the hero profile, main navigation buttons, map selection, records, shop, missions, settings, name change, Start Play and offline-install controls.
- Nine separate maps in Map Selection, each with its own local thumbnail, biome, lighting, track styling and environment.
- Supplied MrRawBean portrait used for the game/PWA launcher icon and home hero artwork.
- Procedural 3D MrRawBean superhero body with articulated run, jump, slide, stumble, damage, idle, flight, landing, rescue and game-over animation states.
- Animated flying carpet visible during the home/idle scene.
- Golden glowing heart: flight/flying power-up.
- Red heart with golden glow ring: +1 life, capped by the configured maximum.
- Green glowing heart: 2× speed power-up.
- Grey obstacle: stumble only; it does not remove a life.
- Reddish-black obstacle: removes a life.
- Cars, motorcycles/bikes and trucks travel toward the runner as opposing traffic.
- Civilian rescue encounters; successful rescue queues the bundled gentle male “thank you” voice.
- Every 2,000 metres queues the bundled loud male superhero checkpoint voice: “Yahooo, I am MisterRawBean,The SUPERHERO”.
- Local synthesized SFX only; no background music player or soundtrack.
- High-graphics 3D rendering with nine biome-specific road albedo textures, nine normal maps, five ground textures, a roughness detail map, anisotropic filtering, reflective lane inlays, richer roadside scenery, and soft shadows up to 2048 × 2048. All 24 files are local/offline-cached.
- Three-lane endless-runner controls with keyboard/touch/swipe support.
- PWA service worker precaches the app shell, all nine map images, icons and local voice clips for offline play after the first successful load.
- Capacitor configuration is included for a native Android APK build from the same `dist/` output.
- Netlify is configured to build with `npm run build` and publish `dist/`.

## Verification in this authoring environment

The source contract tests pass (42/42), including new checks for all 24 high-graphics textures and offline cache references. A production Vite build, Android Gradle build and physical-device test require npm registry access plus Android SDK/Gradle tooling and therefore are not claimed as completed here.
