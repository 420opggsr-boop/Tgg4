import { readdir, readFile, writeFile } from 'node:fs/promises';
import { resolve, relative, sep } from 'node:path';
import { defineConfig, type Plugin } from 'vite';

/** Inject built local JS/CSS bundles into the app-shell cache before publishing dist/. */
function offlinePrecachePlugin(): Plugin {
  return {
    name: 'mrrawbean-offline-precache',
    apply: 'build',
    async closeBundle() {
      const outDir = resolve(process.cwd(), 'dist');
      const assetDir = resolve(outDir, 'assets');
      const serviceWorkerPath = resolve(outDir, 'service-worker.js');
      const files: string[] = [];
      const walk = async (directory: string): Promise<void> => {
        let entries;
        try { entries = await readdir(directory, { withFileTypes: true }); }
        catch (error) {
          if ((error as NodeJS.ErrnoException).code === 'ENOENT') return;
          throw error;
        }
        for (const entry of entries) {
          const fullPath = resolve(directory, entry.name);
          if (entry.isDirectory()) await walk(fullPath);
          else if (/\.(?:js|css|woff2?|wasm|json)$/i.test(entry.name)) {
            const localPath = relative(outDir, fullPath).split(sep).join('/');
            files.push(`./${localPath}`);
          }
        }
      };
      await walk(assetDir);
      const serviceWorker = await readFile(serviceWorkerPath, 'utf8');
      const marker = 'const BUILD_ASSET_PATHS = [];';
      if (!serviceWorker.includes(marker)) {
        throw new Error('Offline precache marker is missing from public/service-worker.js.');
      }
      await writeFile(serviceWorkerPath, serviceWorker.replace(marker, `const BUILD_ASSET_PATHS = ${JSON.stringify(files.sort())};`));
    },
  };
}

export default defineConfig({
  base: './',
  publicDir: 'public',
  plugins: [offlinePrecachePlugin()],
  build: {
    outDir: 'dist',
    sourcemap: true,
    assetsInlineLimit: 4096,
    target: 'es2022',
    rollupOptions: {
      output: {
        manualChunks: {
          three: ['three'],
        },
      },
    },
  },
  server: { host: '0.0.0.0' },
  preview: { host: '0.0.0.0' },
});
