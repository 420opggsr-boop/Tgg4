import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.mrrawbean.speedster',
  appName: 'MrRawBean Superhero Speedster',
  webDir: 'dist',
  backgroundColor: '#06132e',
  android: {
    allowMixedContent: false,
  },
};

export default config;
