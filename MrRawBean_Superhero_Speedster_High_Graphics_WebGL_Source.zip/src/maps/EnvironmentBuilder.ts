import * as THREE from 'three';
import type { MapDefinition } from './MapRegistry';

export interface BuiltEnvironment {
  root: THREE.Group;
  trackSegments: THREE.Group[];
  segmentLength: number;
  landmark: THREE.Group;
}

const SEGMENT_LENGTH = 34;

// High-resolution local surface pack. Every map and normal map is stored with the
// app, so these materials also work after the PWA has been cached for offline play.
function loadSurfaceTexture(file: string, repeatX: number, repeatY: number, colorMap = true): THREE.Texture {
  const texture = new THREE.TextureLoader().load(new URL(`./textures/${file}`, document.baseURI).href);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(repeatX, repeatY);
  texture.anisotropy = 8;
  texture.colorSpace = colorMap ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  texture.generateMipmaps = true;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
  return texture;
}

function groundTextureFor(map: MapDefinition): string {
  if (map.biome === 'tropical' || map.biome === 'emerald') return 'ground-lush.jpg';
  if (map.biome === 'ice') return 'ground-ice.jpg';
  if (map.biome === 'desert') return 'ground-sand.jpg';
  if (map.biome === 'inferno') return 'ground-rock.jpg';
  return 'ground-dark.jpg';
}

export function disposeObjectTree(root: THREE.Object3D): void {
  const geometries = new Set<THREE.BufferGeometry>();
  const materials = new Set<THREE.Material>();
  const textures = new Set<THREE.Texture>();
  root.traverse((node) => {
    const mesh = node as THREE.Mesh;
    if (!mesh.isMesh) return;
    if (mesh.geometry) geometries.add(mesh.geometry);
    const assignedMaterials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    for (const material of assignedMaterials) materials.add(material);
  });
  for (const material of materials) {
    const fields = material as unknown as Record<string, unknown>;
    for (const key of ['map', 'normalMap', 'roughnessMap', 'bumpMap', 'metalnessMap', 'aoMap', 'emissiveMap', 'alphaMap', 'envMap']) {
      const texture = fields[key] as THREE.Texture | undefined;
      if (texture && texture.isTexture) textures.add(texture);
    }
    material.dispose();
  }
  geometries.forEach((geometry) => geometry.dispose());
  // Release per-map GPU textures as the player changes worlds instead of retaining
  // every map's full-resolution materials indefinitely on mobile devices.
  textures.forEach((texture) => texture.dispose());
}

export function buildEnvironment(map: MapDefinition, quality: 'low' | 'medium' | 'high', shadowsEnabled: boolean, effectsEnabled = true): BuiltEnvironment {
  const root = new THREE.Group(); root.name = `Environment-${map.id}`;
  const landmark = new THREE.Group(); landmark.name = `Landmark-${map.id}`; root.add(landmark);
  const segments: THREE.Group[] = [];
  const low = quality === 'low';
  const high = quality === 'high';
  const detail = low ? 0.55 : high ? 1.55 : 1;

  const material = (color: string, emissive = '#000000', metalness = 0.15, roughness = 0.62) => new THREE.MeshStandardMaterial({ color, emissive, emissiveIntensity: emissive === '#000000' ? 0 : 0.65, metalness, roughness });
  const roadMat = material(map.road, map.biome === 'neon' || map.biome === 'moonlight' ? map.accent : '#000000', map.biome === 'ice' ? 0.58 : 0.45, map.biome === 'ice' || map.biome === 'neon' || map.biome === 'moonlight' ? 0.26 : 0.48);
  roadMat.map = loadSurfaceTexture(`road-${map.biome}.jpg`, 1.35, 5.2);
  roadMat.normalMap = loadSurfaceTexture(`normal-${map.biome}.jpg`, 1.35, 5.2, false);
  roadMat.roughnessMap = loadSurfaceTexture('surface-detail.jpg', 1.35, 5.2, false);
  roadMat.normalScale.set(high ? 0.72 : low ? 0.25 : 0.46, high ? 0.72 : low ? 0.25 : 0.46);
  roadMat.needsUpdate = true;
  const edgeMat = material(map.accent, map.accent, 0.5, 0.25);
  const accent2Mat = material(map.accent2, map.accent2, 0.45, 0.3);
  const groundMat = material(map.ground, '#000000', 0.04, 0.93);
  groundMat.map = loadSurfaceTexture(groundTextureFor(map), 36, 36);
  groundMat.needsUpdate = true;
  const shoulderMat = material(map.ground, '#000000', 0.04, 0.9);
  const wallMat = material(map.biome === 'ice' ? '#bde9ff' : map.biome === 'desert' ? '#b76e3a' : map.biome === 'tropical' ? '#51705f' : map.biome === 'inferno' ? '#2b2029' : '#162653', map.biome === 'inferno' ? '#59120b' : '#000000', 0.15, 0.75);
  const darkMat = material('#101c34', map.biome === 'neon' ? '#062c9a' : '#000000', 0.6, 0.35);
  const glassMat = new THREE.MeshStandardMaterial({ color: map.accent, emissive: map.accent, emissiveIntensity: high ? 0.5 : 0.3, transparent: true, opacity: 0.78, metalness: 0.4, roughness: 0.22 });
  const reflectiveStripMat = new THREE.MeshStandardMaterial({ color: '#dffaff', emissive: map.accent, emissiveIntensity: high ? 0.42 : 0.2, metalness: 0.65, roughness: 0.25 });

  const addMesh = (geom: THREE.BufferGeometry, mat: THREE.Material, parent: THREE.Object3D, pos: [number, number, number], scale?: [number, number, number], rot?: [number, number, number]) => {
    const mesh = new THREE.Mesh(geom, mat); mesh.position.set(...pos); if (scale) mesh.scale.set(...scale); if (rot) mesh.rotation.set(...rot);
    mesh.castShadow = shadowsEnabled && !low; mesh.receiveShadow = shadowsEnabled && !low; parent.add(mesh); return mesh;
  };
  const addBox = (parent: THREE.Object3D, pos: [number, number, number], size: [number, number, number], mat: THREE.Material, rot?: [number, number, number]) => addMesh(new THREE.BoxGeometry(...size), mat, parent, pos, undefined, rot);

  // A horizon plate keeps the ground continuous beyond the reusable road segments.
  addMesh(new THREE.PlaneGeometry(1500, 1500, high ? 24 : 1, high ? 24 : 1), groundMat, root, [0, -0.14, -180], [1, 1, 1], [-Math.PI / 2, 0, 0]);
  const hemisphere = new THREE.HemisphereLight(map.sky, map.ground, map.ambient); root.add(hemisphere);
  const sun = new THREE.DirectionalLight('#ffffff', map.sun); sun.position.set(-12, 28, 13); sun.castShadow = shadowsEnabled && quality !== 'low';
  sun.shadow.mapSize.set(quality === 'high' ? 2048 : 1024, quality === 'high' ? 2048 : 1024);
  sun.shadow.bias = -0.00018;
  sun.shadow.normalBias = 0.025;
  sun.shadow.radius = quality === 'high' ? 4 : 2;
  sun.shadow.camera.left = -12; sun.shadow.camera.right = 12; sun.shadow.camera.top = 18; sun.shadow.camera.bottom = -12; sun.shadow.camera.updateProjectionMatrix();
  root.add(sun);

  function addNeonTower(parent: THREE.Object3D, x: number, z: number, height: number, accent: THREE.Material, width = 3) {
    addBox(parent, [x, height / 2, z], [width, height, width], darkMat);
    const stripCount = low ? 2 : high ? 7 : 4;
    for (let s = 0; s < stripCount; s += 1) {
      const y = 0.55 + ((height - 1) * s) / stripCount;
      addBox(parent, [x - width * 0.34, y, z + width * 0.505], [0.06, 0.16, 0.04], accent);
      addBox(parent, [x + width * 0.34, y + 0.12, z + width * 0.505], [0.06, 0.11, 0.04], accent2Mat);
    }
    addBox(parent, [x, height + 0.12, z], [width * 0.4, 0.24, width * 0.4], accent);
  }

  function addPalm(parent: THREE.Object3D, x: number, z: number, size = 1) {
    addMesh(new THREE.CylinderGeometry(0.11 * size, 0.18 * size, 3.8 * size, 7), material('#6c563f'), parent, [x, 1.9 * size, z], undefined, [0.04, 0, -0.11]);
    for (let i = 0; i < (low ? 4 : high ? 10 : 7); i += 1) {
      const leaf = addMesh(new THREE.ConeGeometry(0.18 * size, 2.1 * size, 5), material('#258d79'), parent, [x + Math.cos(i * 0.92) * 0.85 * size, 3.55 * size, z + Math.sin(i * 0.92) * 0.85 * size], [0.65, 1, 1], [0, 0, Math.cos(i * 0.92) * 0.9]);
      leaf.rotation.x = Math.sin(i * 0.92) * 0.65;
    }
  }

  function addIceSpire(parent: THREE.Object3D, x: number, z: number, h: number) {
    addMesh(new THREE.ConeGeometry(0.95 + h * 0.03, h, low ? 4 : high ? 10 : 6), material('#8bd8ff', '#2c8cff', 0.35, 0.18), parent, [x, h / 2, z], undefined, [0.05, z * 0.08, -0.07]);
    addMesh(new THREE.ConeGeometry(0.38, h * 0.58, 5), glassMat, parent, [x + 0.08, h * 0.6, z + 0.06], undefined, [0, 0.18, 0.08]);
  }

  function addFloatingIsland(parent: THREE.Object3D, x: number, z: number) {
    addMesh(new THREE.DodecahedronGeometry(2.2, 0), material('#176b69'), parent, [x, 3.2, z], [1.35, 0.45, 1]);
    addMesh(new THREE.ConeGeometry(1.6, 3.5, 6), material('#285a49'), parent, [x, 1.6, z], [1, 1, 0.9], [0, 0.3, 0]);
    addMesh(new THREE.CylinderGeometry(0.12, 0.55, 2.2, 6), material('#5eeed8', '#24b8b2'), parent, [x + 1.05, -0.3, z + 0.35], [0.5, 1, 0.5]);
    addMesh(new THREE.SphereGeometry(0.28, 8, 6), material('#49ffb6', '#00bb99'), parent, [x, 4, z]);
  }

  function buildSegment(index: number): THREE.Group {
    const seg = new THREE.Group(); seg.name = `TrackSegment-${index}`;
    // Road deck and raised side platforms.
    addMesh(new THREE.PlaneGeometry(8.6, SEGMENT_LENGTH), roadMat, seg, [0, -0.02, 0], undefined, [-Math.PI / 2, 0, 0]);
    addMesh(new THREE.BoxGeometry(0.26, 0.18, SEGMENT_LENGTH), edgeMat, seg, [-4.32, 0.02, 0]);
    addMesh(new THREE.BoxGeometry(0.26, 0.18, SEGMENT_LENGTH), edgeMat, seg, [4.32, 0.02, 0]);
    addMesh(new THREE.BoxGeometry(2.0, 0.12, SEGMENT_LENGTH), shoulderMat, seg, [-5.55, -0.11, 0]);
    addMesh(new THREE.BoxGeometry(2.0, 0.12, SEGMENT_LENGTH), shoulderMat, seg, [5.55, -0.11, 0]);
    // Lane markings are actual road geometry rather than flat UI art.
    for (const x of [-1.1, 1.1]) {
      for (let z = -SEGMENT_LENGTH / 2 + 2; z < SEGMENT_LENGTH / 2; z += high ? 4.6 : 5.2) {
        addMesh(new THREE.BoxGeometry(high ? 0.055 : 0.045, 0.018, high ? 2.35 : 2.15), edgeMat, seg, [x, 0.012, z]);
        if (high) addMesh(new THREE.BoxGeometry(0.018, 0.012, 2.0), reflectiveStripMat, seg, [x + 0.055, 0.016, z]);
      }
    }
    for (const x of [-4.45, 4.45]) {
      for (let z = -SEGMENT_LENGTH / 2 + 1; z < SEGMENT_LENGTH / 2; z += 3.8) {
        addMesh(new THREE.BoxGeometry(0.07, 0.12, 0.08), accent2Mat, seg, [x, 0.1, z]);
      }
    }

    const sideZ = high ? [-15, -8, 0, 8, 15] : [-12, 1, 13];
  const detailBoltCount = Math.max(1, Math.round(detail * 2));
    for (let i = 0; i < sideZ.length; i += 1) {
      const z = sideZ[i] + (index % 2) * 2;
      const h1 = 7 + ((index * 13 + i * 7) % 9);
      if (map.landmark === 'towers' || map.landmark === 'green-towers') {
        addNeonTower(seg, -7.2 - (i % 2) * 1.2, z, h1, edgeMat, 2.6 + (i % 2) * 0.8);
        addNeonTower(seg, 7.2 + (i % 2) * 1.1, z - 3, h1 + 3, accent2Mat, 3.0);
      } else if (map.landmark === 'palms') {
        addPalm(seg, -6.5 - (i % 2), z, 0.72 + (i % 2) * 0.14);
        addPalm(seg, 6.5 + (i % 2), z - 4, 0.82);
        addMesh(new THREE.SphereGeometry(1.0, 8, 6), material('#53bd9a'), seg, [i % 2 ? -8 : 8, 0.45, z + 1], [1.7, 0.5, 1.2]);
      } else if (map.landmark === 'icecastle') {
        addIceSpire(seg, -7.0 - (i % 2), z, 5 + i * 2);
        addIceSpire(seg, 7.0 + (i % 2), z - 3, 8 + i * 1.5);
        addMesh(new THREE.BoxGeometry(3, 1.4, 2), material('#a3defb'), seg, [-8, 0.6, z + 3]);
      } else if (map.landmark === 'islands') {
        addFloatingIsland(seg, -8.1, z);
        addFloatingIsland(seg, 8.1, z - 5);
        for (let k = 0; k < 3; k += 1) addMesh(new THREE.ConeGeometry(0.52, 1.7, 5), material('#24a66b'), seg, [Math.cos(k * 2.1) * 0.9 - 8.1, 4.15, z + Math.sin(k * 2.1) * 0.9]);
      } else if (map.landmark === 'volcano') {
        addMesh(new THREE.DodecahedronGeometry(3.5, 0), wallMat, seg, [-8, 1, z], [1.2, 1, 0.85]);
        addMesh(new THREE.ConeGeometry(2.6, 4.7, 5), material('#301520', '#8d180c'), seg, [8, 2, z - 2], [1, 1, 0.9], [0, 0.3, 0]);
        for (let k = 0; k < 3; k += 1) addMesh(new THREE.BoxGeometry(0.15, 0.035, 1.6), material('#ff5e23', '#ff3010'), seg, [-7 - k * 0.34, 0.55, z + k]);
      } else if (map.landmark === 'portal') {
        addNeonTower(seg, -7.4, z, h1 + 1, edgeMat, 3.1);
        addNeonTower(seg, 7.4, z - 1, h1 + 4, accent2Mat, 3.3);
        addMesh(new THREE.TorusGeometry(1.3, 0.12, 8, 24), edgeMat, seg, [i % 2 ? 8.8 : -8.8, 5.4, z], [1, 1.35, 0.45], [0, 0.15, 0]);
      } else if (map.landmark === 'canyon') {
        addMesh(new THREE.BoxGeometry(4.4, 8 + i, 5), material('#a96336'), seg, [-7.5, 3 + i * 0.4, z], undefined, [0.02, 0.18, -0.04]);
        addMesh(new THREE.BoxGeometry(4.4, 7 + i, 5), material('#c17d3e'), seg, [7.5, 2.7 + i * 0.35, z - 3], undefined, [-0.02, -0.18, 0.05]);
        addMesh(new THREE.ConeGeometry(1.3, 2.2, 5), material('#e3a55f'), seg, [-6.8, 1.4, z + 2], undefined, [0, 0.2, -0.08]);
      } else if (map.landmark === 'planet') {
        addNeonTower(seg, -7.1, z, h1 + 5, edgeMat, 2.6);
        addNeonTower(seg, 7.1, z - 3, h1 + 1, accent2Mat, 2.8);
        addMesh(new THREE.TorusGeometry(1.2, 0.06, 6, 16), edgeMat, seg, [i % 2 ? 8.3 : -8.3, 6.5, z], [1.4, 0.45, 1], [0.45, 0, 0.4]);
      }
      // Small environment-specific light markers keep the sides readable.
      if (!low && map.biome !== 'tropical' && map.biome !== 'desert') {
        addMesh(new THREE.SphereGeometry(0.11, high ? 12 : 7, high ? 8 : 5), glassMat, seg, [-4.9, 0.6, z + 3]);
        addMesh(new THREE.SphereGeometry(0.11, high ? 12 : 7, high ? 8 : 5), glassMat, seg, [4.9, 0.6, z - 2]);
        for (let bolt = 1; bolt < detailBoltCount; bolt += 1) {
          const boltZ = z - 1.4 + bolt * 0.8;
          addMesh(new THREE.SphereGeometry(0.045, high ? 8 : 5, high ? 6 : 4), reflectiveStripMat, seg, [-4.5, 0.16, boltZ]);
          addMesh(new THREE.SphereGeometry(0.045, high ? 8 : 5, high ? 6 : 4), reflectiveStripMat, seg, [4.5, 0.16, boltZ]);
        }
      }
    }
    return seg;
  }

  for (let i = 0; i < 9; i += 1) {
    const segment = buildSegment(i);
    segment.position.z = (i - 4) * SEGMENT_LENGTH;
    segments.push(segment); root.add(segment);
  }

  // One map-defining distant landmark per environment. These remain behind the gameplay props.
  if (map.landmark === 'portal') {
    addMesh(new THREE.TorusGeometry(11, 0.72, low ? 8 : 14, low ? 48 : 96), edgeMat, landmark, [0, 13, -90], [1, 1.12, 0.24], [0.06, 0, 0]);
    addMesh(new THREE.TorusGeometry(9.5, 0.18, 6, 72), accent2Mat, landmark, [0, 13, -90.5], [1, 1.12, 0.24]);
    addMesh(new THREE.CircleGeometry(8.9, 48), material('#180b52', '#4216a5', 0.4, 0.18), landmark, [0, 13, -91], [1, 1.18, 0.2]);
  } else if (map.landmark === 'planet') {
    addMesh(new THREE.SphereGeometry(18, low ? 16 : 32, low ? 12 : 24), material('#1642ac', '#1738d8', 0.45, 0.28), landmark, [14, 21, -118]);
    addMesh(new THREE.SphereGeometry(18.6, low ? 14 : 28, low ? 10 : 20), new THREE.MeshBasicMaterial({ color: '#27bfff', transparent: true, opacity: 0.12, side: THREE.BackSide }), landmark, [14, 21, -118]);
    addMesh(new THREE.TorusGeometry(22, 0.18, 8, 64), accent2Mat, landmark, [14, 21, -118], [1.2, 0.48, 1], [0.22, 0.2, 0.15]);
    for (let i = 0; i < 7; i += 1) addMesh(new THREE.SphereGeometry(0.23 + (i % 2) * 0.1, 8, 6), edgeMat, landmark, [Math.sin(i * 2.2) * 25, 8 + (i % 3) * 4, -92 - i * 6]);
  } else if (map.landmark === 'volcano') {
    addMesh(new THREE.ConeGeometry(19, 28, 7), material('#220c15', '#430e09'), landmark, [-18, 12, -105]);
    addMesh(new THREE.TorusGeometry(4.8, 0.26, 8, 28), material('#ff421a', '#ff2400'), landmark, [-18, 24, -104], [1, 0.24, 1]);
  } else if (map.landmark === 'icecastle') {
    addMesh(new THREE.BoxGeometry(18, 15, 7), material('#a9dfff', '#1d8aff', 0.3, 0.2), landmark, [4, 7, -100]);
    for (let i = 0; i < 6; i += 1) addMesh(new THREE.ConeGeometry(1.8 + (i % 2) * 0.6, 10 + (i % 3) * 2, 5), glassMat, landmark, [-4 + i * 3.2, 14, -100 - (i % 2) * 4]);
  } else if (map.landmark === 'islands') {
    addFloatingIsland(landmark, -13, -90); addFloatingIsland(landmark, 13, -104); addFloatingIsland(landmark, 0, -122);
  } else if (map.landmark === 'palms') {
    addMesh(new THREE.SphereGeometry(8, 20, 14), material('#ffbf62', '#ff9b3c', 0.1, 0.35), landmark, [-12, 17, -128]);
    for (let i = 0; i < 6; i += 1) addPalm(landmark, -25 + i * 9, -100 - (i % 3) * 8, 1.3);
  } else if (map.landmark === 'canyon') {
    addMesh(new THREE.CylinderGeometry(5, 8, 28, 5), material('#ae6337'), landmark, [-18, 14, -102], [1, 1, 0.8], [0, 0.1, 0.2]);
    addMesh(new THREE.CylinderGeometry(5, 8, 31, 5), material('#bd7840'), landmark, [21, 15, -112], [1, 1, 0.9], [0, 0.1, -0.16]);
  } else if (map.landmark === 'towers' || map.landmark === 'green-towers') {
    for (let i = 0; i < 13; i += 1) {
      const x = -31 + i * 5.2;
      const h = 10 + ((i * 7) % 17);
      addNeonTower(landmark, x, -108 - (i % 3) * 8, h, i % 2 ? edgeMat : accent2Mat, 2.4);
    }
  }

  // Cosmic and city backdrops get a small star/particle field that remains static (no expensive simulation).
  if (effectsEnabled && (map.biome === 'cosmic' || map.biome === 'portal' || map.biome === 'neon' || map.biome === 'moonlight')) {
    const starCount = low ? 180 : high ? 1400 : 420;
    const vertices = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i += 1) {
      vertices[i * 3] = (Math.random() - 0.5) * 230;
      vertices[i * 3 + 1] = Math.random() * 80 + 8;
      vertices[i * 3 + 2] = -35 - Math.random() * 190;
    }
    const geometry = new THREE.BufferGeometry(); geometry.setAttribute('position', new THREE.BufferAttribute(vertices, 3));
    const starMat = new THREE.PointsMaterial({ color: map.biome === 'cosmic' ? '#b7dfff' : '#80eaff', size: low ? 0.09 : high ? 0.15 : 0.12, sizeAttenuation: true });
    const stars = new THREE.Points(geometry, starMat); landmark.add(stars);
  }

  root.traverse((node) => {
    if (node instanceof THREE.Mesh) {
      node.castShadow = shadowsEnabled && !low;
      node.receiveShadow = shadowsEnabled && !low;
    }
  });
  return { root, trackSegments: segments, segmentLength: SEGMENT_LENGTH, landmark };
}
