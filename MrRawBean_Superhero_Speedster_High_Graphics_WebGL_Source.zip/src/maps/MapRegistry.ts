export type MapId =
  | 'MAP_01' | 'MAP_02' | 'MAP_03' | 'MAP_04' | 'MAP_05'
  | 'MAP_06' | 'MAP_07' | 'MAP_08' | 'MAP_09';

export type Biome = 'neon' | 'tropical' | 'ice' | 'emerald' | 'inferno' | 'portal' | 'desert' | 'moonlight' | 'cosmic';

export interface MapDefinition {
  id: MapId;
  name: string;
  subtitle: string;
  biome: Biome;
  thumbnail: string;
  sky: string;
  fog: string;
  road: string;
  accent: string;
  accent2: string;
  glow: string;
  ground: string;
  ambient: number;
  sun: number;
  propDensity: number;
  landmark: 'towers' | 'palms' | 'icecastle' | 'islands' | 'volcano' | 'portal' | 'canyon' | 'green-towers' | 'planet';
  description: string;
}

export const MAPS: readonly MapDefinition[] = [
  {
    id: 'MAP_01', name: 'NEON CYBER CITY', subtitle: 'Electric streets • Night run', biome: 'neon',
    thumbnail: './maps/neon-city.webp', sky: '#061232', fog: '#10265e', road: '#07152b',
    accent: '#00d9ff', accent2: '#ff2fc7', glow: '#315dff', ground: '#071d3a',
    ambient: 1.1, sun: 2.1, propDensity: 1, landmark: 'towers', description: 'Run through rain-slick neon avenues and a towering cyber skyline.'
  },
  {
    id: 'MAP_02', name: 'TROPICAL SUNSET KINGDOM', subtitle: 'Golden horizon • Island run', biome: 'tropical',
    thumbnail: './maps/tropical-sunset.webp', sky: '#ff925d', fog: '#fa9d6c', road: '#5a3225',
    accent: '#ffb33d', accent2: '#49e7cb', glow: '#ff7b2f', ground: '#234f43',
    ambient: 1.45, sun: 2.5, propDensity: 0.9, landmark: 'palms', description: 'Dash across amber bridges between palm islands, waterfalls, and floating ruins.'
  },
  {
    id: 'MAP_03', name: 'FROZEN ICE KINGDOM', subtitle: 'Frostbite fast • Ice run', biome: 'ice',
    thumbnail: './maps/ice-kingdom.webp', sky: '#8ac8f5', fog: '#b9e5ff', road: '#5b8eb2',
    accent: '#a9f6ff', accent2: '#75b7ff', glow: '#f2fdff', ground: '#c4edff',
    ambient: 1.4, sun: 2.2, propDensity: 1, landmark: 'icecastle', description: 'Race along frozen roads beneath crystalline peaks and ice castles.'
  },
  {
    id: 'MAP_04', name: 'EMERALD FLOATING ISLANDS', subtitle: 'Sky gardens • Canopy run', biome: 'emerald',
    thumbnail: './maps/emerald-islands.webp', sky: '#71d5ff', fog: '#8ceac9', road: '#176d67',
    accent: '#42ffad', accent2: '#10cfbd', glow: '#76fcb0', ground: '#126e4f',
    ambient: 1.4, sun: 2.6, propDensity: 0.95, landmark: 'islands', description: 'Leap between lush floating gardens, waterfalls, and suspended bridges.'
  },
  {
    id: 'MAP_05', name: 'INFERNO VOLCANO KINGDOM', subtitle: 'Lava below • Survival run', biome: 'inferno',
    thumbnail: './maps/inferno.webp', sky: '#24070d', fog: '#59121b', road: '#210f18',
    accent: '#ff5a29', accent2: '#ffbd33', glow: '#ff3018', ground: '#1b0d17',
    ambient: 0.7, sun: 1.7, propDensity: 1, landmark: 'volcano', description: 'Outrun the heat along volcanic causeways cut into black rock.'
  },
  {
    id: 'MAP_06', name: 'COSMIC PURPLE PORTAL CITY', subtitle: 'Dimensional gate • Portal run', biome: 'portal',
    thumbnail: './maps/cosmic-portal.webp', sky: '#170b40', fog: '#352064', road: '#170f35',
    accent: '#a451ff', accent2: '#ff37e9', glow: '#3caeff', ground: '#201345',
    ambient: 1.0, sun: 2.3, propDensity: 1, landmark: 'portal', description: 'Sprint toward a colossal dimensional portal in a violet megacity.'
  },
  {
    id: 'MAP_07', name: 'GOLDEN DESERT FRONTIER', subtitle: 'Dust and daylight • Canyon run', biome: 'desert',
    thumbnail: './maps/golden-desert.webp', sky: '#ffc77c', fog: '#e6a85b', road: '#8a512b',
    accent: '#ffd75f', accent2: '#ff912f', glow: '#fff4a3', ground: '#ab652f',
    ambient: 1.6, sun: 2.8, propDensity: 0.85, landmark: 'canyon', description: 'Thread canyon roads, sandstone arches, and sunlit rocky bridges.'
  },
  {
    id: 'MAP_08', name: 'EMERALD MOONLIGHT CITY', subtitle: 'Green neon • Lunar run', biome: 'moonlight',
    thumbnail: './maps/moonlight-city.webp', sky: '#041a2d', fog: '#073e4b', road: '#052728',
    accent: '#00ff96', accent2: '#42bfff', glow: '#48ffaf', ground: '#052b35',
    ambient: 0.9, sun: 1.9, propDensity: 1, landmark: 'green-towers', description: 'Explore a moonlit city glowing with emerald signs and teal reflections.'
  },
  {
    id: 'MAP_09', name: 'COSMIC PLANET FRONTIER', subtitle: 'Orbit ahead • Space run', biome: 'cosmic',
    thumbnail: './maps/planet-frontier.webp', sky: '#03051a', fog: '#171e62', road: '#10122c',
    accent: '#52dfff', accent2: '#b17cff', glow: '#f55cff', ground: '#090d29',
    ambient: 1.0, sun: 2.4, propDensity: 0.85, landmark: 'planet', description: 'Race along orbital walkways beneath a giant luminous planet and spacecraft.'
  },
] as const;

const validMapIds = new Set<string>(MAPS.map((map) => map.id));
if (MAPS.length !== 9 || new Set(MAPS.map((map) => map.id)).size !== 9) {
  throw new Error('MapRegistry must contain exactly nine unique map IDs.');
}

export function isMapId(value: unknown): value is MapId {
  return typeof value === 'string' && validMapIds.has(value);
}

export function getMap(id: MapId): MapDefinition {
  const map = MAPS.find((candidate) => candidate.id === id);
  if (!map) throw new Error(`Unknown map ID: ${String(id)}`);
  return map;
}
