import { classifyGesture } from '../game/logic.js';
import type { Game, GameAction } from '../game/Game';

export class TouchControls {
  private root: HTMLElement;
  private game: Game;
  private start: { x: number; y: number; id: number } | null = null;
  private sensitivity: number;
  private pointerDown = (event: PointerEvent) => {
    if (this.game.currentState !== 'running' || this.isUiTarget(event.target)) return;
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    this.start = { x: event.clientX, y: event.clientY, id: event.pointerId };
  };
  private pointerUp = (event: PointerEvent) => {
    if (!this.start || this.start.id !== event.pointerId) return;
    const gesture = classifyGesture(this.start.x, this.start.y, event.clientX, event.clientY, this.sensitivity);
    this.start = null;
    if (gesture.type !== 'swipe') return;
    const action: Record<string, GameAction> = { left: 'left', right: 'right', up: 'jump', down: 'slide' };
    const mapped = action[gesture.direction ?? ''];
    if (mapped) this.game.action(mapped);
  };
  private pointerCancel = () => { this.start = null; };
  private keyDown = (event: KeyboardEvent) => {
    if (this.isTypingTarget(event.target)) return;
    const key = event.key.toLowerCase();
    if (key === 'escape') {
      event.preventDefault();
      if (this.game.currentState === 'running') this.game.pause();
      else if (this.game.currentState === 'paused') this.game.resume();
      return;
    }
    const actionByKey: Record<string, GameAction> = {
      arrowleft: 'left', a: 'left', arrowright: 'right', d: 'right',
      arrowup: 'jump', w: 'jump', ' ': 'jump', arrowdown: 'slide', s: 'slide',
    };
    const action = actionByKey[key];
    if (!action) return;
    event.preventDefault(); this.game.action(action);
  };

  constructor(root: HTMLElement, game: Game, sensitivity = 42) {
    this.root = root; this.game = game; this.sensitivity = sensitivity;
    this.root.addEventListener('pointerdown', this.pointerDown);
    window.addEventListener('pointerup', this.pointerUp);
    window.addEventListener('pointercancel', this.pointerCancel);
    window.addEventListener('keydown', this.keyDown);
  }

  setSensitivity(value: number): void { this.sensitivity = Math.max(22, Math.min(90, value)); }

  private isUiTarget(target: EventTarget | null): boolean {
    if (!(target instanceof Element)) return false;
    return Boolean(target.closest('button, a, input, select, textarea, label, [data-no-swipe], [role="dialog"]'));
  }

  private isTypingTarget(target: EventTarget | null): boolean {
    return target instanceof HTMLElement && (['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName) || target.isContentEditable);
  }

  dispose(): void {
    this.root.removeEventListener('pointerdown', this.pointerDown);
    window.removeEventListener('pointerup', this.pointerUp);
    window.removeEventListener('pointercancel', this.pointerCancel);
    window.removeEventListener('keydown', this.keyDown);
  }
}
