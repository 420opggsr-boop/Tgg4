export const LANES = Object.freeze([-2.2, 0, 2.2]);
export const GAME_RULES = Object.freeze({
  maxLives: 5,
  startingLives: 3,
  checkpointMeters: 2000,
  jumpDuration: 0.88,
  slideDuration: 0.72,
  stumbleDuration: 0.8,
  damageCooldown: 1.1,
  flightDuration: 8,
  speedBoostDuration: 7,
  extraLifePickup: 1,
});

export function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

export function clampLane(lane) {
  return clamp(Math.round(Number.isFinite(lane) ? lane : 1), 0, 2);
}

export function nextLane(currentLane, direction) {
  return clampLane(clampLane(currentLane) + Math.sign(direction));
}

export function classifyGesture(startX, startY, endX, endY, threshold = 42) {
  const dx = endX - startX;
  const dy = endY - startY;
  if (Math.max(Math.abs(dx), Math.abs(dy)) < threshold) return { type: 'tap', direction: null };
  if (Math.abs(dx) > Math.abs(dy)) return { type: 'swipe', direction: dx < 0 ? 'left' : 'right' };
  return { type: 'swipe', direction: dy < 0 ? 'up' : 'down' };
}

export function distanceDelta(speedMetersPerSecond, dtSeconds) {
  if (!Number.isFinite(speedMetersPerSecond) || !Number.isFinite(dtSeconds) || dtSeconds <= 0) return 0;
  return Math.max(0, speedMetersPerSecond) * Math.min(dtSeconds, 0.05);
}

export function crossedCheckpoints(previousDistance, currentDistance, interval = GAME_RULES.checkpointMeters) {
  if (![previousDistance, currentDistance, interval].every(Number.isFinite) || interval <= 0 || currentDistance <= previousDistance) return [];
  const first = Math.floor(Math.max(0, previousDistance) / interval) + 1;
  const last = Math.floor(Math.max(0, currentDistance) / interval);
  const milestones = [];
  for (let index = first; index <= last && milestones.length < 100; index += 1) milestones.push(index * interval);
  return milestones;
}

export function awardLife(currentLives, add = 1, maxLives = GAME_RULES.maxLives) {
  const lives = clamp(Math.floor(Number.isFinite(currentLives) ? currentLives : 0), 0, maxLives);
  const addition = Math.max(0, Math.floor(Number.isFinite(add) ? add : 0));
  return { lives: clamp(lives + addition, 0, maxLives), added: clamp(lives + addition, 0, maxLives) - lives };
}

export function applyObstacleHit({ obstacleType, lives, damage = 1, invulnerable = false, stumbling = false, maxLives = GAME_RULES.maxLives }) {
  if (stumbling || invulnerable) return { outcome: 'ignored', lives: clamp(Math.floor(Number.isFinite(lives) ? lives : 0), 0, maxLives), damage: 0 };
  if (obstacleType === 'grey') return { outcome: 'stumble', lives: Math.max(0, Math.floor(lives)), damage: 0 };
  if (!['red-black', 'vehicle'].includes(obstacleType)) return { outcome: 'ignored', lives: Math.max(0, Math.floor(lives)), damage: 0 };
  const applied = clamp(Math.floor(Number.isFinite(damage) ? damage : 1), 0, 99);
  const nextLives = clamp(Math.floor(Number.isFinite(lives) ? lives : 0) - applied, 0, maxLives);
  return { outcome: nextLives <= 0 ? 'gameover' : 'damage', lives: nextLives, damage: Math.max(0, Math.floor(lives) - nextLives) };
}

export function shouldCollectPickup(id, collectedIds) {
  return typeof id === 'string' && id.length > 0 && collectedIds instanceof Set && !collectedIds.has(id);
}

export function settleRewardOnce(runId, settlementSet) {
  if (!runId || !(settlementSet instanceof Set) || settlementSet.has(runId)) return false;
  settlementSet.add(runId);
  return true;
}

export function isValidPurchase({ price, balance, owned = false }) {
  return Number.isFinite(price) && Number.isFinite(balance) && price >= 0 && balance >= price && owned === false;
}

export function calculateLevel(experience) {
  const xp = Math.max(0, Math.floor(Number.isFinite(experience) ? experience : 0));
  const level = 1 + Math.floor(Math.sqrt(xp / 100));
  const currentLevelXp = (level - 1) ** 2 * 100;
  const nextLevelXp = level ** 2 * 100;
  return { level, progressXp: xp - currentLevelXp, nextLevelXp: nextLevelXp - currentLevelXp };
}

export function isValidPlayerName(name) {
  return typeof name === 'string' && name.trim().length >= 3 && name.trim().length <= 16 && /^[A-Za-z0-9 _-]+$/.test(name.trim()) && !/[\r\n]/.test(name);
}

export function normalizeAudioSettings(settings = {}) {
  const value = (candidate, fallback) => Number.isFinite(candidate) ? clamp(candidate, 0, 1) : fallback;
  return {
    sfx: value(settings.sfx, 0.75),
    voices: value(settings.voices, 0.85),
    ui: value(settings.ui, 0.7),
    vibration: settings.vibration !== false,
  };
}

export function normalizeSettings(settings = {}) {
  const mobileRuntime = typeof navigator !== 'undefined' && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
  const recommendedQuality = mobileRuntime ? 'medium' : 'high';
  const quality = ['low', 'medium', 'high'].includes(settings.quality)
    ? settings.quality
    : settings.quality === undefined ? recommendedQuality : 'medium';
  const fps = [30, 60].includes(settings.fps) ? settings.fps : 60;
  const swipeSensitivity = clamp(Number.isFinite(settings.swipeSensitivity) ? settings.swipeSensitivity : 42, 22, 90);
  return {
    quality,
    fps,
    shadows: typeof settings.shadows === 'boolean' ? settings.shadows : quality === 'high',
    effects: settings.effects !== false,
    motionEffects: settings.motionEffects !== false,
    audio: normalizeAudioSettings(settings.audio),
    swipeSensitivity,
    vibration: settings.vibration !== false,
    music: false,
  };
}
