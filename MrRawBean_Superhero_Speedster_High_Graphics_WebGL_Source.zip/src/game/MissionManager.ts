import type { MissionDefinition } from '../save/SaveSchema';

export const MISSIONS: readonly MissionDefinition[] = [
  { id: 'distance-500', title: 'FIRST FLIGHT', description: 'Reach 500 meters in one run.', objective: 'distance', target: 500, rewardCoins: 100, rewardGems: 0 },
  { id: 'rescue-3', title: 'CITY GUARDIAN', description: 'Rescue 3 civilians in one run.', objective: 'rescues', target: 3, rewardCoins: 180, rewardGems: 2 },
  { id: 'hearts-5', title: 'HEART HUNTER', description: 'Collect 5 hearts in one run.', objective: 'hearts', target: 5, rewardCoins: 120, rewardGems: 1 },
  { id: 'survive-1000', title: 'TRAFFIC BREAKER', description: 'Survive for 1,000 meters.', objective: 'survive', target: 1000, rewardCoins: 220, rewardGems: 1 },
  { id: 'finish-3-lives', title: 'UNSTOPPABLE', description: 'Finish 600 meters with at least 3 lives.', objective: 'lives', target: 600, rewardCoins: 200, rewardGems: 2 },
] as const;

export function getMission(id: string): MissionDefinition | undefined {
  return MISSIONS.find((mission) => mission.id === id);
}

export class MissionManager {
  current: MissionDefinition;
  progress = 0;
  completedThisRun = false;

  constructor(missionId = MISSIONS[0].id) { this.current = getMission(missionId) ?? MISSIONS[0]; }

  setMission(missionId: string): boolean {
    const mission = getMission(missionId);
    if (!mission) return false;
    this.current = mission; this.progress = 0; this.completedThisRun = false; return true;
  }

  reset(): void { this.progress = 0; this.completedThisRun = false; }

  update(metrics: { distance?: number; rescues?: number; hearts?: number; lives?: number }): { progress: number; target: number; complete: boolean; mission: MissionDefinition } {
    let progress = 0;
    switch (this.current.objective) {
      case 'distance': case 'survive': progress = metrics.distance ?? this.progress; break;
      case 'rescues': progress = metrics.rescues ?? this.progress; break;
      case 'hearts': progress = metrics.hearts ?? this.progress; break;
      case 'lives': progress = (metrics.distance ?? this.progress) >= this.current.target && (metrics.lives ?? 0) >= 3 ? this.current.target : Math.min(metrics.distance ?? 0, this.current.target - 1); break;
    }
    this.progress = Math.min(this.current.target, Math.max(0, progress));
    const complete = this.progress >= this.current.target;
    this.completedThisRun ||= complete;
    return { progress: this.progress, target: this.current.target, complete, mission: this.current };
  }
}
