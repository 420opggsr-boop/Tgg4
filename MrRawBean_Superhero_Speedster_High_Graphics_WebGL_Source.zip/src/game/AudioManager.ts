import type { SaveData } from '../save/SaveSchema';

/** Local sound effects and bundled speech only. There is no music player or music track. */
type VoiceKind = 'rescue' | 'checkpoint';
const VOICE_CLIPS: Record<VoiceKind, string> = {
  rescue: './audio/rescue-thank-you.mp3',
  checkpoint: './audio/checkpoint-superhero.mp3',
};

export class AudioManager {
  private context: AudioContext | null = null;
  private masterSfx = 0.75;
  private masterVoices = 0.85;
  private masterUi = 0.7;
  private enabled = true;
  private voicePaused = false;
  private voiceQueue: VoiceKind[] = [];
  private voiceAudio: HTMLAudioElement | null = null;

  configure(save: SaveData): void {
    this.setVolumes(save.settings.audio.sfx, save.settings.audio.voices, save.settings.audio.ui);
  }

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined' || !('AudioContext' in window)) return null;
    try {
      this.context ??= new AudioContext();
      if (this.context.state === 'suspended') void this.context.resume();
      return this.context;
    } catch { return null; }
  }

  private noiseBurst(duration: number, gainValue: number, filterHz: number, channel: 'sfx' | 'ui'): void {
    if (!this.enabled) return;
    const ctx = this.ensureContext();
    if (!ctx) return;
    const volume = channel === 'ui' ? this.masterUi : this.masterSfx;
    if (volume <= 0) return;
    const frameCount = Math.max(1, Math.floor(ctx.sampleRate * duration));
    const buffer = ctx.createBuffer(1, frameCount, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < frameCount; i += 1) data[i] = (Math.random() * 2 - 1) * (1 - i / frameCount) * 0.65;
    const source = ctx.createBufferSource(); source.buffer = buffer;
    const filter = ctx.createBiquadFilter(); filter.type = 'lowpass'; filter.frequency.value = filterHz;
    const gain = ctx.createGain(); gain.gain.setValueAtTime(Math.max(0.0001, gainValue * volume), ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
    source.connect(filter); filter.connect(gain); gain.connect(ctx.destination);
    source.start(); source.stop(ctx.currentTime + duration);
  }

  uiClick(): void { this.noiseBurst(0.045, 0.12, 1500, 'ui'); }
  pickup(): void { this.noiseBurst(0.12, 0.22, 2300, 'sfx'); }
  jump(): void { this.noiseBurst(0.11, 0.15, 900, 'sfx'); }
  impact(): void { this.noiseBurst(0.17, 0.32, 420, 'sfx'); }
  stumble(): void { this.noiseBurst(0.13, 0.18, 760, 'sfx'); }
  rescue(): void { this.noiseBurst(0.09, 0.13, 1800, 'sfx'); }
  powerUp(): void { this.noiseBurst(0.16, 0.2, 1300, 'sfx'); }
  complete(): void { this.noiseBurst(0.13, 0.18, 1900, 'sfx'); }

  /**
   * Queue one bundled, local voice clip. Speech is serialized to avoid overlap at
   * multi-checkpoint crossings. Returns false only when the requested clip is unknown.
   */
  queueVoice(kind: VoiceKind): boolean {
    if (!(kind in VOICE_CLIPS)) return false;
    this.voiceQueue.push(kind);
    this.playNextVoice();
    return true;
  }

  private playNextVoice(): void {
    if (this.voicePaused || this.voiceAudio || this.voiceQueue.length === 0 || !this.enabled || this.masterVoices <= 0) return;
    if (typeof Audio === 'undefined') { this.voiceQueue = []; return; }
    const kind = this.voiceQueue.shift();
    if (!kind) return;
    const audio = new Audio(VOICE_CLIPS[kind]);
    audio.preload = 'auto';
    audio.loop = false;
    audio.volume = Math.min(1, Math.max(0, this.masterVoices));
    this.voiceAudio = audio;
    const finish = (): void => {
      if (this.voiceAudio !== audio) return;
      audio.onended = null;
      audio.onerror = null;
      this.voiceAudio = null;
      this.playNextVoice();
    };
    audio.onended = finish;
    audio.onerror = finish;
    void audio.play().catch(finish);
  }

  setEnabled(value: boolean): void {
    this.enabled = value;
    if (!value) {
      this.voiceQueue = [];
      this.voiceAudio?.pause();
      this.voiceAudio = null;
    } else this.playNextVoice();
  }

  setVolumes(sfx: number, voices: number, ui: number): void {
    this.masterSfx = Math.min(1, Math.max(0, Number.isFinite(sfx) ? sfx : 0.75));
    this.masterVoices = Math.min(1, Math.max(0, Number.isFinite(voices) ? voices : 0.85));
    this.masterUi = Math.min(1, Math.max(0, Number.isFinite(ui) ? ui : 0.7));
    if (this.voiceAudio) this.voiceAudio.volume = this.masterVoices;
    if (this.masterVoices <= 0) this.voiceAudio?.pause();
    else if (!this.voicePaused && this.voiceAudio?.paused) void this.voiceAudio.play().catch(() => undefined);
  }

  get voiceVolume(): number { return this.masterVoices; }

  pause(): void {
    if (this.context?.state === 'running') void this.context.suspend();
    this.voicePaused = true;
    this.voiceAudio?.pause();
  }

  resume(): void {
    if (this.context?.state === 'suspended') void this.context.resume();
    this.voicePaused = false;
    if (this.voiceAudio?.paused && this.masterVoices > 0) void this.voiceAudio.play().catch(() => undefined);
    else this.playNextVoice();
  }

  dispose(): void {
    this.enabled = false;
    this.voicePaused = true;
    this.voiceQueue = [];
    if (this.voiceAudio) {
      this.voiceAudio.pause();
      this.voiceAudio.removeAttribute('src');
      this.voiceAudio.load();
    }
    this.voiceAudio = null;
    if (this.context) void this.context.close();
    this.context = null;
  }
}
