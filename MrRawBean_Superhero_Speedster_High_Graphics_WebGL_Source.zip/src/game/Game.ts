import * as THREE from 'three';
import { MAPS, getMap, isMapId, type MapDefinition, type MapId } from '../maps/MapRegistry';
import { buildEnvironment, disposeObjectTree, type BuiltEnvironment } from '../maps/EnvironmentBuilder';
import { PlayerCharacter, type PlayerAnimation } from '../player/PlayerCharacter';
import { AudioManager } from './AudioManager';
import { MissionManager } from './MissionManager';
import { GAME_RULES, LANES, awardLife, applyObstacleHit, crossedCheckpoints, distanceDelta, nextLane } from './logic.js';

export type GameState = 'menu' | 'running' | 'paused' | 'gameover';
export type GameAction = 'left' | 'right' | 'jump' | 'slide';
export interface RunStats {
  distance: number; lives: number; rescues: number; coins: number; gems: number; hearts: number;
  duration: number; speed: number; baseSpeed: number; activePower: '' | 'flight' | 'speed'; powerRemaining: number;
  lane: number; missionId: string; missionProgress: number; missionTarget: number; missionComplete: boolean;
}
export interface GameResult {
  runId: string; mapId: MapId; distance: number; rescues: number; coins: number; gems: number;
  hearts: number; duration: number; missionId: string; missionComplete: boolean; lives: number;
}
export type GameEvent =
  | { type: 'state'; state: GameState }
  | { type: 'hud'; stats: RunStats }
  | { type: 'toast'; message: string; tone?: 'info' | 'success' | 'warning' | 'danger' }
  | { type: 'checkpoint'; meters: number; voiceAvailable: boolean }
  | { type: 'map-loaded'; mapId: MapId }
  | { type: 'map-error'; mapId: MapId; message: string }
  | { type: 'gameover'; result: GameResult }
  | { type: 'mission'; missionId: string; progress: number; target: number; complete: boolean; title: string };

type SpawnKind = 'grey' | 'red-black' | 'car' | 'motorcycle' | 'truck' | 'heart-flight' | 'heart-life' | 'heart-speed' | 'coin' | 'civilian';
interface SpawnedObject { id: string; kind: SpawnKind; lane: number; z: number; mesh: THREE.Group; resolved: boolean; width: number; height: number; style?: 'low' | 'overhead' | 'wall'; damage?: number; }
interface PowerState { flight: number; speed: number; }

export class Game {
  readonly audio = new AudioManager();
  readonly canvas: HTMLCanvasElement;
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.PerspectiveCamera(62, 1, 0.1, 550);
  readonly player = new PlayerCharacter();
  readonly missions = new MissionManager();
  private onEvent: (event: GameEvent) => void;
  private state: GameState = 'menu';
  private selectedMap: MapId = 'MAP_01';
  private mapDefinition: MapDefinition = getMap('MAP_01');
  private environment: BuiltEnvironment | null = null;
  private objectRoot = new THREE.Group();
  private spawned: SpawnedObject[] = [];
  private trackFarZ = -68;
  private frameHandle = 0;
  private lastFrame = 0;
  private lastRenderedAt = 0;
  private elapsed = 0;
  private runId = '';
  private objectSequence = 0;
  private runStart = 0;
  private distance = 0;
  private lives = GAME_RULES.startingLives;
  private rescues = 0;
  private coins = 0;
  private gems = 0;
  private hearts = 0;
  private runDuration = 0;
  private baseSpeed = 13;
  private speed = 13;
  private difficulty = 0;
  private activePower: '' | 'flight' | 'speed' = '';
  private powers: PowerState = { flight: 0, speed: 0 };
  private invulnerability = 0;
  private spawnClock = 0;
  private nextCheckpoint = 2000;
  private collectedIds = new Set<string>();
  private runSettled = false;
  private randomState = 0x6d2b79f5;
  private lastHudAt = 0;
  private visibilityHandler = () => { if (document.hidden && this.state === 'running') this.pause(); };
  private contextMenuHandler = (event: MouseEvent) => { if (event.target === this.canvas) event.preventDefault(); };
  private contextLostHandler = (event: Event) => { event.preventDefault(); if (this.state === 'running') this.pause(); this.emit({ type: 'toast', message: '3D context lost. Attempting recovery…', tone: 'warning' }); };
  private contextRestoredHandler = () => { this.resize(); this.emit({ type: 'toast', message: '3D context restored.', tone: 'success' }); }; 
  private readonly mobileRuntime = typeof navigator !== 'undefined' && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
  private renderScale = 1;
  private perfSamples = 0;
  private perfFrameMs = 16.7;
  private perfCheckFrames = 0;
  private settings: { quality: 'low' | 'medium' | 'high'; fps: 30 | 60; shadows: boolean; effects: boolean; motionEffects: boolean; vibration: boolean } = { quality: typeof navigator !== 'undefined' && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent) ? 'medium' : 'high', fps: 60, shadows: !(typeof navigator !== 'undefined' && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent)), effects: true, motionEffects: true, vibration: true };

  constructor(canvas: HTMLCanvasElement, onEvent: (event: GameEvent) => void) {
    this.canvas = canvas; this.onEvent = onEvent;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: !this.mobileRuntime, alpha: false, powerPreference: 'high-performance', failIfMajorPerformanceCaveat: false, preserveDrawingBuffer: false });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.shadowMap.enabled = this.settings.shadows;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.scene.add(this.player.root, this.objectRoot);
    this.objectRoot.name = 'SpawnedGameplayObjects';
    this.applyCamera('menu');
    this.loadMap('MAP_01');
    this.bindGlobalListeners();
    this.resize();
    this.frameHandle = requestAnimationFrame(this.frame);
    const url = new URL(window.location.href);
    if (url.searchParams.get('test') === '1') this.installTestApi();
  }

  private bindGlobalListeners(): void {
    window.addEventListener('resize', this.resize);
    document.addEventListener('visibilitychange', this.visibilityHandler);
    window.addEventListener('contextmenu', this.contextMenuHandler);
    this.canvas.addEventListener('webglcontextlost', this.contextLostHandler, false);
    this.canvas.addEventListener('webglcontextrestored', this.contextRestoredHandler, false);
  }

  private resize = (): void => {
    const width = Math.max(1, this.canvas.clientWidth || window.innerWidth);
    const height = Math.max(1, this.canvas.clientHeight || window.innerHeight);
    this.camera.aspect = width / height; this.camera.updateProjectionMatrix();
    const qualityScale = this.settings.quality === 'low' ? 0.62 : this.settings.quality === 'medium' ? 0.9 : 1;
    const deviceCap = this.mobileRuntime ? 1.65 : 2.25;
    this.renderer.shadowMap.enabled = this.settings.shadows && this.settings.quality !== 'low';
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, deviceCap) * qualityScale * this.renderScale);
    this.renderer.setSize(width, height, false);
  };

  private emit(event: GameEvent): void { this.onEvent(event); }

  private haptic(pattern: number | number[]): void {
    if (!this.settings.vibration || typeof navigator === 'undefined' || typeof navigator.vibrate !== 'function') return;
    try { navigator.vibrate(pattern); } catch { /* Unsupported browser/device: continue without haptics. */ }
  }
  get currentState(): GameState { return this.state; }
  get currentMap(): MapId { return this.selectedMap; }
  get availableMaps(): readonly MapDefinition[] { return MAPS; }

  applySettings(settings: Partial<{ quality: 'low' | 'medium' | 'high'; fps: 30 | 60; shadows: boolean; effects: boolean; motionEffects: boolean; vibration: boolean }>): void {
    const previous = this.settings;
    this.settings = { ...this.settings, ...settings };
    const needsRebuild = previous.quality !== this.settings.quality || previous.shadows !== this.settings.shadows || previous.effects !== this.settings.effects;
    this.player.setMotionEffects(this.settings.motionEffects);
    this.player.setSpeedTrail(this.settings.effects && this.powers.speed > 0);
    if (this.environment && needsRebuild && this.state !== 'running') this.loadMap(this.selectedMap);
    this.resize();
  }

  loadMap(mapId: string): boolean {
    if (!isMapId(mapId)) return false;
    if (this.state === 'running') return false;
    const id = mapId as MapId;
    let nextEnvironment: BuiltEnvironment;
    try {
      nextEnvironment = buildEnvironment(getMap(id), this.settings.quality, this.settings.shadows, this.settings.effects);
    } catch (error) {
      this.emit({ type: 'map-error', mapId: id, message: error instanceof Error ? error.message : 'Could not build this map.' });
      return false;
    }
    if (this.environment) {
      this.scene.remove(this.environment.root);
      disposeObjectTree(this.environment.root);
    }
    this.environment = nextEnvironment;
    this.scene.add(nextEnvironment.root);
    this.selectedMap = id; this.mapDefinition = getMap(id);
    this.scene.background = new THREE.Color(this.mapDefinition.sky);
    this.scene.fog = new THREE.Fog(this.mapDefinition.fog, 32, 220);
    this.emit({ type: 'map-loaded', mapId: id });
    return true;
  }

  setMission(missionId: string): boolean { return this.missions.setMission(missionId); }

  startRun(missionId?: string): boolean {
    if (this.state === 'running') return false;
    if (missionId) this.missions.setMission(missionId);
    this.clearSpawnedObjects();
    this.player.root.rotation.set(0, Math.PI, 0);
    this.player.root.scale.set(1, 1, 1);
    this.player.lane = 1; this.player.targetX = 0; this.player.root.position.set(0, 0.08, 0);
    this.player.setAnimation('run');
    this.elapsed = 0;
    this.distance = 0; this.lives = GAME_RULES.startingLives; this.rescues = 0; this.coins = 0; this.gems = 0; this.hearts = 0;
    this.runDuration = 0; this.baseSpeed = 13; this.speed = 13; this.difficulty = 0;
    this.activePower = ''; this.powers = { flight: 0, speed: 0 }; this.player.setSpeedTrail(false); this.invulnerability = 0;
    this.spawnClock = 0; this.nextCheckpoint = GAME_RULES.checkpointMeters; this.collectedIds.clear(); this.runSettled = false;
    this.missions.reset(); this.runId = `run-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
    this.runStart = performance.now(); this.lastFrame = performance.now(); this.lastRenderedAt = this.lastFrame; this.lastHudAt = 0; this.randomState = (Date.now() ^ 0x6d2b79f5) >>> 0;
    this.state = 'running'; this.applyCamera('game'); this.audio.resume();
    this.emit({ type: 'state', state: this.state }); this.emit({ type: 'toast', message: `${this.mapDefinition.name} — RUN STARTED`, tone: 'success' });
    this.emitHud(true);
    return true;
  }

  pause(): boolean {
    if (this.state !== 'running') return false;
    this.state = 'paused'; this.audio.pause(); this.emit({ type: 'state', state: this.state }); return true;
  }

  resume(): boolean {
    if (this.state !== 'paused') return false;
    this.state = 'running'; this.lastFrame = performance.now(); this.audio.resume(); this.emit({ type: 'state', state: this.state }); return true;
  }

  restart(): boolean {
    if (!['running', 'paused', 'gameover'].includes(this.state)) return false;
    return this.startRun();
  }

  returnHome(): void {
    if (this.state === 'running') this.pause();
    if (this.state === 'paused' || this.state === 'gameover') {
      this.state = 'menu'; this.player.root.rotation.set(0, 0, 0); this.player.setAnimation('idle');
      this.clearSpawnedObjects(); this.activePower = ''; this.powers = { flight: 0, speed: 0 }; this.player.setSpeedTrail(false);
      this.applyCamera('menu'); this.audio.resume(); this.emit({ type: 'state', state: this.state });
    } else {
      this.player.root.rotation.y = 0; this.player.setAnimation('idle'); this.applyCamera('menu');
    }
  }

  action(action: GameAction): boolean {
    if (this.state !== 'running') return false;
    switch (action) {
      case 'left': this.player.moveLane(-1); break;
      case 'right': this.player.moveLane(1); break;
      case 'jump':
        if (!['jump', 'slide', 'flight'].includes(this.player.animation)) { this.player.setAnimation('jump', GAME_RULES.jumpDuration); this.audio.jump(); this.haptic(7); }
        break;
      case 'slide':
        if (!['slide', 'flight'].includes(this.player.animation)) this.player.setAnimation('slide', GAME_RULES.slideDuration);
        break;
    }
    return true;
  }

  private applyCamera(mode: 'menu' | 'game'): void {
    if (mode === 'menu') {
      this.camera.position.set(0, 3.0, 9.7); this.camera.lookAt(0, 1.2, -2.5);
      this.camera.fov += (50 - this.camera.fov) * 0.18;
      this.player.root.rotation.y = 0;
    } else {
      this.camera.position.set(this.player.root.position.x * 0.22, 3.8, 8.3); this.camera.lookAt(this.player.root.position.x * 0.07, 1.4, -11);
      const targetFov = this.settings.motionEffects && this.powers.speed > 0 ? 67 : 62;
      this.camera.fov += (targetFov - this.camera.fov) * 0.18;
      this.player.root.rotation.y = Math.PI;
    }
    this.camera.updateProjectionMatrix();
  }

  private frame = (time: number): void => {
    if (!this.canvas.isConnected) return;
    const minFrameMs = 1000 / (this.settings.fps === 30 ? 30 : 60);
    if (this.lastRenderedAt && time - this.lastRenderedAt < minFrameMs - 1) {
      this.frameHandle = requestAnimationFrame(this.frame);
      return;
    }
    const rawDelta = this.lastFrame ? (time - this.lastFrame) / 1000 : 1 / 60;
    this.lastFrame = time; this.lastRenderedAt = time;
    const frameMs = Math.min(100, Math.max(1, rawDelta * 1000));
    this.perfFrameMs += (frameMs - this.perfFrameMs) * 0.08;
    this.perfSamples += 1;
    this.perfCheckFrames += 1;
    if (this.mobileRuntime && this.state === 'running' && this.perfCheckFrames >= 45 && this.perfSamples >= 45) {
      this.perfCheckFrames = 0;
      if (this.perfFrameMs > 27 && this.renderScale > 0.72) {
        this.renderScale = 0.72; this.resize();
      } else if (this.perfFrameMs > 21 && this.renderScale > 0.82) {
        this.renderScale = 0.82; this.resize();
      } else if (this.perfFrameMs < 15.5 && this.renderScale < 1) {
        this.renderScale = Math.min(1, this.renderScale + 0.08); this.resize();
      }
    }
    const dt = Math.min(0.05, Math.max(0, rawDelta));
    if (this.state === 'running') this.updateRun(dt);
    else if (this.state === 'menu') this.player.update(dt, time / 1000);
    else if (this.state === 'paused' || this.state === 'gameover') this.player.update(0, time / 1000);
    this.applyCamera(this.state === 'menu' ? 'menu' : 'game');
    try { this.renderer.render(this.scene, this.camera); } catch (error) {
      this.emit({ type: 'toast', message: 'Renderer error. Try a lower graphics setting or reload.', tone: 'danger' });
      console.error('Three.js render failed:', error);
    }
    this.frameHandle = requestAnimationFrame(this.frame);
  };

  private updateRun(dt: number): void {
    this.elapsed += dt; this.runDuration += dt;
    this.difficulty = Math.min(1, this.distance / 12000);
    this.baseSpeed = Math.min(22, 13 + this.distance / 1400);
    const hadFlight = this.powers.flight > 0;
    const hadSpeed = this.powers.speed > 0;
    this.powers.flight = Math.max(0, this.powers.flight - dt);
    this.powers.speed = Math.max(0, this.powers.speed - dt);
    if (hadFlight && this.powers.flight === 0) {
      if (['flight', 'flight-takeoff'].includes(this.player.animation)) this.player.setAnimation('flight-landing', 0.35);
      if (this.activePower === 'flight') this.activePower = this.powers.speed > 0 ? 'speed' : '';
      this.emit({ type: 'toast', message: 'FLIGHT ENDED', tone: 'info' });
    }
    if (hadSpeed && this.powers.speed === 0) {
      this.player.setSpeedTrail(false);
      if (this.activePower === 'speed') this.activePower = this.powers.flight > 0 ? 'flight' : '';
      this.emit({ type: 'toast', message: '2× SPEED ENDED', tone: 'info' });
    }
    if (this.powers.flight > 0 && this.player.animation === 'run') this.player.setAnimation('flight');
    this.speed = this.baseSpeed * (this.powers.speed > 0 ? 2 : 1);
    const deltaDistance = distanceDelta(this.speed, dt);
    const oldDistance = this.distance;
    this.distance += deltaDistance;
    this.invulnerability = Math.max(0, this.invulnerability - dt);
    this.updateTrack(deltaDistance);
    this.player.update(dt, this.runDuration);
    this.updateSpawnedObjects(deltaDistance, dt);
    this.updateSpawning(dt);
    for (const meters of crossedCheckpoints(oldDistance, this.distance, GAME_RULES.checkpointMeters)) {
      this.nextCheckpoint = meters + GAME_RULES.checkpointMeters;
      const voiceAvailable = this.audio.queueVoice('checkpoint');
      this.emit({ type: 'checkpoint', meters, voiceAvailable });
    }
    this.updateMission();
    if (this.distance >= 100_000) this.finishRun();
    if (this.runDuration - this.lastHudAt >= 0.12) { this.lastHudAt = this.runDuration; this.emitHud(); }
  }

  private updateTrack(distanceDeltaMeters: number): void {
    if (!this.environment) return;
    const shift = distanceDeltaMeters;
    let minZ = Infinity;
    for (const segment of this.environment.trackSegments) {
      segment.position.z += shift;
      minZ = Math.min(minZ, segment.position.z);
    }
    for (const segment of this.environment.trackSegments) {
      if (segment.position.z > this.environment.segmentLength * 1.45) {
        segment.position.z = minZ - this.environment.segmentLength;
        minZ = Math.min(minZ, segment.position.z);
      }
    }
  }

  private random(): number {
    this.randomState = (Math.imul(this.randomState, 1664525) + 1013904223) >>> 0;
    return this.randomState / 0x100000000;
  }

  private updateSpawning(dt: number): void {
    this.spawnClock += dt;
    const interval = Math.max(0.72, 1.35 - this.difficulty * 0.32);
    let guard = 0;
    while (this.spawnClock >= interval && guard < 2) {
      this.spawnClock -= interval; this.spawnWave(); guard += 1;
    }
  }

  private spawnWave(): void {
    const objectCap = this.settings.quality === 'low' || this.mobileRuntime && this.renderScale < 0.8 ? 34 : 42;
    if (this.spawned.length > objectCap) return;
    const lane = Math.floor(this.random() * 3);
    const roll = this.random();
    let kind: SpawnKind;
    if (roll < 0.13) kind = 'coin';
    else if (roll < 0.18) kind = 'heart-flight';
    else if (roll < 0.22) kind = 'heart-life';
    else if (roll < 0.26) kind = 'heart-speed';
    else if (roll < 0.36) kind = 'civilian';
    else if (roll < 0.46) kind = 'motorcycle';
    else if (roll < 0.56) kind = 'car';
    else if (roll < 0.62) kind = 'truck';
    else if (roll < 0.78) kind = 'grey';
    else kind = 'red-black';
    // Rarely add a second item in a different lane, preserving at least one clear path.
    this.spawnObject(kind, lane, -Math.max(76, this.speed * 2.85));
    if (this.random() < 0.18 && ['coin', 'heart-flight', 'heart-life', 'heart-speed'].includes(kind)) {
      const lane2 = (lane + 1 + Math.floor(this.random() * 2)) % 3;
      this.spawnObject('coin', lane2, -Math.max(82, this.speed * 2.95));
    }
  }

  /** Deterministic test hook: spawn a selected scenario in front of the hero. */
  spawnScenario(kind: SpawnKind, lane = 1, distanceAhead = 5): string {
    const id = this.spawnObject(kind, lane, -Math.max(2, distanceAhead));
    return id;
  }

  private spawnObject(kind: SpawnKind, lane: number, z: number): string {
    const mesh = new THREE.Group(); mesh.name = `Spawn-${kind}`;
    const x = LANES[lane];
    const standard = (color: string, emissive = '#000000', metalness = 0.25, roughness = 0.55) => new THREE.MeshStandardMaterial({ color, emissive, emissiveIntensity: emissive === '#000000' ? 0 : 0.75, metalness, roughness });
    const add = (geometry: THREE.BufferGeometry, mat: THREE.Material, pos: [number, number, number], scale?: [number, number, number]) => {
      const item = new THREE.Mesh(geometry, mat); item.position.set(...pos); if (scale) item.scale.set(...scale); item.castShadow = this.settings.shadows && this.settings.quality !== 'low'; item.receiveShadow = item.castShadow; mesh.add(item); return item;
    };
    let width = 1.45, height = 1.4, style: SpawnedObject['style'] = 'low', damage = 1;
    if (kind === 'grey' || kind === 'red-black') {
      const red = kind === 'red-black'; const bodyMat = standard(red ? '#2a070f' : '#7e8997', red ? '#a41023' : '#000000', 0.35, 0.62);
      if (this.random() < 0.5) {
        style = 'low'; width = 1.45; height = 0.92;
        add(new THREE.BoxGeometry(1.45, 0.9, 0.82), bodyMat, [0, 0.47, 0]);
        add(new THREE.BoxGeometry(1.24, 0.09, 0.87), standard(red ? '#ff293f' : '#b4c1d2', red ? '#7d0014' : '#000000'), [0, 0.77, 0]);
        for (const s of [-1, 1]) add(new THREE.BoxGeometry(0.18, 0.12, 0.04), standard(red ? '#ff412d' : '#d4dbe2'), [s * 0.53, 0.49, 0.43]);
      } else {
        style = 'overhead'; width = 1.95; height = 2.65;
        add(new THREE.BoxGeometry(2.1, 0.25, 0.6), bodyMat, [0, 2.15, 0]);
        add(new THREE.BoxGeometry(0.22, 2.3, 0.38), bodyMat, [-0.92, 1.13, 0]);
        add(new THREE.BoxGeometry(0.22, 2.3, 0.38), bodyMat, [0.92, 1.13, 0]);
        add(new THREE.BoxGeometry(1.4, 0.12, 0.08), standard(red ? '#ff4a35' : '#a9b3bf'), [0, 2.0, 0.32]);
      }
    } else if (kind === 'car' || kind === 'motorcycle' || kind === 'truck') {
      const truck = kind === 'truck'; const bike = kind === 'motorcycle';
      width = truck ? 2.1 : bike ? 0.9 : 1.65; height = truck ? 2.8 : bike ? 1.15 : 1.6; style = truck ? 'wall' : 'low';
      const vehicleColor = standard(kind === 'car' ? '#ff632c' : kind === 'motorcycle' ? '#121d3f' : '#8d2939', kind === 'motorcycle' ? '#0039ff' : '#250000', 0.58, 0.28);
      const glass = standard('#9ce8ff', '#164b7a', 0.2, 0.18); const wheelMat = standard('#050914', '#000000', 0.08, 0.95);
      if (bike) {
        add(new THREE.CylinderGeometry(0.18, 0.18, 0.12, 10), wheelMat, [-0.01, 0.19, -0.44], [1, 1, 0.9]).rotation.x = Math.PI / 2;
        add(new THREE.CylinderGeometry(0.18, 0.18, 0.12, 10), wheelMat, [-0.01, 0.19, 0.43], [1, 1, 0.9]).rotation.x = Math.PI / 2;
        add(new THREE.CapsuleGeometry(0.1, 0.52, 3, 6), vehicleColor, [0, 0.53, 0], [1, 1, 1]).rotation.x = Math.PI / 2;
        add(new THREE.SphereGeometry(0.14, 8, 6), glass, [0, 0.92, 0.08]);
        add(new THREE.BoxGeometry(0.5, 0.06, 0.05), standard('#d9fbff', '#72e6ff'), [0, 0.85, 0.38]);
      } else {
        add(new THREE.BoxGeometry(truck ? 2.0 : 1.55, truck ? 1.2 : 0.58, truck ? 3.5 : 2.6), vehicleColor, [0, truck ? 0.8 : 0.56, 0]);
        add(new THREE.BoxGeometry(truck ? 1.65 : 1.14, truck ? 0.95 : 0.5, truck ? 1.05 : 1.02), glass, [0, truck ? 1.64 : 0.99, 0.66]);
        if (truck) add(new THREE.BoxGeometry(1.9, 1.1, 2.15), standard('#752536'), [0, 1.65, -0.82]);
        for (const side of [-1, 1]) for (const zWheel of [-0.82, 0.84]) {
          add(new THREE.CylinderGeometry(truck ? 0.29 : 0.25, truck ? 0.29 : 0.25, 0.14, 10), wheelMat, [side * (truck ? 1.03 : 0.78), 0.28, zWheel]).rotation.z = Math.PI / 2;
        }
        add(new THREE.BoxGeometry(truck ? 0.6 : 0.4, 0.13, 0.04), standard('#ecfbff', '#5fd8ff'), [-0.48, truck ? 0.68 : 0.57, truck ? 1.77 : 1.29]);
        add(new THREE.BoxGeometry(truck ? 0.6 : 0.4, 0.13, 0.04), standard('#ecfbff', '#5fd8ff'), [0.48, truck ? 0.68 : 0.57, truck ? 1.77 : 1.29]);
      }
    } else if (kind.startsWith('heart-')) {
      const shape = new THREE.Shape(); shape.moveTo(0, -0.35); shape.bezierCurveTo(-0.82, 0.1, -0.67, 0.7, -0.22, 0.7); shape.bezierCurveTo(0, 0.7, 0.06, 0.49, 0, 0.42); shape.bezierCurveTo(0.28, 0.79, 0.77, 0.65, 0.77, 0.25); shape.bezierCurveTo(0.77, 0.0, 0.35, -0.25, 0, -0.65); shape.closePath();
      const color = kind === 'heart-flight' ? '#ffd94f' : kind === 'heart-life' ? '#ff334a' : '#56ff8b';
      const heartMat = standard(color, color, 0.3, 0.2);
      add(new THREE.ExtrudeGeometry(shape, { depth: 0.28, bevelEnabled: true, bevelSegments: 2, steps: 1, bevelSize: 0.06, bevelThickness: 0.05 }), heartMat, [0, 1.35, 0], [0.72, 0.72, 0.72]);
      add(new THREE.TorusGeometry(0.66, 0.035, 6, 18), standard(kind === 'heart-life' ? '#ffcf4a' : color, kind === 'heart-life' ? '#c88300' : color), [0, 1.35, -0.12], [1, 1, 0.2]);
      add(new THREE.OctahedronGeometry(0.1), standard('#ffffff', '#ffffff'), [0.12, 1.68, 0.27]);
      height = 1.8; width = 1.2;
    } else if (kind === 'coin') {
      add(new THREE.CylinderGeometry(0.4, 0.4, 0.13, 16), standard('#ffd449', '#cc7a00', 0.7, 0.2), [0, 1.1, 0]).rotation.x = Math.PI / 2;
      add(new THREE.TorusGeometry(0.26, 0.045, 6, 14), standard('#fff3a3', '#ffa800'), [0, 1.1, 0.075]);
      height = 1.5; width = 0.8;
    } else if (kind === 'civilian') {
      const shirt = standard('#f5f2ff', '#1b1c66', 0.12, 0.6); const skin = standard('#b97b55', '#000000', 0.05, 0.72); const pants = standard('#1f3764');
      add(new THREE.CapsuleGeometry(0.21, 0.36, 3, 7), shirt, [0, 0.88, 0]);
      add(new THREE.SphereGeometry(0.19, 10, 8), skin, [0, 1.38, 0.02]);
      add(new THREE.CapsuleGeometry(0.09, 0.32, 3, 6), pants, [-0.12, 0.34, 0]);
      add(new THREE.CapsuleGeometry(0.09, 0.32, 3, 6), pants, [0.12, 0.34, 0]);
      add(new THREE.CapsuleGeometry(0.07, 0.32, 3, 6), skin, [-0.29, 0.88, 0]).rotation.z = 0.24;
      add(new THREE.CapsuleGeometry(0.07, 0.32, 3, 6), skin, [0.29, 0.88, 0]).rotation.z = -0.24;
      add(new THREE.SphereGeometry(0.42, 8, 6), standard('#52fff0', '#05bcb0'), [0, 1.3, 0], [1.5, 1.5, 0.4]).material.transparent = true;
      height = 1.8; width = 1.0;
    }
    mesh.position.set(x, 0, z); mesh.rotation.y = Math.PI;
    this.objectRoot.add(mesh);
    const id = `${this.runId}-object-${++this.objectSequence}`;
    const entry: SpawnedObject = { id, kind, lane, z, mesh, resolved: false, width, height, style, damage };
    this.spawned.push(entry);
    return id;
  }

  private updateSpawnedObjects(distanceDeltaMeters: number, dt: number): void {
    const speed = this.speed;
    for (const object of [...this.spawned]) {
      object.z += distanceDeltaMeters; object.mesh.position.z = object.z;
      object.mesh.rotation.y += dt * (object.kind.startsWith('heart-') || object.kind === 'coin' ? 1.3 : 0);
      if (object.kind.startsWith('heart-') || object.kind === 'coin') object.mesh.position.y = Math.sin(this.runDuration * 3 + object.z) * 0.08;
      if (!object.resolved && object.z >= -0.55 && object.z <= 1.1) {
        if (Math.abs(this.player.root.position.x - LANES[object.lane]) <= 0.77) {
          object.resolved = true;
          this.resolveCollision(object);
        }
      }
      if (object.z > 10 || object.resolved) this.removeSpawned(object);
    }
    this.spawned = this.spawned.filter((object) => object.mesh.parent === this.objectRoot && !object.resolved && object.z < 11);
    const hardCap = this.settings.quality === 'low' || this.mobileRuntime && this.renderScale < 0.8 ? 36 : 45;
    if (this.spawned.length > hardCap) {
      for (const object of this.spawned.slice(0, this.spawned.length - hardCap)) this.removeSpawned(object);
      this.spawned = this.spawned.slice(-hardCap);
    }
  }

  private resolveCollision(object: SpawnedObject): void {
    if (this.collectedIds.has(object.id)) return;
    this.collectedIds.add(object.id);
    const flying = this.powers.flight > 0;
    const jumping = this.player.animation === 'jump';
    const sliding = this.player.animation === 'slide';
    const safeGroundMotion = flying || jumping;
    if (object.kind === 'coin') {
      this.coins += 5; this.audio.pickup(); this.emit({ type: 'toast', message: '+5 COINS', tone: 'success' }); this.updateMission(); return;
    }
    if (object.kind.startsWith('heart-')) {
      this.hearts += 1; this.audio.pickup(); this.haptic(10);
      if (object.kind === 'heart-flight') {
        this.powers.flight = GAME_RULES.flightDuration; this.activePower = 'flight'; this.player.setAnimation('flight-takeoff', 0.45);
        this.emit({ type: 'toast', message: 'GOLDEN HEART — FLIGHT ACTIVATED', tone: 'success' }); this.audio.powerUp();
      } else if (object.kind === 'heart-life') {
        const lifeResult = awardLife(this.lives, 1, GAME_RULES.maxLives); this.lives = lifeResult.lives;
        this.emit({ type: 'toast', message: lifeResult.added ? '+1 EXTRA LIFE' : 'LIFE LIMIT REACHED', tone: lifeResult.added ? 'success' : 'info' });
      } else {
        this.powers.speed = GAME_RULES.speedBoostDuration; this.activePower = 'speed';
        this.player.setSpeedTrail(this.settings.effects);
        this.emit({ type: 'toast', message: 'GREEN HEART — 2× SPEED', tone: 'success' }); this.audio.powerUp();
      }
      this.updateMission(); this.emitHud(true); return;
    }
    if (object.kind === 'civilian') {
      if (['stumble', 'damage', 'gameover', 'jump', 'slide', 'flight', 'flight-takeoff', 'flight-landing'].includes(this.player.animation)) {
        this.emit({ type: 'toast', message: 'RESCUE MISSED — GET BACK ON YOUR FEET', tone: 'warning' }); return;
      }
      this.rescues += 1; this.coins += 15; this.audio.rescue();
      const voiceAvailable = this.audio.queueVoice('rescue');
      this.haptic([14, 24, 14]);
      this.player.setAnimation('rescue', 0.65);
      this.emit({ type: 'toast', message: voiceAvailable ? 'CIVILIAN RESCUED! +15 COINS • “Thank you!”' : 'CIVILIAN RESCUED! +15 COINS', tone: 'success' });
      this.updateMission(); this.emitHud(true); return;
    }
    if (object.kind === 'grey' || object.kind === 'red-black') {
      const safelyAvoided = (object.style === 'low' && safeGroundMotion) || (object.style === 'overhead' && sliding);
      if (safelyAvoided) return;
      const hit = applyObstacleHit({ obstacleType: object.kind, lives: this.lives, damage: object.damage, invulnerable: this.invulnerability > 0, stumbling: this.player.animation === 'stumble' });
      if (hit.outcome === 'stumble') {
        this.player.setAnimation('stumble', GAME_RULES.stumbleDuration); this.audio.stumble(); this.haptic(18); this.emit({ type: 'toast', message: 'BARRIER HIT — RECOVER!', tone: 'warning' });
      } else if (hit.outcome === 'damage') {
        this.lives = hit.lives; this.invulnerability = GAME_RULES.damageCooldown; this.player.setAnimation('damage', 0.45); this.audio.impact(); this.haptic(35);
        this.emit({ type: 'toast', message: 'DAMAGE TAKEN — −1 LIFE', tone: 'danger' });
      } else if (hit.outcome === 'gameover') {
        this.lives = 0; this.audio.impact(); this.finishRun();
      }
      this.emitHud(true); return;
    }
    if (['car', 'motorcycle', 'truck'].includes(object.kind)) {
      const vehicleSafe = object.kind !== 'truck' && (jumping || flying || sliding);
      if (vehicleSafe) return;
      const hit = applyObstacleHit({ obstacleType: 'vehicle', lives: this.lives, damage: object.damage ?? 1, invulnerable: this.invulnerability > 0, stumbling: this.player.animation === 'stumble' });
      if (hit.outcome === 'ignored') return;
      this.lives = hit.lives; this.invulnerability = GAME_RULES.damageCooldown; this.player.setAnimation('damage', 0.55); this.audio.impact(); this.haptic(40);
      this.emit({ type: 'toast', message: `${object.kind.toUpperCase()} COLLISION — −${hit.damage} LIFE`, tone: 'danger' });
      this.emitHud(true);
      if (hit.outcome === 'gameover' || this.lives <= 0) this.finishRun();
    }
  }

  private removeSpawned(object: SpawnedObject): void {
    if (object.mesh.parent) object.mesh.parent.remove(object.mesh);
    disposeObjectTree(object.mesh);
    object.resolved = true;
  }

  private clearSpawnedObjects(): void {
    for (const object of this.spawned) {
      if (object.mesh.parent) object.mesh.parent.remove(object.mesh);
      disposeObjectTree(object.mesh);
    }
    this.spawned = [];
    this.objectRoot.clear();
  }

  private updateMission(): void {
    const status = this.missions.update({ distance: this.distance, rescues: this.rescues, hearts: this.hearts, lives: this.lives });
    this.emit({ type: 'mission', missionId: status.mission.id, progress: status.progress, target: status.target, complete: status.complete, title: status.mission.title });
  }

  private emitHud(force = false): void {
    if (!force && this.state !== 'running') return;
    const mission = this.missions.update({ distance: this.distance, rescues: this.rescues, hearts: this.hearts, lives: this.lives });
    const stats: RunStats = {
      distance: Math.floor(this.distance), lives: this.lives, rescues: this.rescues, coins: this.coins, gems: this.gems, hearts: this.hearts,
      duration: Math.floor(this.runDuration), speed: Math.round(this.speed * 100) / 100, baseSpeed: Math.round(this.baseSpeed * 100) / 100,
      activePower: this.activePower, powerRemaining: this.activePower === 'flight' ? this.powers.flight : this.activePower === 'speed' ? this.powers.speed : 0,
      lane: this.player.lane, missionId: mission.mission.id, missionProgress: mission.progress, missionTarget: mission.target, missionComplete: mission.complete,
    };
    this.emit({ type: 'hud', stats });
  }

  private finishRun(): void {
    if (this.state === 'gameover' || this.runSettled || !this.runId) return;
    this.runSettled = true; this.state = 'gameover'; this.player.setAnimation('gameover'); this.audio.pause();
    const mission = this.missions.update({ distance: this.distance, rescues: this.rescues, hearts: this.hearts, lives: this.lives });
    const result: GameResult = {
      runId: this.runId, mapId: this.selectedMap, distance: Math.floor(this.distance), rescues: this.rescues,
      coins: this.coins, gems: this.gems, hearts: this.hearts, duration: Math.floor(this.runDuration),
      missionId: mission.mission.id, missionComplete: mission.complete, lives: this.lives,
    };
    this.emit({ type: 'state', state: this.state }); this.emit({ type: 'gameover', result });
  }

  private installTestApi(): void {
    const target = window as unknown as { __MRRAWBEAN_TEST__?: Record<string, unknown> };
    target.__MRRAWBEAN_TEST__ = {
      getState: () => this.state,
      getMap: () => this.selectedMap,
      getStats: () => ({ distance: this.distance, lives: this.lives, rescues: this.rescues, coins: this.coins, gems: this.gems, hearts: this.hearts, duration: this.runDuration, activePower: this.activePower, powerRemaining: this.activePower === 'flight' ? this.powers.flight : this.powers.speed, lane: this.player.lane, animation: this.player.animation, spawned: this.spawned.length }),
      getSceneInfo: () => ({ children: this.environment?.root.children.length ?? 0, sceneId: this.mapDefinition.id }),
      action: (action: GameAction) => this.action(action),
      setDistance: (value: number) => { this.distance = Math.max(0, value); this.emitHud(true); },
      scenario: (kind: SpawnKind, lane = 1, ahead = 5) => this.spawnScenario(kind, lane, ahead),
      setLives: (value: number) => { this.lives = Math.max(0, Math.min(GAME_RULES.maxLives, Math.floor(value))); this.emitHud(true); },
      setState: (state: GameState) => { this.state = state; this.emit({ type: 'state', state }); },
      finish: () => this.finishRun(),
      collect: (kind: SpawnKind) => { this.resolveCollision({ id: `test-${kind}-${Date.now()}`, kind, lane: this.player.lane, z: 0, mesh: new THREE.Group(), resolved: false, width: 1, height: 1, damage: 1 }); },
      reset: () => { this.startRun(); },
      seedRandom: (seed: number) => { this.randomState = (Math.floor(seed) >>> 0) || 1; },
    };
  }

  dispose(): void {
    cancelAnimationFrame(this.frameHandle);
    window.removeEventListener('resize', this.resize);
    document.removeEventListener('visibilitychange', this.visibilityHandler);
    window.removeEventListener('contextmenu', this.contextMenuHandler);
    this.canvas.removeEventListener('webglcontextlost', this.contextLostHandler);
    this.canvas.removeEventListener('webglcontextrestored', this.contextRestoredHandler);
    this.clearSpawnedObjects();
    if (this.environment) { this.scene.remove(this.environment.root); disposeObjectTree(this.environment.root); this.environment = null; }
    this.player.dispose(); this.audio.dispose(); this.renderer.dispose();
  }
}
