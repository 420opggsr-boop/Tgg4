import { App } from './app/App';
import './styles/main.css';

const retryButton = document.getElementById('compat-retry');
retryButton?.addEventListener('click', () => window.location.reload());

const app = new App();
window.addEventListener('pagehide', () => app.dispose(), { once: true });

if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./service-worker.js', { scope: './' })
      .catch((error) => console.warn('Offline caching unavailable:', error));
  }, { once: true });
}
