import { Game, type GameEvent, type GameResult, type RunStats } from '../game/Game';
import { MAPS } from '../maps/MapRegistry';
import { MISSIONS, getMission } from '../game/MissionManager';
import { SaveManager } from '../save/SaveManager';
import type { SaveData } from '../save/SaveSchema';
import { TouchControls } from '../input/TouchControls';
import { AudioManager } from '../game/AudioManager';

 type DeferredInstallPrompt = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }> };
 type Screen = 'home' | 'maps' | 'records' | 'shop' | 'missions' | 'settings' | 'name' | 'exit' | 'hud' | 'pause' | 'results';
 type Cosmetic = { id: string; name: string; description: string; color: string; price: number };
 const COSMETICS: readonly Cosmetic[] = [
  { id: 'cape-royal', name: 'ROYAL BLUE CAPE', description: 'The classic hero look. Included with your suit.', color: '#102e9b', price: 0 },
  { id: 'cape-magenta', name: 'NEON MAGENTA CAPE', description: 'A vivid purple-pink energy finish.', color: '#d52ae8', price: 250 },
  { id: 'cape-emerald', name: 'EMERALD CAPE', description: 'A bright green glow for the moonlit city.', color: '#00d78c', price: 350 },
  { id: 'cape-gold', name: 'GOLDEN LEGEND CAPE', description: 'A warm gold finish for elite runners.', color: '#efad2c', price: 600 },
 ];

 const esc = (value: unknown): string => String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char] ?? char));
 const number = (value: number): string => Math.max(0, Math.floor(value)).toLocaleString();
 const distanceLabel = (value: number): string => value >= 1000 ? `${(value / 1000).toFixed(2)} km` : `${Math.floor(value)} m`;

 export class App {
  readonly saves = new SaveManager();
  game: Game | null = null;
  private root: HTMLElement;
  private screen: Screen = 'home';
  private lastStats: RunStats | null = null;
  private lastResult: GameResult | null = null;
  private lastMissionReward: { coins: number; gems: number; paid: boolean } | null = null;
  private toastTimer = 0;
  private checkpointTimer = 0;
  private pendingCheckpoints: number[] = [];
  private checkpointNoticeActive = false;
  private touchControls: TouchControls | null = null;
  private missingRenderer = false;
  private installPrompt: DeferredInstallPrompt | null = null;
  private beforeInstallHandler = (event: Event) => { event.preventDefault(); this.installPrompt = event as DeferredInstallPrompt; };
  private installedHandler = () => { this.installPrompt = null; this.showToast('MRRAWBEAN SPEEDSTER INSTALLED • OFFLINE PLAY AVAILABLE AFTER FIRST LOAD', 'success'); };
  private clickHandler = (event: MouseEvent) => this.handleClick(event);
  private changeHandler = (event: Event) => this.handleChange(event);
  private inputHandler = (event: Event) => this.handleInput(event);
  private submitHandler = (event: SubmitEvent) => this.handleSubmit(event);

  constructor() {
    const root = document.getElementById('app-ui');
    if (!root) throw new Error('Missing #app-ui mount element.');
    this.root = root;
    this.root.addEventListener('click', this.clickHandler);
    this.root.addEventListener('change', this.changeHandler);
    this.root.addEventListener('input', this.inputHandler);
    this.root.addEventListener('submit', this.submitHandler);
    window.addEventListener('beforeinstallprompt', this.beforeInstallHandler);
    window.addEventListener('appinstalled', this.installedHandler);
    try {
      const canvas = document.getElementById('game-canvas');
      if (!(canvas instanceof HTMLCanvasElement)) throw new Error('Missing game canvas.');
      this.game = new Game(canvas, (gameEvent) => this.handleGameEvent(gameEvent));
      this.touchControls = new TouchControls(document.getElementById('game-root')!, this.game, this.saves.get().settings.swipeSensitivity);
      this.game.audio.configure(this.saves.get());
      this.applySettings();
      this.applyCosmetic();
      if (this.game.currentMap !== this.saves.get().selectedMap) this.game.loadMap(this.saves.get().selectedMap);
      this.renderHome();
    } catch (error) {
      console.error('Game startup failed:', error);
      this.missingRenderer = true;
      const fallback = document.getElementById('compatibility');
      if (fallback) fallback.removeAttribute('hidden');
      this.root.innerHTML = `<section class="compat-card"><span class="eyebrow">MRRAWBEAN SPEEDSTER</span><h1>3D RENDERER UNAVAILABLE</h1><p>This browser or device could not initialize the WebGL renderer. Try a current Chromium, Firefox, or Safari browser with hardware acceleration enabled.</p><p class="muted">Technical detail: ${esc(error instanceof Error ? error.message : 'Unknown renderer error')}</p><button class="primary-button" data-action="reload">RELOAD APP</button></section>`;
    }
  }

  private handleGameEvent(event: GameEvent): void {
    switch (event.type) {
      case 'state':
        if (event.state === 'running') { document.getElementById('game-root')?.classList.add('is-playing'); this.screen = 'hud'; this.renderHud(); }
        else if (event.state === 'paused') { this.screen = 'pause'; this.renderPause(); }
        else if (event.state === 'menu') { document.getElementById('game-root')?.classList.remove('is-playing'); this.screen = 'home'; this.renderHome(); }
        break;
      case 'hud':
        this.lastStats = event.stats;
        if (this.screen === 'hud') this.updateHud(event.stats);
        break;
      case 'toast': this.showToast(event.message, event.tone ?? 'info'); break;
      case 'map-loaded': this.saves.setSelectedMap(event.mapId); break;
      case 'map-error': this.showToast(`MAP FAILED: ${event.message}`, 'danger'); break;
      case 'checkpoint':
        this.pendingCheckpoints.push(event.meters);
        if (!this.checkpointNoticeActive) this.showNextCheckpointNotice(event.voiceAvailable);
        break;
      case 'mission':
        if (this.screen === 'hud') {
          const progress = document.getElementById('hud-mission-progress');
          const label = document.getElementById('hud-mission-label');
          const bar = document.getElementById('hud-mission-bar');
          if (progress) progress.textContent = `${number(event.progress)} / ${number(event.target)}`;
          if (label) label.textContent = event.complete ? `${event.title} • COMPLETE` : event.title;
          if (bar) bar.style.width = `${Math.min(100, event.target ? event.progress / event.target * 100 : 0)}%`;
        }
        break;
      case 'gameover': this.settleResult(event.result); break;
    }
  }

  private handleClick(event: MouseEvent): void {
    const target = event.target instanceof Element ? event.target : null;
    if (!target) return;
    const mapButton = target.closest<HTMLElement>('[data-map-id]');
    if (mapButton) {
      const id = mapButton.dataset.mapId;
      if (id && this.game?.loadMap(id)) { this.saves.setSelectedMap(id as SaveData['selectedMap']); this.renderMaps(); this.game.audio.uiClick(); }
      return;
    }
    const missionButton = target.closest<HTMLElement>('[data-mission-id]');
    if (missionButton) {
      const id = missionButton.dataset.missionId;
      if (id && getMission(id)) {
        const saved = this.saves.get();
        if (saved.completedMissions.includes(id)) { this.showToast('MISSION ALREADY COMPLETED — NO DUPLICATE REWARD', 'info'); return; }
        this.saves.setActiveMission(id);
        this.game?.setMission(id);
        this.renderMissions();
        this.game?.audio.uiClick();
      }
      return;
    }
    const itemButton = target.closest<HTMLElement>('[data-cosmetic-id]');
    if (itemButton) { this.buyOrEquipCosmetic(itemButton.dataset.cosmeticId ?? ''); return; }

    const actionButton = target.closest<HTMLElement>('[data-action]');
    if (!actionButton) return;
    const action = actionButton.dataset.action;
    this.game?.audio.uiClick();
    switch (action) {
      case 'home': this.game?.returnHome(); this.screen = 'home'; this.renderHome(); break;
      case 'maps': this.screen = 'maps'; this.renderMaps(); break;
      case 'records': this.screen = 'records'; this.renderRecords(); break;
      case 'shop': case 'store-info': this.screen = 'shop'; this.renderShop(); if (action === 'store-info') this.showToast('OFFLINE COSMETIC SHOP — NO REAL-MONEY PURCHASES', 'info'); break;
      case 'missions': this.screen = 'missions'; this.renderMissions(); break;
      case 'settings': this.screen = 'settings'; this.renderSettings(); break;
      case 'name': this.screen = 'name'; this.renderNameDialog(); break;
      case 'exit': this.screen = 'exit'; this.renderExit(); break;
      case 'name-cancel': this.screen = 'home'; this.renderHome(); break;
      case 'name-save': this.saveName(); break;
      case 'start': this.startPlay(); break;
      case 'install': void this.installApp(); break;
      case 'pause': this.game?.pause(); break;
      case 'resume': this.game?.resume(); break;
      case 'restart': this.startPlay(true); break;
      case 'jump': this.game?.action('jump'); break;
      case 'slide': this.game?.action('slide'); break;
      case 'lane-left': this.game?.action('left'); break;
      case 'lane-right': this.game?.action('right'); break;
      case 'exit-cancel': this.screen = 'home'; this.renderHome(); break;
      case 'reload': window.location.reload(); break;
      case 'settings-save': this.commitSettings(); this.screen = 'home'; this.renderHome(); break;
      case 'settings-defaults': this.saves.updateSettings({ quality: typeof navigator !== 'undefined' && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent) ? 'medium' : 'high', fps: 60, shadows: !(typeof navigator !== 'undefined' && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent)), effects: true, motionEffects: true, audio: { sfx: 0.75, voices: 0.85, ui: 0.7, vibration: true }, swipeSensitivity: 42, vibration: true, music: false }); this.applySettings(); this.renderSettings(); this.showToast('DEFAULT SETTINGS RESTORED • MUSIC REMAINS DISABLED', 'success'); break;
      case 'retry': this.startPlay(true); break;
      case 'results-home': this.game?.returnHome(); this.screen = 'home'; this.renderHome(); break;
      case 'mission-start': this.startPlay(); break;
    }
  }

  private handleChange(event: Event): void {
    const target = event.target;
    if (!(target instanceof HTMLInputElement || target instanceof HTMLSelectElement)) return;
    if (target.matches('[data-setting]')) this.commitSettings();
  }

  private handleInput(event: Event): void {
    const target = event.target;
    if (!(target instanceof HTMLInputElement)) return;
    if (target.name === 'swipeSensitivity') {
      const output = this.root.querySelector<HTMLElement>('[data-sensitivity-output]');
      if (output) output.textContent = `${target.value}px`;
      this.touchControls?.setSensitivity(Number(target.value));
    }
    if (target.matches('[data-setting]') && target.type !== 'range') this.commitSettings();
  }

  private handleSubmit(event: SubmitEvent): void {
    const form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    if (form.id === 'name-form') { event.preventDefault(); this.saveName(); }
  }

  private startPlay(restart = false): void {
    if (!this.game) return;
    const data = this.saves.get();
    this.game.applySettings(data.settings);
    if (this.game.currentMap !== data.selectedMap) this.game.loadMap(data.selectedMap);
    this.game.setMission(data.activeMissionId);
    this.lastResult = null; this.lastMissionReward = null;
    if (restart) this.game.restart(); else this.game.startRun();
  }

  private settleResult(result: GameResult): void {
    this.lastResult = result;
    const record = {
      id: result.runId,
      date: new Date().toISOString(),
      mapId: result.mapId,
      distance: result.distance,
      rescues: result.rescues,
      coins: result.coins,
      gems: result.gems,
      duration: result.duration,
      missionId: result.missionId,
    };
    const xp = Math.floor(result.distance / 8) + result.rescues * 20;
    const settlement = this.saves.settleRun(record, xp);
    let paidCoins = 0; let paidGems = 0; let paid = false;
    if (result.missionComplete) {
      const mission = getMission(result.missionId);
      if (mission) {
        paid = this.saves.completeMission(mission.id, mission.rewardCoins, mission.rewardGems);
        if (paid) { paidCoins = mission.rewardCoins; paidGems = mission.rewardGems; }
      }
    }
    this.lastMissionReward = { coins: paidCoins, gems: paidGems, paid };
    if (settlement.ok) this.showToast(settlement.levelUp ? 'LEVEL UP!' : 'RUN SAVED TO RECORD HISTORY', 'success');
    this.screen = 'results'; this.renderResults(result);
  }

  private applySettings(): void {
    const saved = this.saves.get();
    this.game?.applySettings(saved.settings);
    this.game?.audio.configure(saved);
    this.touchControls?.setSensitivity(saved.settings.swipeSensitivity);
  }

  private applyCosmetic(): void {
    const save = this.saves.get();
    const item = COSMETICS.find((candidate) => candidate.id === save.equippedCosmeticId) ?? COSMETICS[0];
    this.game?.player.setCapeColor(item.color);
  }

  private buyOrEquipCosmetic(id: string): void {
    const item = COSMETICS.find((candidate) => candidate.id === id);
    if (!item) { this.showToast('ITEM NOT FOUND', 'danger'); return; }
    let save = this.saves.get();
    const owned = id === 'cape-royal' || save.ownedItems.some((candidate) => candidate.id === id);
    if (!owned) {
      const result = this.saves.buyItem(id, item.price, 'coins');
      if (!result.ok) { this.showToast(result.reason ?? 'Purchase failed.', 'warning'); this.renderShop(); return; }
      save = this.saves.get();
      this.showToast(`${item.name} UNLOCKED`, 'success');
    }
    this.saves.equipCosmetic(id);
    this.applyCosmetic();
    this.renderShop();
  }

  private saveName(): void {
    const input = this.root.querySelector<HTMLInputElement>('#player-name');
    if (!input) return;
    const value = input.value.trim();
    if (!this.saves.updateName(value)) {
      const message = this.root.querySelector<HTMLElement>('#name-error');
      if (message) message.textContent = 'Use 3–16 letters, numbers, spaces, underscores or hyphens.';
      input.setAttribute('aria-invalid', 'true');
      return;
    }
    this.screen = 'home'; this.renderHome(); this.showToast('HERO NAME UPDATED', 'success');
  }

  private commitSettings(): void {
    const get = <T extends HTMLInputElement | HTMLSelectElement>(name: string): T | null => this.root.querySelector<T>(`[name="${name}"]`);
    const quality = get('quality')?.value ?? 'medium';
    const fps = Number(get('fps')?.value ?? 60);
    const sfx = Number(get<HTMLInputElement>('sfx-volume')?.value ?? 75) / 100;
    const voices = Number(get<HTMLInputElement>('voice-volume')?.value ?? 85) / 100;
    const ui = Number(get<HTMLInputElement>('ui-volume')?.value ?? 70) / 100;
    const sensitivity = Number(get<HTMLInputElement>('swipeSensitivity')?.value ?? 42);
    this.saves.updateSettings({
      quality: quality === 'low' || quality === 'high' ? quality : 'medium',
      fps: fps === 30 ? 30 : 60,
      shadows: get<HTMLInputElement>('shadows')?.checked ?? true,
      effects: get<HTMLInputElement>('effects')?.checked ?? true,
      motionEffects: get<HTMLInputElement>('motionEffects')?.checked ?? true,
      vibration: get<HTMLInputElement>('vibration')?.checked ?? true,
      swipeSensitivity: sensitivity,
      audio: { sfx, voices, ui, vibration: get<HTMLInputElement>('vibration')?.checked ?? true },
      music: false,
    });
    this.applySettings();
  }

  private renderHome(): void {
    document.getElementById('game-root')?.classList.remove('is-playing');
    this.root.className = 'screen-layer';
    const save = this.saves.get();
    const levelProgress = Math.min(100, Math.max(0, save.experience % Math.max(1, save.level * save.level * 100) / Math.max(1, save.level * save.level * 100) * 100));
    const selected = MAPS.find((map) => map.id === save.selectedMap) ?? MAPS[0];
    this.root.innerHTML = `
      <section class="home-screen" aria-label="Home menu">
        <header class="profile-bar glass-panel">
          <img class="profile-avatar" src="./icons/profile-avatar.webp" alt="Hero avatar" />
          <div class="profile-copy"><div class="player-name-line"><span class="crown" aria-hidden="true">♛</span><strong data-profile-name>${esc(save.playerName)}</strong></div><div class="level-line">LV. ${save.level}<span class="xp-track"><i style="width:${levelProgress}%"></i></span></div></div>
          <div class="wallet"><div class="wallet-item"><span class="coin-icon">S</span><b data-coins>${number(save.coins)}</b><button data-action="store-info" class="wallet-plus" aria-label="Coin store information">+</button></div><div class="wallet-item"><span class="gem-icon">◆</span><b data-gems>${number(save.gems)}</b><button data-action="store-info" class="wallet-plus" aria-label="Gem store information">+</button></div></div>
          <button class="icon-button exit-icon" data-action="exit" aria-label="Exit game">↗</button>
        </header>
        <section class="hero-banner">
          <div class="hero-title-block"><div class="title-crown">♛</div><h1><span>MRRAWBEAN</span><b>SUPERHERO</b><em>SPEEDSTER</em></h1><p>RUN <i>•</i> RESCUE <i>•</i> SAVE <i>•</i> BE A HERO</p></div>
          <div class="hero-character-frame"><img src="./character-reference.webp" alt="MrRawBean superhero concept portrait" /></div>
          <div class="hero-map-caption"><span class="pulse-dot"></span><span>${esc(selected.name)}</span></div>
        </section>
        <div class="main-menu-grid">
          <button class="menu-card card-blue map-menu-card" data-action="maps"><img src="${selected.thumbnail}" alt=""/><span class="card-icon">⌖</span><span class="card-copy"><b>MAP SELECTION</b><small>CHOOSE YOUR CITY & LOCATION</small></span><strong class="chevrons">»</strong></button>
          <button class="menu-card card-purple" data-action="records"><div class="card-art record-art"><span>🏆</span><i>▤</i></div><span class="card-icon">◴</span><span class="card-copy"><b>RECORD HISTORY</b><small>VIEW YOUR BEST RUNS</small></span><strong class="chevrons">»</strong></button>
          <button class="menu-card card-pink" data-action="shop"><div class="card-art gem-art"><span>◇</span><i>◆ ◆</i></div><span class="card-icon">◇</span><span class="card-copy"><b>GEM FOR BUY</b><small>GET SUPER ITEMS</small></span><strong class="chevrons">»</strong></button>
          <button class="menu-card card-orange" data-action="missions"><div class="card-art speed-art"><span>⚡</span><i>➤</i></div><span class="card-icon">ϟ</span><span class="card-copy"><b>QUICK MISSION</b><small>RUN FASTER, SAVE MORE</small></span><strong class="chevrons">»</strong></button>
          <button class="menu-card small-card card-cyan" data-action="settings"><span class="large-icon">⚙</span><b>GRAPHICS SETTINGS</b><small>CUSTOMIZE YOUR EXPERIENCE</small></button>
          <button class="menu-card small-card card-cyan" data-action="name"><span class="large-icon">✎</span><b>CHANGE NAME</b><small>SET YOUR NEW NAME</small></button>
          <button class="start-button" data-action="start"><span class="play-triangle">▶</span><span><b>START PLAY</b><small>BEGIN YOUR HERO JOURNEY</small></span><span class="start-sheen"></span></button>
        </div>
        <footer class="hero-footer"><span></span><b>BE A HERO</b><span></span></footer>
        <button class="install-offline-button" data-action="install">⬇ INSTALL OFFLINE APP</button>
      </section>`;
    this.root.classList.remove('is-playing');
  }

  private async installApp(): Promise<void> {
    if (!this.installPrompt) {
      this.showToast('ANDROID: OPEN CHROME ⋮ → INSTALL APP / ADD TO HOME SCREEN. LOAD THE GAME ONCE BEFORE PLAYING OFFLINE.', 'info');
      return;
    }
    const prompt = this.installPrompt;
    this.installPrompt = null;
    try {
      await prompt.prompt();
      const result = await prompt.userChoice;
      this.showToast(result.outcome === 'accepted' ? 'INSTALL PROMPT ACCEPTED • OPEN THE APP ONCE TO CACHE ALL FILES' : 'INSTALL CANCELLED • YOU CAN INSTALL FROM THE BROWSER MENU', result.outcome === 'accepted' ? 'success' : 'info');
    } catch {
      this.showToast('INSTALL PROMPT UNAVAILABLE • USE CHROME MENU → ADD TO HOME SCREEN', 'warning');
    }
  }

  private renderMaps(): void {
    document.getElementById('game-root')?.classList.remove('is-playing');
    const save = this.saves.get();
    this.root.innerHTML = `<section class="menu-screen"><header class="screen-heading"><button class="back-button" data-action="home" aria-label="Back to home">←</button><div><span class="eyebrow">CHOOSE YOUR WORLD</span><h2>MAP SELECTION</h2><p>Each city has its own track, lighting, skyline and atmosphere.</p></div></header><div class="map-grid">${MAPS.map((map, index) => `<button class="map-card ${save.selectedMap === map.id ? 'selected' : ''}" data-map-id="${map.id}" aria-pressed="${save.selectedMap === map.id}"><img src="${map.thumbnail}" alt="${esc(map.name)} environment" loading="lazy"><span class="map-number">${String(index + 1).padStart(2, '0')}</span><span class="map-card-copy"><b>${esc(map.name)}</b><small>${esc(map.subtitle)}</small></span><span class="map-select-check">${save.selectedMap === map.id ? '✓ SELECTED' : 'SELECT MAP'}</span></button>`).join('')}</div><button class="primary-button wide-button" data-action="start">START ${esc((MAPS.find((x) => x.id === save.selectedMap) ?? MAPS[0]).name)} →</button></section>`;
    this.root.classList.remove('is-playing');
  }

  private renderRecords(): void {
    document.getElementById('game-root')?.classList.remove('is-playing');
    const save = this.saves.get();
    const records = [...save.records].sort((a, b) => b.distance - a.distance);
    this.root.innerHTML = `<section class="menu-screen"><header class="screen-heading"><button class="back-button" data-action="home" aria-label="Back to home">←</button><div><span class="eyebrow">YOUR LEGEND</span><h2>RECORD HISTORY</h2><p>Best distance: <strong>${distanceLabel(save.bestDistance)}</strong> · Rescues: <strong>${number(save.rescuedTotal)}</strong></p></div></header>${records.length ? `<div class="record-list">${records.map((record, index) => `<article class="record-row"><span class="record-rank">${index + 1}</span><div><b>${esc(MAPS.find((map) => map.id === record.mapId)?.name ?? record.mapId)}</b><small>${new Date(record.date).toLocaleString()} · ${record.rescues} rescues</small></div><strong>${distanceLabel(record.distance)}</strong><span class="record-rewards">+${record.coins} coins</span></article>`).join('')}</div>` : `<div class="empty-state"><div class="empty-emblem">◴</div><h3>NO RUNS RECORDED YET</h3><p>Your best distance, rescues, run rewards and chosen map will appear here after your first run.</p><button class="primary-button" data-action="start">RUN YOUR FIRST MISSION</button></div>`}<div class="summary-strip"><span>LEVEL <b>${save.level}</b></span><span>COINS <b>${number(save.coins)}</b></span><span>GEMS <b>${number(save.gems)}</b></span></div></section>`;
    this.root.classList.remove('is-playing');
  }

  private renderShop(): void {
    document.getElementById('game-root')?.classList.remove('is-playing');
    const save = this.saves.get();
    this.root.innerHTML = `<section class="menu-screen"><header class="screen-heading"><button class="back-button" data-action="home" aria-label="Back to home">←</button><div><span class="eyebrow">OFFLINE COSMETICS</span><h2>SUPER ITEM SHOP</h2><p>Unlock cape colors with earned coins. No real-money purchases or external store.</p></div></header><div class="shop-wallet"><span>🟡 COINS <b>${number(save.coins)}</b></span><span>◆ GEMS <b>${number(save.gems)}</b></span></div><div class="shop-grid">${COSMETICS.map((item) => { const owned = item.id === 'cape-royal' || save.ownedItems.some((x) => x.id === item.id); const equipped = save.equippedCosmeticId === item.id; return `<article class="shop-item ${equipped ? 'equipped' : ''}"><div class="cape-preview" style="--cape:${item.color}"><span class="cape-shape"></span><i>♛</i></div><div class="shop-item-copy"><b>${esc(item.name)}</b><p>${esc(item.description)}</p><small>${item.price === 0 ? 'FREE' : `${item.price} COINS`}</small></div><button class="secondary-button" data-cosmetic-id="${item.id}" ${equipped ? 'disabled' : ''}>${equipped ? 'EQUIPPED' : owned ? 'EQUIP' : 'UNLOCK'}</button></article>`; }).join('')}</div><div class="notice-line"><span>ⓘ</span><p>Items only change cape colors. Currency is earned in-game; this shop has no payments, ads, or external transaction system.</p></div></section>`;
    this.root.classList.remove('is-playing');
  }

  private renderMissions(): void {
    document.getElementById('game-root')?.classList.remove('is-playing');
    const save = this.saves.get();
    this.root.innerHTML = `<section class="menu-screen"><header class="screen-heading"><button class="back-button" data-action="home" aria-label="Back to home">←</button><div><span class="eyebrow">DO GOOD AT HIGH SPEED</span><h2>QUICK MISSIONS</h2><p>Select one active objective. Mission rewards are granted once, after a run ends.</p></div></header><div class="mission-list">${MISSIONS.map((mission) => { const completed = save.completedMissions.includes(mission.id); const active = save.activeMissionId === mission.id; return `<article class="mission-card ${active ? 'active' : ''} ${completed ? 'completed' : ''}"><div class="mission-icon">${mission.objective === 'distance' || mission.objective === 'survive' ? '↗' : mission.objective === 'rescues' ? '♡' : mission.objective === 'hearts' ? '◆' : '★'}</div><div class="mission-info"><div class="mission-title-line"><b>${esc(mission.title)}</b>${active ? '<span class="mini-tag">ACTIVE</span>' : ''}${completed ? '<span class="mini-tag done">COMPLETED</span>' : ''}</div><p>${esc(mission.description)}</p><small>REWARD · ${mission.rewardCoins} COINS${mission.rewardGems ? ` + ${mission.rewardGems} GEMS` : ''}</small></div><button class="secondary-button" data-mission-id="${mission.id}" ${completed || active ? 'disabled' : ''}>${completed ? 'DONE' : active ? 'SELECTED' : 'SELECT'}</button></article>`; }).join('')}</div><button class="primary-button wide-button" data-action="mission-start">START ACTIVE MISSION →</button></section>`;
    this.root.classList.remove('is-playing');
  }

  private renderSettings(): void {
    document.getElementById('game-root')?.classList.remove('is-playing');
    const settings = this.saves.get().settings;
    this.root.innerHTML = `<section class="menu-screen settings-screen"><header class="screen-heading"><button class="back-button" data-action="home" aria-label="Back to home">←</button><div><span class="eyebrow">TUNE YOUR EXPERIENCE</span><h2>GRAPHICS & SETTINGS</h2><p>Settings save on this device. Background music is never played.</p></div></header><div class="settings-panel"><label class="setting-row"><span><b>Graphics quality</b><small>High uses detailed local surfaces, normal maps and soft shadows. Medium is tuned for phones.</small></span><select name="quality" data-setting><option value="low" ${settings.quality === 'low' ? 'selected' : ''}>Low</option><option value="medium" ${settings.quality === 'medium' ? 'selected' : ''}>Medium</option><option value="high" ${settings.quality === 'high' ? 'selected' : ''}>High</option></select></label><label class="setting-row"><span><b>Frame-rate target</b><small>Rendering target, not a guaranteed FPS.</small></span><select name="fps" data-setting><option value="30" ${settings.fps === 30 ? 'selected' : ''}>30 FPS</option><option value="60" ${settings.fps === 60 ? 'selected' : ''}>60 FPS</option></select></label>${[['shadows','Dynamic shadows',settings.shadows],['effects','Particles and effects',settings.effects],['motionEffects','Camera/motion effects',settings.motionEffects],['vibration','Vibration (where supported)',settings.vibration]].map(([name,label,checked]) => `<label class="setting-row"><span><b>${label}</b><small>Optional visual or device effect.</small></span><input type="checkbox" name="${name}" data-setting ${checked ? 'checked' : ''}></label>`).join('')}<div class="setting-range"><label for="sfx-volume">Sound effects <output>${Math.round(settings.audio.sfx * 100)}%</output></label><input id="sfx-volume" name="sfx-volume" type="range" min="0" max="100" value="${Math.round(settings.audio.sfx * 100)}" data-setting></div><div class="setting-range"><label for="voice-volume">Character & civilian voices <output>${Math.round(settings.audio.voices * 100)}%</output></label><input id="voice-volume" name="voice-volume" type="range" min="0" max="100" value="${Math.round(settings.audio.voices * 100)}" data-setting><small class="muted">Bundled offline speech clips: gentle rescue thanks and the 2 km superhero shout.</small></div><div class="setting-range"><label for="ui-volume">UI sounds <output>${Math.round(settings.audio.ui * 100)}%</output></label><input id="ui-volume" name="ui-volume" type="range" min="0" max="100" value="${Math.round(settings.audio.ui * 100)}" data-setting></div><div class="setting-range"><label for="swipeSensitivity">Swipe threshold <output data-sensitivity-output>${settings.swipeSensitivity}px</output></label><input id="swipeSensitivity" name="swipeSensitivity" type="range" min="22" max="90" value="${settings.swipeSensitivity}" data-setting></div><div class="music-lock"><span>♫</span><div><b>BACKGROUND MUSIC</b><small>Disabled by design — no soundtrack or music loop is included.</small></div><span class="lock-pill">ALWAYS OFF</span></div></div><div class="settings-actions"><button class="secondary-button" data-action="settings-defaults">RESTORE DEFAULTS</button><button class="primary-button" data-action="settings-save">SAVE SETTINGS</button></div></section>`;
    this.root.classList.remove('is-playing');
  }

  private renderNameDialog(): void {
    const name = this.saves.get().playerName;
    this.root.innerHTML = `<section class="dialog-layer"><form id="name-form" class="dialog-card" role="dialog" aria-modal="true" aria-labelledby="name-heading"><span class="eyebrow">HERO IDENTITY</span><h2 id="name-heading">CHANGE NAME</h2><p>Your name appears in the hero profile and is stored locally.</p><label for="player-name">PLAYER NAME</label><input id="player-name" name="playerName" minlength="3" maxlength="16" pattern="[A-Za-z0-9 _-]+" value="${esc(name)}" autocomplete="off" required><small class="muted">3–16 characters · letters, numbers, spaces, _ or -</small><p id="name-error" class="form-error" role="alert"></p><div class="dialog-actions"><button type="button" class="secondary-button" data-action="name-cancel">CANCEL</button><button type="submit" class="primary-button">SAVE NAME</button></div></form></section>`;
    this.root.classList.remove('is-playing');
    this.root.querySelector<HTMLInputElement>('#player-name')?.focus();
  }

  private renderExit(): void {
    this.root.innerHTML = `<section class="dialog-layer"><article class="dialog-card" role="dialog" aria-modal="true"><span class="eyebrow">MISSION CONTROL</span><h2>LEAVE THE RUNNER?</h2><p>For browser safety, this game cannot guarantee it can close the current tab. You can close this browser tab yourself. Your saved progress remains on this device.</p><div class="dialog-actions"><button class="secondary-button" data-action="exit-cancel">STAY HERE</button><button class="primary-button" data-action="exit-cancel">RETURN TO GAME</button></div></article></section>`;
    this.root.classList.remove('is-playing');
  }

  private renderHud(): void {
    document.getElementById('game-root')?.classList.add('is-playing');
    this.root.className = 'screen-layer is-playing';
    const stats = this.lastStats;
    const mission = stats ? getMission(stats.missionId) : getMission(this.saves.get().activeMissionId);
    this.root.innerHTML = `<section class="game-hud" aria-label="Gameplay HUD"><div class="hud-top-row"><div class="hud-chip distance-chip"><small>DISTANCE</small><b data-hud="distance">${number(stats?.distance ?? 0)} m</b></div><div class="hud-chip life-chip"><small>LIVES</small><b data-hud="lives">♥ ♥ ♥</b></div><div class="hud-chip hud-wallet"><small>RUN COINS</small><b data-hud="coins">0</b></div><button class="pause-button" data-action="pause" aria-label="Pause game">Ⅱ</button></div><div class="hud-bottom-panel"><div class="hud-stats"><span>RESCUED <b data-hud="rescues">0</b></span><span>HEARTS <b data-hud="hearts">0</b></span><span>SPEED <b data-hud="speed">13 m/s</b></span></div><div class="power-meter" data-hud="power" hidden><span data-hud="power-name">POWER</span><div><i data-hud="power-bar"></i></div><b data-hud="power-time">0s</b></div><div class="hud-mission"><div><small>ACTIVE MISSION</small><b id="hud-mission-label">${esc(mission?.title ?? 'FIRST FLIGHT')}</b><span id="hud-mission-progress">0 / ${mission?.target ?? 500}</span></div><div class="mission-progress-track"><i id="hud-mission-bar" style="width:${stats && stats.missionTarget ? stats.missionProgress / stats.missionTarget * 100 : 0}%"></i></div></div></div><div class="touch-pad" aria-label="Optional touch controls"><button data-action="lane-left" data-no-swipe aria-label="Move left">←</button><button data-action="jump" data-no-swipe aria-label="Jump">↑ JUMP</button><button data-action="slide" data-no-swipe aria-label="Slide">↓ SLIDE</button><button data-action="lane-right" data-no-swipe aria-label="Move right">→</button></div></section>`;
    this.updateHud(this.lastStats);
  }

  private updateHud(stats: RunStats | null): void {
    if (!stats || this.screen !== 'hud') return;
    const put = (key: string, value: string) => { const node = this.root.querySelector<HTMLElement>(`[data-hud="${key}"]`); if (node) node.textContent = value; };
    put('distance', `${number(stats.distance)} m`);
    put('lives', `${'♥ '.repeat(Math.max(0, stats.lives)).trim()}${stats.lives ? '' : '—'}`);
    put('coins', number(stats.coins)); put('rescues', number(stats.rescues)); put('hearts', number(stats.hearts)); put('speed', `${Math.round(stats.speed)} m/s${stats.activePower === 'speed' ? ' · 2×' : ''}`);
    const power = this.root.querySelector<HTMLElement>('[data-hud="power"]');
    if (power) {
      power.hidden = !stats.activePower;
      put('power-name', stats.activePower === 'flight' ? 'FLIGHT' : stats.activePower === 'speed' ? '2× SPEED' : 'POWER');
      put('power-time', `${stats.powerRemaining.toFixed(1)}s`);
      const bar = this.root.querySelector<HTMLElement>('[data-hud="power-bar"]');
      const duration = stats.activePower === 'flight' ? 8 : 7;
      if (bar) bar.style.width = `${Math.min(100, stats.powerRemaining / duration * 100)}%`;
      if (power) power.classList.toggle('power-speed', stats.activePower === 'speed');
    }
  }

  private renderPause(): void {
    this.root.className = 'screen-layer is-playing';
    this.root.innerHTML = `<section class="overlay-dialog"><article class="dialog-card pause-card" role="dialog" aria-modal="true"><span class="eyebrow">MISSION PAUSED</span><h2>TAKE A BREATHER</h2><p>The simulation, traffic, spawns and gameplay timers are frozen.</p><button class="primary-button wide-button" data-action="resume">▶ RESUME RUN</button><button class="secondary-button wide-button" data-action="restart">↻ RESTART RUN</button><button class="secondary-button wide-button" data-action="results-home">⌂ RETURN HOME</button></article></section>`;
  }

  private renderResults(result: GameResult): void {
    const save = this.saves.get();
    const mission = getMission(result.missionId);
    const reward = this.lastMissionReward;
    this.root.className = 'screen-layer';
    this.root.innerHTML = `<section class="overlay-dialog results-dialog"><article class="dialog-card results-card"><span class="eyebrow">RUN COMPLETE</span><h2>${result.lives <= 0 ? 'HERO DOWN' : 'GREAT RUN, HERO!'}</h2><div class="result-distance">${number(result.distance)}<small>METERS</small></div><div class="result-grid"><div><small>BEST DISTANCE</small><b>${distanceLabel(save.bestDistance)}</b></div><div><small>RESCUED</small><b>${number(result.rescues)}</b></div><div><small>RUN COINS</small><b>+${number(result.coins)}</b></div><div><small>HEARTS</small><b>${number(result.hearts)}</b></div><div><small>LEVEL</small><b>${save.level}</b></div><div><small>LIVES LEFT</small><b>${result.lives}</b></div></div><div class="result-mission ${result.missionComplete ? 'complete' : ''}"><b>${esc(mission?.title ?? 'MISSION')}</b><span>${result.missionComplete ? 'MISSION COMPLETE' : 'MISSION NOT COMPLETE'}</span><small>${reward?.paid ? `Reward paid: ${reward.coins} coins${reward.gems ? ` + ${reward.gems} gems` : ''}` : result.missionComplete ? 'This mission reward was already claimed.' : 'Try again to complete this objective.'}</small></div><button class="primary-button wide-button" data-action="retry">↻ RETRY RUN</button><button class="secondary-button wide-button" data-action="results-home">⌂ HOME</button></article></section>`;
  }

  private showNextCheckpointNotice(voiceAvailable: boolean): void {
    const meters = this.pendingCheckpoints.shift();
    if (meters === undefined) { this.checkpointNoticeActive = false; return; }
    this.checkpointNoticeActive = true;
    const voice = voiceAvailable ? ' • VOICE ANNOUNCEMENT' : ' • VOICE UNAVAILABLE';
    this.showToast(`${number(meters)} M CHECKPOINT — “Yahooo, I am MisterRawBean, The SUPERHERO!”${voice}`, 'success');
    window.clearTimeout(this.checkpointTimer);
    this.checkpointTimer = window.setTimeout(() => this.showNextCheckpointNotice(voiceAvailable), 2450);
  }

  private showToast(message: string, tone: 'info' | 'success' | 'warning' | 'danger' = 'info'): void {
    let toast = this.root.querySelector<HTMLElement>('.game-toast');
    if (!toast) {
      toast = document.createElement('div'); toast.className = 'game-toast'; toast.setAttribute('role', 'status'); this.root.appendChild(toast);
    }
    toast.className = `game-toast tone-${tone}`; toast.textContent = message;
    window.clearTimeout(this.toastTimer);
    this.toastTimer = window.setTimeout(() => toast?.classList.add('toast-hide'), 2400);
  }

  dispose(): void {
    this.root.removeEventListener('click', this.clickHandler);
    this.root.removeEventListener('change', this.changeHandler);
    this.root.removeEventListener('input', this.inputHandler);
    this.root.removeEventListener('submit', this.submitHandler);
    window.removeEventListener('beforeinstallprompt', this.beforeInstallHandler);
    window.removeEventListener('appinstalled', this.installedHandler);
    this.touchControls?.dispose(); this.game?.dispose(); window.clearTimeout(this.toastTimer); window.clearTimeout(this.checkpointTimer);
  }
}
