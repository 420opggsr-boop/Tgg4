import { isMapId } from '../maps/MapRegistry';
import { calculateLevel, isValidPlayerName, isValidPurchase, normalizeSettings } from '../game/logic.js';
import type { MapId } from '../maps/MapRegistry';
import type { RunRecord, SaveData } from './SaveSchema';

const SAVE_KEY = 'mrrawbean.speedster.save';
const CURRENT_VERSION = 2;

export function createDefaultSave(): SaveData {
  return {
    schemaVersion: CURRENT_VERSION,
    playerName: 'MrRawBean',
    level: 1,
    experience: 0,
    coins: 0,
    gems: 0,
    bestDistance: 0,
    selectedMap: 'MAP_01',
    records: [],
    rescuedTotal: 0,
    completedMissions: [],
    activeMissionId: 'distance-500',
    equippedCosmeticId: 'cape-royal',
    ownedItems: [],
    settings: normalizeSettings(),
  };
}

const safeInteger = (value: unknown, fallback = 0, max = 1_000_000_000): number =>
  typeof value === 'number' && Number.isFinite(value) ? Math.min(max, Math.max(0, Math.floor(value))) : fallback;
const safeName = (value: unknown): string => typeof value === 'string' && isValidPlayerName(value) ? value.trim() : 'MrRawBean';

export function sanitizeSave(input: unknown): SaveData {
  const defaults = createDefaultSave();
  if (!input || typeof input !== 'object' || Array.isArray(input)) return defaults;
  const raw = input as Record<string, unknown>;
  const exp = safeInteger(raw.experience, defaults.experience);
  const levelInfo = calculateLevel(exp);
  const records = Array.isArray(raw.records) ? raw.records.slice(0, 50).flatMap((r): RunRecord[] => {
    if (!r || typeof r !== 'object') return [];
    const item = r as Record<string, unknown>;
    if (typeof item.id !== 'string' || !item.id || !isMapId(item.mapId)) return [];
    return [{
      id: item.id.slice(0, 100),
      date: typeof item.date === 'string' && !Number.isNaN(Date.parse(item.date)) ? item.date : new Date(0).toISOString(),
      mapId: item.mapId,
      distance: safeInteger(item.distance),
      rescues: safeInteger(item.rescues),
      coins: safeInteger(item.coins),
      gems: safeInteger(item.gems),
      duration: safeInteger(item.duration),
      ...(typeof item.missionId === 'string' ? { missionId: item.missionId.slice(0, 80) } : {}),
    }];
  }) : [];
  return {
    schemaVersion: CURRENT_VERSION,
    playerName: safeName(raw.playerName),
    level: levelInfo.level,
    experience: exp,
    coins: safeInteger(raw.coins),
    gems: safeInteger(raw.gems),
    bestDistance: safeInteger(raw.bestDistance),
    selectedMap: isMapId(raw.selectedMap) ? raw.selectedMap : defaults.selectedMap,
    records,
    rescuedTotal: safeInteger(raw.rescuedTotal),
    completedMissions: Array.isArray(raw.completedMissions) ? [...new Set(raw.completedMissions.filter((x): x is string => typeof x === 'string').map((x) => x.slice(0, 80)))].slice(0, 200) : [],
    activeMissionId: typeof raw.activeMissionId === 'string' ? raw.activeMissionId.slice(0, 80) : defaults.activeMissionId,
    equippedCosmeticId: typeof raw.equippedCosmeticId === 'string' && /^[a-z0-9-]{2,60}$/i.test(raw.equippedCosmeticId) ? raw.equippedCosmeticId : defaults.equippedCosmeticId,
    ownedItems: Array.isArray(raw.ownedItems) ? raw.ownedItems.flatMap((x) => {
      if (!x || typeof x !== 'object') return [];
      const item = x as Record<string, unknown>;
      if (typeof item.id !== 'string' || !/^[a-z0-9-]{2,60}$/i.test(item.id)) return [];
      return [{ id: item.id, purchasedAt: typeof item.purchasedAt === 'string' ? item.purchasedAt : new Date(0).toISOString() }];
    }).slice(0, 100) : [],
    settings: normalizeSettings(raw.settings && typeof raw.settings === 'object' ? raw.settings as Record<string, any> : {}),
  };
}

export class SaveManager {
  private data: SaveData;
  private storage: Storage | null;
  private writeFailed = false;

  constructor(storage: Storage | null = typeof localStorage !== 'undefined' ? localStorage : null) {
    this.storage = storage;
    this.data = this.load();
  }

  private load(): SaveData {
    if (!this.storage) return createDefaultSave();
    try {
      const serialized = this.storage.getItem(SAVE_KEY);
      if (!serialized) return createDefaultSave();
      const parsed: unknown = JSON.parse(serialized);
      const record = parsed && typeof parsed === 'object' ? parsed as Record<string, unknown> : {};
      if (record.schemaVersion === CURRENT_VERSION) return sanitizeSave(parsed);
      // Up to now, v1 contained the same named scalar progression keys; sanitize performs the migration.
      if (record.schemaVersion === 1) return sanitizeSave(parsed);
      return createDefaultSave();
    } catch {
      try { this.storage.removeItem(SAVE_KEY); } catch { /* storage may be denied */ }
      return createDefaultSave();
    }
  }

  get(): SaveData { return structuredClone(this.data); }
  get persistenceWarning(): boolean { return this.writeFailed; }

  private persist(): void {
    if (!this.storage) return;
    try {
      this.storage.setItem(SAVE_KEY, JSON.stringify(this.data));
      this.writeFailed = false;
    } catch {
      this.writeFailed = true;
    }
  }

  updateName(name: string): boolean {
    if (!isValidPlayerName(name)) return false;
    this.data.playerName = name.trim();
    this.persist();
    return true;
  }

  setSelectedMap(id: MapId): void { this.data.selectedMap = id; this.persist(); }

  setActiveMission(id: string): boolean {
    if (!/^[a-z0-9-]{2,80}$/i.test(id)) return false;
    this.data.activeMissionId = id; this.persist(); return true;
  }

  equipCosmetic(id: string): boolean {
    if (!/^[a-z0-9-]{2,60}$/i.test(id)) return false;
    if (id !== 'cape-royal' && !this.data.ownedItems.some((item) => item.id === id)) return false;
    this.data.equippedCosmeticId = id; this.persist(); return true;
  }

  updateSettings(next: Record<string, unknown>): void {
    this.data.settings = normalizeSettings({ ...this.data.settings, ...next, audio: { ...this.data.settings.audio, ...(next.audio as object || {}) } });
    this.data.settings.music = false;
    this.persist();
  }

  addRunCoins(coins: number): void {
    this.data.coins += safeInteger(coins);
    this.persist();
  }

  addRunGems(gems: number): void {
    this.data.gems += safeInteger(gems);
    this.persist();
  }

  buyItem(id: string, price: number, currency: 'coins' | 'gems' = 'coins'): { ok: boolean; reason?: string } {
    if (!/^[a-z0-9-]{2,60}$/i.test(id) || !Number.isSafeInteger(price) || price < 0) return { ok: false, reason: 'Invalid item or price.' };
    if (this.data.ownedItems.some((item) => item.id === id)) return { ok: false, reason: 'Already owned.' };
    const balance = this.data[currency];
    if (!isValidPurchase({ price, balance, owned: false })) return { ok: false, reason: `Not enough ${currency}.` };
    this.data[currency] = Math.max(0, balance - price);
    this.data.ownedItems.push({ id, purchasedAt: new Date().toISOString() });
    this.persist();
    return { ok: true };
  }

  completeMission(id: string, rewardCoins: number, rewardGems: number): boolean {
    if (!id || this.data.completedMissions.includes(id)) return false;
    if (!Number.isSafeInteger(rewardCoins) || rewardCoins < 0 || !Number.isSafeInteger(rewardGems) || rewardGems < 0) return false;
    this.data.completedMissions.push(id);
    this.data.coins += rewardCoins;
    this.data.gems += rewardGems;
    this.persist();
    return true;
  }

  settleRun(record: RunRecord, xpReward: number): { ok: boolean; newRecord: boolean; levelUp: boolean } {
    if (!record.id || !isMapId(record.mapId) || this.data.records.some((item) => item.id === record.id)) return { ok: false, newRecord: false, levelUp: false };
    const oldLevel = this.data.level;
    this.data.coins += safeInteger(record.coins);
    this.data.gems += safeInteger(record.gems);
    this.data.experience += safeInteger(xpReward);
    this.data.level = calculateLevel(this.data.experience).level;
    this.data.rescuedTotal += safeInteger(record.rescues);
    const newRecord = record.distance > this.data.bestDistance;
    this.data.bestDistance = Math.max(this.data.bestDistance, record.distance);
    this.data.records.unshift({ ...record });
    this.data.records = this.data.records.slice(0, 50);
    this.persist();
    return { ok: true, newRecord, levelUp: this.data.level > oldLevel };
  }

  resetForTests(): void { this.data = createDefaultSave(); this.persist(); }
}
