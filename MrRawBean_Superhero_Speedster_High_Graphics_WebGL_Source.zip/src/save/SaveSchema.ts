import type { MapId } from '../maps/MapRegistry';

export interface RunRecord {
  id: string;
  date: string;
  mapId: MapId;
  distance: number;
  rescues: number;
  coins: number;
  gems: number;
  duration: number;
  missionId?: string;
}

export interface MissionDefinition {
  id: string;
  title: string;
  description: string;
  objective: 'distance' | 'rescues' | 'hearts' | 'survive' | 'lives';
  target: number;
  rewardCoins: number;
  rewardGems: number;
}

export interface OwnedItem {
  id: string;
  purchasedAt: string;
}

export interface SaveData {
  schemaVersion: 2;
  playerName: string;
  level: number;
  experience: number;
  coins: number;
  gems: number;
  bestDistance: number;
  selectedMap: MapId;
  records: RunRecord[];
  rescuedTotal: number;
  completedMissions: string[];
  activeMissionId: string;
  equippedCosmeticId: string;
  ownedItems: OwnedItem[];
  settings: {
    quality: 'low' | 'medium' | 'high';
    fps: 30 | 60;
    shadows: boolean;
    effects: boolean;
    motionEffects: boolean;
    audio: { sfx: number; voices: number; ui: number; vibration: boolean };
    swipeSensitivity: number;
    vibration: boolean;
    music: false;
  };
}
