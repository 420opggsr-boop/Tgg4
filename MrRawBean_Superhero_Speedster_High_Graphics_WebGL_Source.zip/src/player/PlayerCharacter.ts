import * as THREE from 'three';
import { LANES, clamp } from '../game/logic.js';

export type PlayerAnimation = 'idle' | 'run' | 'jump' | 'slide' | 'stumble' | 'damage' | 'flight-takeoff' | 'flight' | 'flight-landing' | 'rescue' | 'victory' | 'gameover';

export class PlayerCharacter {
  readonly root = new THREE.Group();
  readonly laneChangeSpeed = 13;
  lane = 1;
  targetX = 0;
  animation: PlayerAnimation = 'idle';
  private armLeft = new THREE.Group();
  private armRight = new THREE.Group();
  private legLeft = new THREE.Group();
  private legRight = new THREE.Group();
  private capeLeft = new THREE.Mesh();
  private capeRight = new THREE.Mesh();
  private torso = new THREE.Group();
  private animationTime = 0;
  private actionTimer = 0;
  private bodyBaseY = 0;
  private materials: THREE.Material[] = [];
  private capeMaterial: THREE.MeshStandardMaterial | null = null;
  private speedTrail = new THREE.Group();
  private hoverCarpet = new THREE.Group();
  private motionEffects = true;

  constructor() {
    this.root.name = 'MrRawBean-Procedural-Hero';
    this.root.position.set(0, 0.08, 0);
    this.buildModel();
  }

  private mat(color: string | number, emissive = 0, metalness = 0.3, roughness = 0.4): THREE.MeshStandardMaterial {
    const material = new THREE.MeshStandardMaterial({ color, emissive, metalness, roughness });
    this.materials.push(material);
    return material;
  }

  private mesh(geometry: THREE.BufferGeometry, material: THREE.Material, parent: THREE.Object3D, position: [number, number, number], scale?: [number, number, number]): THREE.Mesh {
    const obj = new THREE.Mesh(geometry, material);
    obj.position.set(...position);
    if (scale) obj.scale.set(...scale);
    obj.castShadow = true; obj.receiveShadow = true;
    parent.add(obj);
    return obj;
  }

  private buildModel(): void {
    const navy = this.mat('#071a3c', 0x041843, 0.75, 0.25);
    const blue = this.mat('#075dce', 0x043dff, 0.65, 0.28);
    const cyan = this.mat('#18e8ff', 0x00bfff, 0.6, 0.2);
    const magenta = this.mat('#ec2bcf', 0x9d00ff, 0.5, 0.26);
    const gold = this.mat('#ffcc4a', 0x955400, 0.75, 0.2);
    const skin = this.mat('#c78058', 0, 0.1, 0.68);
    const hair = this.mat('#170f20', 0x17031d, 0.05, 0.72);
    const dark = this.mat('#061020', 0, 0.2, 0.8);
    const white = this.mat('#effaff', 0x1b9fff, 0.15, 0.22);

    // Torso and chest armor.
    this.torso.position.y = 0.98;
    this.root.add(this.torso);
    this.mesh(new THREE.CapsuleGeometry(0.34, 0.44, 4, 8), navy, this.torso, [0, 0.06, 0]);
    this.mesh(new THREE.BoxGeometry(0.66, 0.19, 0.09), blue, this.torso, [0, 0.23, 0.29]);
    this.mesh(new THREE.BoxGeometry(0.09, 0.46, 0.1), cyan, this.torso, [0, 0.01, 0.31]);
    const chestBadge = new THREE.Mesh(new THREE.OctahedronGeometry(0.16, 0), gold);
    chestBadge.position.set(0, -0.06, 0.33); chestBadge.scale.set(1.0, 1.15, 0.45); this.torso.add(chestBadge);
    const chestText = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.085, 0.035), white);
    chestText.position.set(0, 0.13, 0.34); this.torso.add(chestText);
    this.mesh(new THREE.BoxGeometry(0.74, 0.14, 0.13), blue, this.torso, [0, -0.23, 0.02]);
    for (const side of [-1, 1]) {
      this.mesh(new THREE.OctahedronGeometry(0.09, 0), gold, this.torso, [side * 0.23, 0.18, 0.28]);
      this.mesh(new THREE.BoxGeometry(0.085, 0.36, 0.13), magenta, this.torso, [side * 0.27, -0.03, 0.2]);
    }

    // Head, hair, face, brows and beard create an intentional human-like silhouette.
    const head = new THREE.Group(); head.position.set(0, 1.57, 0.04); this.root.add(head);
    this.mesh(new THREE.SphereGeometry(0.26, 16, 12), skin, head, [0, 0, 0]);
    this.mesh(new THREE.SphereGeometry(0.278, 16, 9), hair, head, [0, 0.11, -0.015], [1.02, 0.86, 1.0]);
    for (let i = 0; i < 7; i += 1) {
      const tuft = this.mesh(new THREE.SphereGeometry(0.075, 8, 6), hair, head, [Math.sin(i * 1.7) * 0.18, 0.23 + (i % 2) * 0.025, -0.025 + Math.cos(i * 1.7) * 0.04]);
      tuft.scale.set(1.2, 0.8, 1.0);
    }
    const eyes = this.mat('#1b1020', 0, 0, 0.2);
    for (const side of [-1, 1]) {
      this.mesh(new THREE.SphereGeometry(0.032, 8, 6), eyes, head, [side * 0.09, 0.02, 0.232], [1, 0.8, 0.45]);
      this.mesh(new THREE.BoxGeometry(0.105, 0.025, 0.025), hair, head, [side * 0.09, 0.077, 0.226]).rotation.z = side * -0.12;
    }
    this.mesh(new THREE.ConeGeometry(0.035, 0.085, 5), skin, head, [0, -0.005, 0.255], [0.75, 1, 0.5]).rotation.x = Math.PI / 2;
    this.mesh(new THREE.SphereGeometry(0.17, 12, 8, 0, Math.PI * 2, 0.85, 1.1), hair, head, [0, -0.14, 0.065], [1.0, 0.7, 0.8]);
    this.mesh(new THREE.BoxGeometry(0.22, 0.035, 0.025), hair, head, [0, -0.12, 0.19]);

    // Belt and pelvis.
    this.mesh(new THREE.BoxGeometry(0.54, 0.13, 0.32), gold, this.root, [0, 0.68, 0]);
    this.mesh(new THREE.BoxGeometry(0.21, 0.16, 0.08), cyan, this.root, [0, 0.67, 0.18]);
    this.mesh(new THREE.CapsuleGeometry(0.27, 0.2, 3, 7), navy, this.root, [0, 0.47, 0]);

    // Pivoted articulated arms and gloves.
    const limbGeo = new THREE.CapsuleGeometry(0.105, 0.3, 3, 7);
    const forearmGeo = new THREE.CapsuleGeometry(0.11, 0.24, 3, 7);
    for (const [side, pivot] of [[-1, this.armLeft], [1, this.armRight]] as const) {
      pivot.position.set(side * 0.39, 1.12, 0.02); this.root.add(pivot);
      this.mesh(new THREE.SphereGeometry(0.16, 10, 8), blue, pivot, [0, -0.01, 0]);
      this.mesh(limbGeo, navy, pivot, [0, -0.22, 0]);
      this.mesh(forearmGeo, blue, pivot, [0, -0.43, 0.02]);
      this.mesh(new THREE.TorusGeometry(0.115, 0.026, 6, 10), gold, pivot, [0, -0.31, 0.035]).rotation.x = Math.PI / 2;
      this.mesh(new THREE.SphereGeometry(0.13, 10, 8), dark, pivot, [0, -0.6, 0.07]);
      this.mesh(new THREE.BoxGeometry(0.14, 0.07, 0.14), cyan, pivot, [0, -0.55, 0.16]);
      this.mesh(new THREE.BoxGeometry(0.12, 0.17, 0.09), magenta, pivot, [side * -0.02, -0.15, 0.1]);
    }

    // Articulated legs and gold-accented boots.
    for (const [side, pivot] of [[-1, this.legLeft], [1, this.legRight]] as const) {
      pivot.position.set(side * 0.17, 0.42, 0); this.root.add(pivot);
      this.mesh(new THREE.CapsuleGeometry(0.14, 0.32, 3, 7), navy, pivot, [0, -0.18, 0]);
      this.mesh(new THREE.BoxGeometry(0.26, 0.22, 0.3), blue, pivot, [0, -0.46, 0.035]);
      this.mesh(new THREE.BoxGeometry(0.275, 0.065, 0.32), gold, pivot, [0, -0.48, 0.06]);
      this.mesh(new THREE.BoxGeometry(0.07, 0.17, 0.08), cyan, pivot, [0, -0.26, 0.13]);
      const boot = new THREE.Mesh(new THREE.BoxGeometry(0.29, 0.1, 0.4), dark);
      boot.position.set(0, -0.54, 0.08); pivot.add(boot);
    }

    // Two feathered cape panels with low-cost procedural secondary motion.
    const capeMat = this.mat('#102e9b', 0x2012a8, 0.35, 0.28);
    this.capeMaterial = capeMat;
    const capeEdge = this.mat('#ed2bcf', 0x8f0878, 0.4, 0.27);
    for (const [side, key] of [[-1, 'left'], [1, 'right']] as const) {
      const panel = new THREE.Group(); panel.position.set(side * 0.18, 1.22, -0.2); this.root.add(panel);
      const shape = new THREE.Shape(); shape.moveTo(0, 0.03); shape.lineTo(side * 0.52, -0.08); shape.lineTo(side * 0.84, -0.78); shape.lineTo(side * 0.35, -0.68); shape.lineTo(0.02 * side, -0.46); shape.closePath();
      const geometry = new THREE.ShapeGeometry(shape, 1);
      const fabric = new THREE.Mesh(geometry, capeMat); fabric.position.z = -0.015; panel.add(fabric); fabric.material.side = THREE.DoubleSide;
      const edgeShape = new THREE.Shape(); edgeShape.moveTo(side * 0.35, -0.68); edgeShape.lineTo(side * 0.84, -0.78); edgeShape.lineTo(side * 0.74, -0.67); edgeShape.lineTo(side * 0.35, -0.62); edgeShape.closePath();
      const trim = new THREE.Mesh(new THREE.ShapeGeometry(edgeShape), capeEdge); trim.position.z = 0.005; trim.material.side = THREE.DoubleSide; panel.add(trim);
      if (key === 'left') this.capeLeft = fabric; else this.capeRight = fabric;
      panel.userData.side = side;
      (panel as THREE.Group & { isCape?: boolean }).isCape = true;
    }
    // Bright shoulder fins and back collar.
    this.mesh(new THREE.BoxGeometry(0.9, 0.13, 0.28), magenta, this.root, [0, 1.26, -0.09]).rotation.z = 0.04;
    this.mesh(new THREE.BoxGeometry(0.74, 0.09, 0.2), cyan, this.root, [0, 1.31, -0.04]);

    // Optional green speed streaks; a setting can disable the visual effect.
    this.speedTrail.name = 'SpeedBoostTrail';
    this.speedTrail.visible = false;
    const trailMaterial = this.mat('#50ffa0', 0x13ff79, 0.25, 0.22);
    for (const [index, x] of [-0.18, 0, 0.18].entries()) {
      const streak = new THREE.Mesh(new THREE.BoxGeometry(index === 1 ? 0.065 : 0.04, 0.045, 0.8 + (index % 2) * 0.3), trailMaterial);
      streak.position.set(x, 0.86 + (index % 2) * 0.09, -0.58);
      this.speedTrail.add(streak);
    }
    this.root.add(this.speedTrail);

    // A small levitating superhero carpet is visible in the home/idle scene only.
    // It is procedural geometry so it ships locally and works without network assets.
    this.hoverCarpet.name = 'HomeHoverCarpet';
    this.hoverCarpet.position.set(0, -0.06, 0.05);
    const carpetBody = new THREE.Mesh(
      new THREE.CylinderGeometry(0.43, 0.5, 0.065, 6, 1, false),
      this.mat('#17136a', 0x2e16ff, 0.7, 0.25),
    );
    carpetBody.rotation.y = Math.PI / 6;
    carpetBody.scale.z = 0.58;
    carpetBody.castShadow = true;
    this.hoverCarpet.add(carpetBody);
    const carpetTrim = new THREE.Mesh(
      new THREE.TorusGeometry(0.42, 0.025, 6, 24),
      this.mat('#ffd65b', 0xff9800, 0.6, 0.2),
    );
    carpetTrim.rotation.x = Math.PI / 2;
    carpetTrim.position.y = 0.04;
    carpetTrim.scale.z = 0.57;
    this.hoverCarpet.add(carpetTrim);
    const carpetRune = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.095, 0),
      this.mat('#31eaff', 0x00bfff, 0.45, 0.2),
    );
    carpetRune.position.set(0, 0.052, 0);
    carpetRune.scale.set(1.6, 0.22, 0.5);
    this.hoverCarpet.add(carpetRune);
    this.hoverCarpet.visible = true;
    this.root.add(this.hoverCarpet);
  }

  moveLane(direction: number): void {
    this.lane = clamp(this.lane + Math.sign(direction), 0, 2);
    this.targetX = LANES[this.lane];
  }

  setMotionEffects(enabled: boolean): void { this.motionEffects = enabled; }

  setSpeedTrail(enabled: boolean): void { this.speedTrail.visible = enabled; }

  setAnimation(animation: PlayerAnimation, duration = 0): void {
    if (this.animation === animation && duration <= 0) return;
    this.animation = animation;
    this.actionTimer = Math.max(0, duration);
    if (animation === 'jump') this.bodyBaseY = 0.08;
  }

  update(dt: number, elapsed: number): void {
    const d = Math.min(0.05, Math.max(0, dt));
    this.animationTime += d;
    this.root.position.x += (this.targetX - this.root.position.x) * (1 - Math.exp(-this.laneChangeSpeed * d));
    this.actionTimer = Math.max(0, this.actionTimer - d);
    if (this.actionTimer === 0 && ['jump', 'slide', 'stumble', 'damage', 'flight-takeoff', 'flight-landing', 'rescue', 'victory'].includes(this.animation)) this.animation = 'run';

    const t = this.animationTime;
    const running = this.animation === 'run' || this.animation === 'idle' || this.animation === 'jump';
    this.hoverCarpet.visible = this.animation === 'idle';
    this.hoverCarpet.position.y = -0.06 + (this.motionEffects ? Math.sin(t * 2.2) * 0.035 : 0);
    this.hoverCarpet.rotation.y = this.motionEffects ? Math.sin(t * 0.75) * 0.045 : 0;
    const sprint = this.animation === 'flight' || this.animation === 'flight-takeoff';
    const stride = Math.sin(t * (sprint ? 13 : 10));
    const strideScale = running || sprint ? 1 : this.animation === 'stumble' ? 0.35 : 0;
    this.legLeft.rotation.x = stride * 0.7 * strideScale;
    this.legRight.rotation.x = -stride * 0.7 * strideScale;
    this.armLeft.rotation.x = -stride * 0.58 * strideScale;
    this.armRight.rotation.x = stride * 0.58 * strideScale;
    this.armLeft.rotation.z = ['flight', 'flight-takeoff'].includes(this.animation) ? -0.85 : 0;
    this.armRight.rotation.z = ['flight', 'flight-takeoff'].includes(this.animation) ? 0.85 : 0;

    let jumpY = 0;
    if (this.animation === 'jump') {
      const progress = clamp((this.actionTimer > 0 ? 0.88 - this.actionTimer : 1) / 0.88, 0, 1);
      jumpY = Math.sin(progress * Math.PI) * 1.55;
      this.legLeft.rotation.x = -0.55; this.legRight.rotation.x = 0.3;
    } else if (this.animation === 'flight-takeoff') {
      const progress = clamp(1 - this.actionTimer / 0.45, 0, 1);
      jumpY = Math.sin(progress * Math.PI / 2) * 1.45;
      this.torso.rotation.x = -0.22;
      this.armLeft.rotation.x = -1.0; this.armRight.rotation.x = -1.0;
    } else if (this.animation === 'flight') {
      jumpY = 1.45 + Math.sin(t * 2.4) * 0.1;
      this.torso.rotation.x = -0.34;
      this.legLeft.rotation.x = 0.72 + stride * 0.06;
      this.legRight.rotation.x = 0.78 - stride * 0.06;
    } else if (this.animation === 'flight-landing') {
      jumpY = clamp(this.actionTimer / 0.35, 0, 1) * 0.72;
      this.torso.rotation.x = -0.12;
    } else this.torso.rotation.x += (0 - this.torso.rotation.x) * (1 - Math.exp(-8 * d));

    const idleBob = this.motionEffects && this.animation === 'idle' ? Math.sin(t * 2.5) * 0.025 : 0;
    const runBob = this.motionEffects && running ? Math.abs(stride) * 0.035 : 0;
    this.root.position.y = 0.08 + jumpY + idleBob + runBob;
    if (this.animation === 'slide') {
      this.root.scale.y += (0.63 - this.root.scale.y) * (1 - Math.exp(-20 * d));
      this.torso.rotation.x = 0.44;
      this.armLeft.rotation.x = -1.2; this.armRight.rotation.x = -1.2;
    } else this.root.scale.y += (1 - this.root.scale.y) * (1 - Math.exp(-15 * d));
    if (this.animation === 'stumble') {
      this.root.rotation.z = Math.sin(t * 19) * 0.18;
      this.armLeft.rotation.x = -1.2; this.armRight.rotation.x = 0.7;
    } else if (this.animation === 'damage') {
      this.root.rotation.z = Math.sin(t * 30) * 0.1;
    } else {
      const bank = clamp((this.targetX - this.root.position.x) * 0.16, -0.14, 0.14);
      this.root.rotation.z += (bank - this.root.rotation.z) * (1 - Math.exp(-10 * d));
    }
    if (this.animation === 'gameover') this.root.rotation.x = -0.85;
    else this.root.rotation.x += (0 - this.root.rotation.x) * (1 - Math.exp(-4 * d));

    const capes = this.root.children.filter((child) => Boolean((child as THREE.Group & { isCape?: boolean }).isCape));
    for (const cape of capes) {
      const side = Number(cape.userData.side || 1);
      cape.rotation.y = this.motionEffects ? Math.sin(t * 5 + side) * 0.18 + (this.animation === 'flight' ? side * 0.17 : 0) : 0;
      cape.rotation.x = this.motionEffects ? Math.cos(t * 4 + side) * 0.08 - (this.animation === 'flight' ? 0.22 : 0) : 0;
    }
    if (this.speedTrail.visible && this.motionEffects) this.speedTrail.rotation.z = Math.sin(t * 16) * 0.045;
  }

  setCapeColor(color: string): void {
    if (!this.capeMaterial) return;
    this.capeMaterial.color.set(color);
    this.capeMaterial.emissive.set(color);
    this.capeMaterial.emissiveIntensity = 0.28;
  }

  dispose(): void {
    this.root.traverse((node) => {
      if (node instanceof THREE.Mesh) node.geometry.dispose();
    });
    for (const material of this.materials) material.dispose();
  }
}
