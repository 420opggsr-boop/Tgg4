# MrRawBean Superhero Speedster

A portrait-first, browser-based superhero endless runner built with Three.js, TypeScript, and Vite. The nine environments and hero are generated from local procedural geometry; supplied artwork is used as a local visual reference/avatar and as map-selection thumbnails, not as flattened game screenshots.

## Implemented in source

- Third-person Three.js WebGL scene with a procedural articulated hero, animated limbs, armor details, and a lightweight animated cape.
- **High-graphics surface pack:** 9 biome-specific high-resolution road textures, 9 matching tangent-space normal maps, 5 ground textures, and a fine roughness/detail map. Each asset is bundled locally and cached for offline use.
- High desktop profile with ACES tone mapping, PCF soft shadows at up to 2048², anisotropic tiled surfaces, denser landmarks, reflective lane inlays, and increased render-pixel-ratio headroom. Android phones use a medium initial preset with adaptive resolution to protect frame rate; users can select High in settings.
- Nine separate map IDs and distinct procedural scene builders: Neon Cyber City, Tropical Sunset Kingdom, Frozen Ice Kingdom, Emerald Floating Islands, Inferno Volcano Kingdom, Cosmic Purple Portal City, Golden Desert Frontier, Emerald Moonlight City, and Cosmic Planet Frontier.
- Three-lane movement, jump, slide, track recycling, approaching vehicles, grey obstacles, damaging red-black obstacles, coins, three heart pickups, civilian rescue, checkpoint notifications, bounded difficulty, pause/restart/Game Over, and mission progress.
- Responsive HTML/CSS home UI, map selector, records, offline cosmetic cape shop, quick missions, settings, player-name validation, result settlement, and versioned local progression.
- Versioned save validation and recovery from invalid JSON, gesture/logic unit tests using Node's built-in test runner, Vitest tests, and Playwright E2E test scenarios.
- PWA manifest, portrait-derived PNG launcher icons, an install control, a service worker configured to precache the built local JS/CSS bundles, nine map thumbnails, all 24 local surface textures, icons and two voice clips, Netlify static-hosting configuration, and a strict no-background-music source policy.
- Local generated male-voice samples for civilian rescue (“Thank you!”) and the 2 km checkpoint shout. They are offline bundled speech clips, not studio recordings.
- Capacitor configuration and Android commands for generating a native APK whose web assets are packed into the app.

## Requirements

- Node.js 22.12 or newer (the source was written for the currently supported Vite 8 toolchain).
- npm and network access to the npm registry for the initial dependency install.
- A modern browser with WebGL support. Actual compatibility and performance vary by device.

## Setup

The initial dependency install needs registry access. Run:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. `npm install` will produce `package-lock.json`; commit that generated lockfile for reproducible team/Netlify builds.

After the first install, use:

```bash
npm run typecheck
npm test
npm run test:vitest
npm run test:e2e
npm run build
npm run preview
```

Playwright browser binaries may need installation for the chosen host (for example `npx playwright install chromium`). The E2E suite runs desktop Chromium and Pixel-like mobile emulation; mobile emulation is not a replacement for physical Android testing.

## Controls

| Action | Touch | Keyboard |
|---|---|---|
| Move left/right | Swipe left/right or left/right pad buttons | Arrow keys or A/D |
| Jump | Swipe up or JUMP button | Up, W, or Space |
| Slide | Swipe down or SLIDE button | Down or S |
| Pause/resume | Pause button | Escape |

On the running surface, a gesture threshold separates taps from swipes. Menu controls are excluded from swipe handling. Returning to the home screen, pausing, or switching tabs does not advance the simulation.

## Audio policy

There is no background-music player, soundtrack asset, music loop, or music toggle. Short sound effects use Web Audio noise bursts; the two speech clips are local MP3s generated with a local text-to-speech engine. The checkpoint clip is louder/faster and the civilian response is softer. These voices are synthetic and somewhat robotic, not studio-quality recordings. Voice files are included in the offline cache. Audio activation and actual output should still be verified on the target Android browser/device.

## Art and animation notes

- `public/character-reference.webp` is derived from the supplied portrait.
- `public/maps/*.webp` are crops from the supplied nine-map collage.
- `public/icons/profile-avatar.webp` is a cropped reference avatar; `icon-64.png`, `icon-192.png`, and `icon-512.png` are launcher/favicon sizes derived from that portrait.
- The in-game player is procedural, not an imported rigged GLB. Animation states are procedural pose blends/rotations; no skeletal rig, mocap clip, or production-quality cloth simulation is claimed.
- `public/models`, `public/textures`, `public/audio`, and `public/fonts` are reserved asset directories. No GLB or prerecorded voice/audio files were included with the references.

## Android install and offline play

For the easiest Android install, publish the app to HTTPS, open it once in Chrome, allow the service worker to cache all files, then use the in-game **INSTALL OFFLINE APP** control or Chrome’s **Install app / Add to Home screen** option. It needs an initial download before PWA offline play works. For a native APK that can launch with no prior web visit, use [the Android build guide](docs/ANDROID_BUILD.md) and Capacitor. The native Android project and APK must be generated on a machine with Android Studio/SDK and successful npm dependency installation.

## Deployment to Netlify

1. Ensure `package-lock.json` has been generated and committed after `npm install`.
2. Run all checks and `npm run build`.
3. Deploy this repository through Netlify. The included `netlify.toml` uses `npm run build` and publishes `dist`.
4. Test the published preview on an actual browser, then publish to production only after the smoke test.

No live Netlify URL is included because this environment has no deployment credentials and could not install the build dependencies.

## Test/deployment status

See [`docs/HIGH_GRAPHICS_UPGRADE.md`](docs/HIGH_GRAPHICS_UPGRADE.md) for the added local texture pack and render settings. See [`docs/ANDROID_BUILD.md`](docs/ANDROID_BUILD.md) for Android PWA/APK options. See [`docs/TEST_REPORT.md`](docs/TEST_REPORT.md) for source tests and the remaining build blockers. See [`docs/KNOWN_ISSUES.md`](docs/KNOWN_ISSUES.md) for current limitations.


## Android runtime optimization

See `docs/ANDROID_RUNTIME_OPTIMIZATION.md` for the Android GPU/runtime tuning pass and `docs/ANDROID_FINAL_BUILD.md` for the actual APK build procedure. This source package is not itself an APK and no unverified APK is represented as final.
