# High-Graphics WebGL Upgrade

This upgrade keeps the existing MrRawBean endless-runner gameplay and adds a locally bundled surface-texture pack. Textures are procedural artwork created for this game and require no third-party network requests or licensed texture package.

## Local surface pack

- Nine biome-specific road albedo textures for Neon, Tropical, Ice, Emerald, Inferno, Portal, Desert, Moonlight and Cosmic maps.
- Nine matching normal maps to improve visible surface relief under scene lighting.
- Five ground albedo textures chosen by biome family.
- One fine detail/roughness map to add micro-surface variation.
- Texture files are loaded from `public/textures/` and are included in the service-worker shell cache for offline play after initial installation. Surface textures are disposed when changing maps so GPU memory does not accumulate from all nine worlds.

## Rendering profile

- ACES Filmic tone mapping with a higher exposure setting.
- PCF soft shadows, with 2048 × 2048 shadow maps on High and 1024 × 1024 on Medium.
- Anisotropic filtering and mipmapped tiled surfaces.
- Denser roadside props, higher-resolution ice spires, additional neon strips, reflective road inlays and a larger star field on High.
- High default profile on desktop. Mobile devices start at Medium with shadows off and a lower pixel-ratio cap; adaptive render scaling responds to sustained slow frame times. High remains selectable on supported phones, but heavy effects can reduce FPS and increase heat/battery use.

## Publish

The project remains a Vite source project. On a build-capable computer run `npm install`, `npm test`, `npm run build`, then publish the generated `dist/` directory through Netlify. The `netlify.toml` already specifies `npm run build` and `dist`. Deploying the source ZIP through Git/Netlify is preferable to a manual Drop; a manual Drop must contain the built `dist/` files, not the source files.

## Verification boundary

The source tests check that all 24 texture files exist, match their map/material roles, and are listed in the offline service-worker cache. A real WebGL visual check, production Vite build, Netlify smoke test and physical Android FPS/heat test are still required; source-contract tests cannot establish device performance or guarantee a zero-issue release.
