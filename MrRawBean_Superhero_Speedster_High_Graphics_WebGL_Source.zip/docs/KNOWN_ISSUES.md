# Known issues and limitations

- The authoring environment could not complete `npm install` because the package registry request timed out. `package-lock.json` is not present yet, so reproducible `npm ci`, project type checking, Vite production build, Vitest and project-local Playwright are blocked until dependencies are installed successfully.
- No production `dist/` directory or public Netlify URL was produced or verified.
- The native Android project (`android/`) and APK are not generated in this source delivery. Use `docs/ANDROID_BUILD.md` on a machine with npm registry access and Android Studio/SDK.
- Physical Android hardware, offline launch, frame rate and memory use have not been tested in this environment.
- The hero is an articulated procedural Three.js model, not an imported production rig or motion-captured GLB. The home scene now includes an animated procedural hover carpet, and the cape is animated with lightweight procedural motion rather than cloth simulation.
- The two bundled voice clips are offline male-voice synthesis. They are understandable but robotic and are not studio-quality performances. Verify actual speaker volume and queue playback on Android.
- The background-music policy is enforced in source checks. Short synthesized sound effects and the two local speech clips are permitted; no soundtrack or music loop is bundled.
- PWA offline launch works only after the first successful HTTPS visit and service-worker cache installation. A native Capacitor APK packages its web assets locally, but that APK still needs to be generated and verified.
- The new texture pack is covered by source-contract tests, but visual UV tiling, contrast, WebGL shader compatibility and shadow appearance still require browser testing.
- High-quality textures and PCF soft shadows increase download size and GPU load; the project starts mobile devices at Medium, and users should lower quality if their phone overheats or stutters.
- Scene rendering, gameplay collisions and all map environments still require the documented browser E2E and real-device tests before release acceptance.
