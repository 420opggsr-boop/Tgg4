# Final Android APK build

## Environment

Use Android Studio with a working Android SDK and Gradle, or another CI runner with the Android SDK installed.

## Build

1. Use Node 22.16.x and npm 10.9.x.
2. From the project root run `npm install`.
3. Run `npm test`.
4. Run `npm run typecheck`.
5. Run `npm run build`.
6. Run `npx cap add android` if the `android/` directory does not exist.
7. Run `npx cap sync android`.
8. Open the `android/` directory in Android Studio.
9. Build a release APK from the Android Studio Build menu, or run the appropriate Gradle assemble task.
10. Install the APK on an Android device and test offline before distribution.

The Capacitor web directory is `dist`; all game assets and voice clips are local. No runtime music or network dependency is required by the game design.
