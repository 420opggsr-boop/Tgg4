# Android runtime optimization

The final source is tuned for offline Android WebView play:

- mobile WebGL antialiasing is disabled to reduce GPU fill cost;
- mobile device pixel ratio is capped at 1.65 (with a Medium render scale of 0.9); desktop can use up to 2.25;
- medium/low render scales reduce GPU pressure without changing gameplay coordinates;
- shadows default off on mobile (High on desktop enables them) for Android and can be enabled in higher-end devices;
- adaptive render scale monitors frame time and reduces resolution if sustained frame cost is high;
- spawned gameplay objects are capped more aggressively on low-performance mobile paths;
- map textures are disposed when changing worlds to keep GPU memory from accumulating across all nine maps;
- background tabs pause the game loop and audio;
- no network asset is required at runtime; game assets, maps and voice clips are local;
- no background music is included.

## Android build verification status

This environment does not contain the Android SDK/Gradle toolchain and cannot download npm packages, so an APK cannot be honestly compiled or device-tested here. The source is prepared for Capacitor Android packaging, but the final APK must be built in an Android/Gradle-capable environment.

The High desktop preset now uses local biome albedo/normal textures, a roughness-detail map, denser environment geometry and PCF soft shadows up to 2048². All high-graphics files are included in the service-worker precache.
