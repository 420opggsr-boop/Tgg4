# Netlify Deployment

1. Use Node.js 22.12+ and npm with working registry access.
2. Run `npm install` once and commit the resulting `package-lock.json`.
3. Run `npm run typecheck`, `npm test`, `npm run test:vitest`, `npm run test:e2e`, and `npm run build`; do not deploy while any required command fails.
4. Push the repository to the source-control provider used by Netlify.
5. Create a Netlify site from the repository. The checked-in `netlify.toml` sets build command `npm run build` and publish directory `dist`.
6. Deploy a preview and inspect browser console/network requests. Verify all nine map environments, game state transitions, local persistence, and offline cache behavior in the deployed preview.
7. Test mobile portrait layout and touchscreen controls on real Android hardware before publishing production.

This repository was not deployed as part of the current authoring session. No deployment URL is available to report.
