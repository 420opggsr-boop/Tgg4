# Netlify publish fix

## Important

Netlify publishes a **web build**, not an Android APK. The APK is built separately with Capacitor/Android Studio. Do not upload an `.apk` as the Netlify site.

## Repository deployment (recommended)

1. Put the **contents of this folder** at the repository root. Do not create an extra `mrrawbean-superhero-speedster/` folder above `index.html`.
2. Push the repository to GitHub/GitLab/Bitbucket.
3. In Netlify, choose **Add new project -> Import an existing project** and select the repository.
4. Leave the build settings from `netlify.toml` in place:
   - Build command: `npm install --no-audit --no-fund && npm run build`
   - Publish directory: `dist`
   - Node: `22.16.0`
5. Deploy.

## Why the old ZIP failed

A source ZIP is not the same thing as a built Netlify site. A drag-and-drop ZIP deployment does not run the Vite build for the source tree. The old archive also contained the project inside a top-level folder, which can make the wrong directory become the site root when manually uploaded.

## If using Netlify Drop

First run:

```bash
npm install
npm run build
```

Then upload the **contents of `dist/`**, not the source project ZIP. The `dist/` directory must contain `index.html`, the generated `assets/`, `manifest.webmanifest`, service worker, icons, maps, and audio files.

## Android APK

The APK is separate:

```bash
npm install
npm run build
npm run android:add
npm run android:sync
npm run android:open
```

Build the signed APK/AAB from Android Studio. Never use the APK as the Netlify publish directory.
