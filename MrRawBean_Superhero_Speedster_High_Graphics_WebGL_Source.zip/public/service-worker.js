/* Offline app-shell cache. There is deliberately no audio music path or background playback. */
const CACHE_PREFIX = 'mrrawbean-speedster-';
const CACHE_VERSION = 'v4';
const SHELL_CACHE = `${CACHE_PREFIX}shell-${CACHE_VERSION}`;
const RUNTIME_CACHE = `${CACHE_PREFIX}runtime-${CACHE_VERSION}`;
// Replaced by the Vite build plugin with locally bundled scripts/styles.
const BUILD_ASSET_PATHS = [];
const SHELL_PATHS = [
  './', './manifest.webmanifest', './icons/icon.svg', './icons/icon-64.png', './icons/icon-192.png', './icons/icon-512.png', './icons/profile-avatar.webp', './character-reference.webp',
  './maps/neon-city.webp', './maps/tropical-sunset.webp', './maps/ice-kingdom.webp',
  './maps/emerald-islands.webp', './maps/inferno.webp', './maps/cosmic-portal.webp',
  './maps/golden-desert.webp', './maps/moonlight-city.webp', './maps/planet-frontier.webp',
  './audio/rescue-thank-you.mp3', './audio/checkpoint-superhero.mp3',
  './textures/road-neon.jpg', './textures/road-tropical.jpg', './textures/road-ice.jpg',
  './textures/road-emerald.jpg', './textures/road-inferno.jpg', './textures/road-portal.jpg',
  './textures/road-desert.jpg', './textures/road-moonlight.jpg', './textures/road-cosmic.jpg',
  './textures/normal-neon.jpg', './textures/normal-tropical.jpg', './textures/normal-ice.jpg',
  './textures/normal-emerald.jpg', './textures/normal-inferno.jpg', './textures/normal-portal.jpg',
  './textures/normal-desert.jpg', './textures/normal-moonlight.jpg', './textures/normal-cosmic.jpg',
  './textures/ground-lush.jpg', './textures/ground-rock.jpg', './textures/ground-ice.jpg',
  './textures/ground-sand.jpg', './textures/ground-dark.jpg', './textures/surface-detail.jpg',
  ...BUILD_ASSET_PATHS
];
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(SHELL_CACHE).then((cache) => cache.addAll(SHELL_PATHS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key.startsWith(CACHE_PREFIX) && ![SHELL_CACHE, RUNTIME_CACHE].includes(key)).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (request.mode === 'navigate') {
    event.respondWith(caches.match(request, { ignoreSearch: true }).then((cached) => cached || caches.match('./') || fetch(request).then((response) => {
      const copy = response.clone(); caches.open(SHELL_CACHE).then((cache) => cache.put('./', copy)); return response;
    })));
    return;
  }
  event.respondWith(caches.match(request).then((cached) => {
    if (cached) return cached;
    return fetch(request).then((response) => {
      if (response && response.ok && response.type === 'basic') {
        const copy = response.clone(); caches.open(RUNTIME_CACHE).then((cache) => cache.put(request, copy));
      }
      return response;
    }).catch(() => caches.match(request));
  }));
});
