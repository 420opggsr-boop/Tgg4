import { describe, expect, it } from 'vitest';
import { MAPS, isMapId, getMap } from '../../src/maps/MapRegistry';
import { awardLife, crossedCheckpoints, nextLane, normalizeSettings, applyObstacleHit } from '../../src/game/logic.js';

describe('map registry', () => {
  it('contains exactly nine unique map IDs and distinct biome definitions', () => {
    expect(MAPS).toHaveLength(9);
    expect(new Set(MAPS.map((map) => map.id)).size).toBe(9);
    expect(new Set(MAPS.map((map) => map.biome)).size).toBe(9);
    expect(MAPS.every((map) => map.thumbnail && map.name && map.description)).toBe(true);
    expect(isMapId('MAP_09')).toBe(true);
    expect(isMapId('MAP_10')).toBe(false);
    expect(getMap('MAP_05').landmark).toBe('volcano');
  });
});

describe('gameplay rules', () => {
  it('clamps lanes, lives, and settings', () => {
    expect(nextLane(0, -1)).toBe(0);
    expect(nextLane(2, 1)).toBe(2);
    expect(awardLife(5)).toEqual({ lives: 5, added: 0 });
    expect(normalizeSettings({ music: true, swipeSensitivity: 1000 }).music).toBe(false);
  });
  it('counts every checkpoint crossed, including large frame spans', () => {
    expect(crossedCheckpoints(1900, 6100)).toEqual([2000, 4000, 6000]);
  });
  it('does not let grey obstacles deal life damage', () => {
    expect(applyObstacleHit({ obstacleType: 'grey', lives: 3 })).toMatchObject({ outcome: 'stumble', lives: 3, damage: 0 });
  });
});
