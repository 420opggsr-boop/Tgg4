import test from 'node:test';
import assert from 'node:assert/strict';
import { access, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  LANES, GAME_RULES, clampLane, nextLane, classifyGesture, distanceDelta,
  crossedCheckpoints, awardLife, applyObstacleHit, shouldCollectPickup,
  settleRewardOnce, isValidPurchase, calculateLevel, isValidPlayerName,
  normalizeSettings,
} from '../../src/game/logic.js';

test('three lane movement remains clamped at both edges', () => {
  assert.deepEqual(LANES, [-2.2, 0, 2.2]);
  assert.equal(nextLane(0, -1), 0);
  assert.equal(nextLane(0, 1), 1);
  assert.equal(nextLane(2, 1), 2);
  assert.equal(nextLane(2, -1), 1);
  assert.equal(clampLane(Number.NaN), 1);
});

test('gesture thresholds distinguish tap from swipes', () => {
  assert.deepEqual(classifyGesture(10, 10, 42, 10, 42), { type: 'tap', direction: null });
  assert.deepEqual(classifyGesture(100, 100, 35, 108, 42), { type: 'swipe', direction: 'left' });
  assert.deepEqual(classifyGesture(100, 100, 104, 30, 42), { type: 'swipe', direction: 'up' });
  assert.deepEqual(classifyGesture(100, 100, 103, 190, 42), { type: 'swipe', direction: 'down' });
});

test('distance integration bounds frame stalls and rejects invalid values', () => {
  assert.equal(distanceDelta(20, 0.02), 0.4);
  assert.equal(distanceDelta(20, 3), 1);
  assert.equal(distanceDelta(-10, 0.03), 0);
  assert.equal(distanceDelta(Number.NaN, 0.1), 0);
});

test('checkpoint crossing fires every crossed threshold exactly once', () => {
  assert.deepEqual(crossedCheckpoints(1990, 2010), [2000]);
  assert.deepEqual(crossedCheckpoints(1900, 6100), [2000, 4000, 6000]);
  assert.deepEqual(crossedCheckpoints(2000, 2000), []);
  assert.deepEqual(crossedCheckpoints(900, 1100, 1000), [1000]);
  assert.deepEqual(crossedCheckpoints(0, 100, 0), []);
});

test('extra lives obey the configured cap', () => {
  assert.deepEqual(awardLife(3), { lives: 4, added: 1 });
  assert.deepEqual(awardLife(5), { lives: 5, added: 0 });
  assert.deepEqual(awardLife(-1), { lives: 1, added: 1 });
  assert.equal(GAME_RULES.maxLives, 5);
});

test('grey obstacles stumble without life damage; damaging obstacles use explicit types', () => {
  assert.deepEqual(applyObstacleHit({ obstacleType: 'grey', lives: 3 }), { outcome: 'stumble', lives: 3, damage: 0 });
  assert.deepEqual(applyObstacleHit({ obstacleType: 'red-black', lives: 3 }), { outcome: 'damage', lives: 2, damage: 1 });
  assert.equal(applyObstacleHit({ obstacleType: 'red-black', lives: 1 }).outcome, 'gameover');
  assert.equal(applyObstacleHit({ obstacleType: 'red-black', lives: 3, invulnerable: true }).lives, 3);
  assert.equal(applyObstacleHit({ obstacleType: 'red-black', lives: 3, stumbling: true }).lives, 3);
});

test('pickup and reward settlement callbacks are idempotent', () => {
  const picked = new Set();
  assert.equal(shouldCollectPickup('heart-1', picked), true);
  picked.add('heart-1');
  assert.equal(shouldCollectPickup('heart-1', picked), false);
  const settled = new Set();
  assert.equal(settleRewardOnce('run-1', settled), true);
  assert.equal(settleRewardOnce('run-1', settled), false);
});

test('purchase validation rejects invalid, unaffordable and duplicate purchases', () => {
  assert.equal(isValidPurchase({ price: 100, balance: 100 }), true);
  assert.equal(isValidPurchase({ price: 101, balance: 100 }), false);
  assert.equal(isValidPurchase({ price: -1, balance: 100 }), false);
  assert.equal(isValidPurchase({ price: 1, balance: 100, owned: true }), false);
  assert.equal(isValidPurchase({ price: Number.NaN, balance: 100 }), false);
});

test('player names enforce length and allowed characters', () => {
  assert.equal(isValidPlayerName('MrRawBean'), true);
  assert.equal(isValidPlayerName('abc'), true);
  assert.equal(isValidPlayerName('ab'), false);
  assert.equal(isValidPlayerName('  '), false);
  assert.equal(isValidPlayerName('name\nline'), false);
  assert.equal(isValidPlayerName('<admin>'), false);
  assert.equal(isValidPlayerName('x'.repeat(17)), false);
});

test('level progression and settings normalization are bounded', () => {
  assert.deepEqual(calculateLevel(0), { level: 1, progressXp: 0, nextLevelXp: 100 });
  assert.equal(calculateLevel(100).level, 2);
  const settings = normalizeSettings({ quality: 'ultra', fps: 90, swipeSensitivity: 999, music: true, audio: { sfx: -3, ui: 0.4 } });
  assert.equal(settings.quality, 'medium');
  assert.equal(settings.fps, 60);
  assert.equal(settings.swipeSensitivity, 90);
  assert.equal(settings.audio.sfx, 0);
  assert.equal(settings.audio.ui, 0.4);
  assert.equal(settings.music, false);
});


test('map registry has exactly nine unique IDs, nine biomes, and local thumbnails', async () => {
  const root = fileURLToPath(new URL('../../', import.meta.url));
  const source = await readFile(join(root, 'src/maps/MapRegistry.ts'), 'utf8');
  const ids = [...source.matchAll(/id:\s*'(MAP_\d{2})'/g)].map((match) => match[1]);
  const biomes = [...source.matchAll(/biome:\s*'([^']+)'/g)].map((match) => match[1]);
  const thumbnails = [...source.matchAll(/thumbnail:\s*'\.\/maps\/([^']+)'/g)].map((match) => match[1]);
  assert.equal(ids.length, 9);
  assert.equal(new Set(ids).size, 9);
  assert.equal(biomes.length, 9);
  assert.equal(new Set(biomes).size, 9);
  assert.equal(thumbnails.length, 9);
  for (const thumbnail of thumbnails) await access(join(root, 'public/maps', thumbnail));
});
