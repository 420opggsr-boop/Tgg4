import test from 'node:test';
import assert from 'node:assert/strict';
import { access, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../../', import.meta.url));

test('PWA icon assets are local and the service worker is configured for build-time offline precaching', async () => {
  const manifest = JSON.parse(await readFile(join(root, 'public/manifest.webmanifest'), 'utf8'));
  assert.ok(manifest.icons.some((icon) => icon.sizes === '192x192'));
  assert.ok(manifest.icons.some((icon) => icon.sizes === '512x512'));
  for (const icon of manifest.icons) {
    assert.match(icon.src, /^\.\//, 'PWA icon URLs should be relative/local.');
    await access(join(root, 'public', icon.src.replace(/^\.\//, '')));
  }
  const sw = await readFile(join(root, 'public/service-worker.js'), 'utf8');
  const vite = await readFile(join(root, 'vite.config.ts'), 'utf8');
  assert.match(sw, /const BUILD_ASSET_PATHS = \[\];/);
  assert.match(sw, /\.\.\.BUILD_ASSET_PATHS/);
  assert.match(vite, /offline-precache/);
  assert.match(vite, /serviceWorker\.replace\(marker/);
});

test('Android packaging and offline voice/carpet assets are wired into the project', async () => {
  const pkg = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'));
  const capacitor = await readFile(join(root, 'capacitor.config.ts'), 'utf8');
  const sw = await readFile(join(root, 'public/service-worker.js'), 'utf8');
  const game = await readFile(join(root, 'src/game/AudioManager.ts'), 'utf8');
  const player = await readFile(join(root, 'src/player/PlayerCharacter.ts'), 'utf8');
  const app = await readFile(join(root, 'src/app/App.ts'), 'utf8');
  assert.equal(pkg.dependencies['@capacitor/core'], '^8.5.3');
  assert.equal(pkg.dependencies['@capacitor/android'], '^8.5.3');
  assert.equal(pkg.devDependencies['@capacitor/cli'], '^8.5.3');
  assert.match(capacitor, /webDir:\s*'dist'/);
  assert.ok(pkg.scripts['android:add'] && pkg.scripts['android:sync'] && pkg.scripts['android:open']);
  assert.match(sw, /\.\/audio\/rescue-thank-you\.mp3/);
  assert.match(sw, /\.\/audio\/checkpoint-superhero\.mp3/);
  assert.match(game, /this\.voiceAudio/);
  assert.match(player, /HomeHoverCarpet/);
  assert.match(app, /data-action="install"/);
});
