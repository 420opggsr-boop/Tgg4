import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../../', import.meta.url));
const read = (file) => readFile(join(root, file), 'utf8');

test('home screen contract includes hero portrait, map selector, gameplay controls and offline install', async () => {
  const app = await read('src/app/App.ts');
  assert.match(app, /character-reference\.webp/);
  assert.match(app, /data-action="maps"/);
  assert.match(app, /data-action="records"/);
  assert.match(app, /data-action="shop"/);
  assert.match(app, /data-action="missions"/);
  assert.match(app, /data-action="settings"/);
  assert.match(app, /data-action="name"/);
  assert.match(app, /data-action="start"/);
  assert.match(app, /data-action="install"/);
});

test('all nine maps are independently selectable with local thumbnails', async () => {
  const registry = await read('src/maps/MapRegistry.ts');
  const ids = [...registry.matchAll(/id:\s*'(MAP_0[1-9])'/g)].map((m) => m[1]);
  assert.deepEqual(ids, ['MAP_01','MAP_02','MAP_03','MAP_04','MAP_05','MAP_06','MAP_07','MAP_08','MAP_09']);
  assert.match(registry, /MAPS\.length !== 9/);
  const app = await read('src/app/App.ts');
  assert.match(app, /data-map-id="\$\{map\.id\}"/);
});

test('power-ups use the requested golden, red-gold and green hearts', async () => {
  const game = await read('src/game/Game.ts');
  assert.match(game, /heart-flight/);
  assert.match(game, /heart-life/);
  assert.match(game, /heart-speed/);
  assert.match(game, /#ffd94f/);
  assert.match(game, /#ff334a/);
  assert.match(game, /#56ff8b/);
  assert.match(game, /FLIGHT ACTIVATED/);
  assert.match(game, /\+1 EXTRA LIFE/);
  assert.match(game, /2× SPEED/);
});

test('obstacles, opposite traffic and rescue gameplay are wired', async () => {
  const game = await read('src/game/Game.ts');
  const logic = await read('src/game/logic.js');
  assert.match(logic, /obstacleType === 'grey'/);
  assert.match(logic, /red-black/);
  assert.match(game, /\['car', 'motorcycle', 'truck'\]/);
  assert.match(game, /kind === 'civilian'/);
  assert.match(game, /CIVILIAN RESCUED/);
  assert.match(game, /queueVoice\('rescue'\)/);
});

test('checkpoint voice contract is exactly every 2000 metres', async () => {
  const logic = await read('src/game/logic.js');
  const game = await read('src/game/Game.ts');
  const audio = await read('src/game/AudioManager.ts');
  assert.match(logic, /checkpointMeters:\s*2000/);
  assert.match(game, /crossedCheckpoints\(oldDistance, this\.distance, GAME_RULES\.checkpointMeters\)/);
  assert.match(game, /queueVoice\('checkpoint'\)/);
  assert.match(audio, /checkpoint-superhero\.mp3/);
});

test('no background music implementation exists', async () => {
  const audio = await read('src/game/AudioManager.ts');
  const app = await read('src/app/App.ts');
  const sw = await read('public/service-worker.js');
  assert.match(audio, /no music player or music track/i);
  assert.match(app, /music: false/);
  assert.doesNotMatch(sw, /music\.(mp3|ogg|wav|m4a)/i);
});
