import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'index.html', 'package.json', 'netlify.toml', 'vite.config.ts',
  'public/manifest.webmanifest', 'public/service-worker.js',
  'public/icons/icon-192.png', 'public/icons/icon-512.png',
  'public/audio/rescue-thank-you.mp3', 'public/audio/checkpoint-superhero.mp3',
  'public/textures/road-neon.jpg', 'public/textures/normal-neon.jpg', 'public/textures/ground-lush.jpg'
];
for (const rel of required) test(`required build input: ${rel}`, () => {
  assert.equal(fs.existsSync(path.join(root, rel)), true);
});

test('package uses the Netlify build contract', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  assert.equal(pkg.scripts.build, 'vite build');
  assert.equal(pkg.scripts['android:sync'], 'npm run build && cap sync android');
  assert.match(pkg.engines.node, /22\.16\.0/);
});

test('Netlify publishes dist and pins Node 22', () => {
  const cfg = fs.readFileSync(path.join(root, 'netlify.toml'), 'utf8');
  assert.match(cfg, /publish\s*=\s*["']dist["']/);
  assert.match(cfg, /NODE_VERSION\s*=\s*["']22\.16\.0["']/);
});
