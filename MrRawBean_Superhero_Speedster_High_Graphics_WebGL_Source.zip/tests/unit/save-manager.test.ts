import { beforeEach, describe, expect, it } from 'vitest';
import { SaveManager } from '../../src/save/SaveManager';
import type { RunRecord } from '../../src/save/SaveSchema';

class MemoryStorage implements Storage {
  private values = new Map<string, string>();
  get length(): number { return this.values.size; }
  clear(): void { this.values.clear(); }
  getItem(key: string): string | null { return this.values.get(key) ?? null; }
  key(index: number): string | null { return [...this.values.keys()][index] ?? null; }
  removeItem(key: string): void { this.values.delete(key); }
  setItem(key: string, value: string): void { this.values.set(key, String(value)); }
}

const KEY = 'mrrawbean.speedster.save';
let storage: MemoryStorage;
let save: SaveManager;
beforeEach(() => { storage = new MemoryStorage(); save = new SaveManager(storage); });

const runRecord = (id: string, distance = 100): RunRecord => ({
  id, date: '2026-10-22T12:00:00.000Z', mapId: 'MAP_01', distance, rescues: 1, coins: 15, gems: 0, duration: 12,
});

describe('SaveManager', () => {
  it('starts with the requested zero currency and level-one profile', () => {
    expect(save.get()).toMatchObject({ playerName: 'MrRawBean', level: 1, experience: 0, coins: 0, gems: 0, bestDistance: 0, selectedMap: 'MAP_01' });
  });

  it('recovers from corrupted or non-object JSON without throwing', () => {
    storage.setItem(KEY, '{ malformed');
    const recovered = new SaveManager(storage);
    expect(recovered.get().playerName).toBe('MrRawBean');
    expect(storage.getItem(KEY)).toBeNull();
    storage.setItem(KEY, JSON.stringify(['not', 'a', 'save']));
    expect(new SaveManager(storage).get().coins).toBe(0);
  });

  it('sanitizes invalid balances, selected maps, names, and settings', () => {
    storage.setItem(KEY, JSON.stringify({ schemaVersion: 2, playerName: '\nadmin', coins: -3, gems: Infinity, selectedMap: 'MAP_77', settings: { music: true, swipeSensitivity: 999 } }));
    const recovered = new SaveManager(storage).get();
    expect(recovered.playerName).toBe('MrRawBean');
    expect(recovered.coins).toBe(0);
    expect(recovered.gems).toBe(0);
    expect(recovered.selectedMap).toBe('MAP_01');
    expect(recovered.settings.music).toBe(false);
    expect(recovered.settings.swipeSensitivity).toBe(90);
  });

  it('validates names and normalizes whitespace', () => {
    expect(save.updateName('  Speed Hero  ')).toBe(true);
    expect(save.get().playerName).toBe('Speed Hero');
    expect(save.updateName('x')).toBe(false);
    expect(save.updateName('bad\nname')).toBe(false);
    expect(save.get().playerName).toBe('Speed Hero');
  });

  it('rejects negative or unaffordable purchases and settles an owned item once', () => {
    expect(save.buyItem('cape-gold', 600).ok).toBe(false);
    expect(save.buyItem('cape-gold', -1).ok).toBe(false);
    save.addRunCoins(700);
    expect(save.buyItem('cape-gold', 600)).toEqual({ ok: true });
    expect(save.get().coins).toBe(100);
    expect(save.buyItem('cape-gold', 1)).toEqual({ ok: false, reason: 'Already owned.' });
    expect(save.get().coins).toBe(100);
    expect(save.equipCosmetic('cape-gold')).toBe(true);
    expect(save.equipCosmetic('cape-magenta')).toBe(false);
  });

  it('settles each run once and tracks progression and records', () => {
    expect(save.settleRun(runRecord('run-one', 100), 50).ok).toBe(true);
    expect(save.settleRun(runRecord('run-one', 500), 50).ok).toBe(false);
    const result = save.get();
    expect(result.coins).toBe(15);
    expect(result.bestDistance).toBe(100);
    expect(result.records).toHaveLength(1);
    expect(result.rescuedTotal).toBe(1);
  });

  it('grants a mission reward once and persists completed IDs', () => {
    expect(save.completeMission('rescue-3', 180, 2)).toBe(true);
    expect(save.completeMission('rescue-3', 180, 2)).toBe(false);
    expect(save.get()).toMatchObject({ coins: 180, gems: 2, completedMissions: ['rescue-3'] });
    expect(save.setActiveMission('rescue-3')).toBe(true);
    expect(save.get().activeMissionId).toBe('rescue-3');
  });

  it('supports the v1-to-v2 migration with safe defaults', () => {
    storage.setItem(KEY, JSON.stringify({ schemaVersion: 1, playerName: 'Legacy Hero', coins: 42, records: [] }));
    const migrated = new SaveManager(storage).get();
    expect(migrated.schemaVersion).toBe(2);
    expect(migrated.playerName).toBe('Legacy Hero');
    expect(migrated.coins).toBe(42);
    expect(migrated.equippedCosmeticId).toBe('cape-royal');
  });
});
