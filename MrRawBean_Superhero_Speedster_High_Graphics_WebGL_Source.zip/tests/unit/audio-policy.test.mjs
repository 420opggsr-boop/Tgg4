import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';

const root = new URL('../../', import.meta.url).pathname;
async function walk(dir) {
  const found = [];
  for (const item of await readdir(dir, { withFileTypes: true })) {
    const path = join(dir, item.name);
    if (item.isDirectory()) {
      if (!['node_modules', 'dist', '.git'].includes(item.name)) found.push(...await walk(path));
    } else found.push(path);
  }
  return found;
}

test('source code registers no music player, soundtrack file or music loop', async () => {
  const files = await walk(join(root, 'src')).then(async (paths) => [...paths, ...await walk(join(root, 'public'))]);
  const sourceFiles = files.filter((file) => /\.(ts|js|html|json|webmanifest|css)$/i.test(file));
  const bodies = await Promise.all(sourceFiles.map((file) => readFile(file, 'utf8')));
  const joined = bodies.join('\n');
  assert.match(joined, /rescue-thank-you\.mp3/);
  assert.match(joined, /checkpoint-superhero\.mp3/);
  assert.match(joined, /audio\.loop\s*=\s*false/i, 'Bundled voice clips must be one-shot playback.');
  assert.doesNotMatch(joined, /https?:\/\/[^\s'"`]+\.(mp3|ogg|wav|m4a)/i, 'Audio assets must remain local.');
  assert.doesNotMatch(joined, /\.loop\s*=\s*true/i, 'No audio loop is allowed.');
  assert.doesNotMatch(joined, /background[-_ ]music\.(mp3|ogg|wav|m4a)/i, 'No background music asset should be registered.');
  assert.match(joined, /music:\s*false/);
  assert.equal(files.some((file) => /(?:background[-_ ]?music|soundtrack)\.(?:mp3|ogg|wav|m4a)$/i.test(file)), false, 'No soundtrack asset may be bundled.');
  for (const voice of ['rescue-thank-you.mp3', 'checkpoint-superhero.mp3']) {
    const path = join(root, 'public/audio', voice);
    const audio = await readFile(path);
    assert.ok(audio.length > 1000, `${voice} should be a real bundled audio asset`);
  }
});
