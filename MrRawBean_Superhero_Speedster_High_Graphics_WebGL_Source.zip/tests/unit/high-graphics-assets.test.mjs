import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const builder = fs.readFileSync(path.join(root, 'src/maps/EnvironmentBuilder.ts'), 'utf8');
const game = fs.readFileSync(path.join(root, 'src/game/Game.ts'), 'utf8');
const serviceWorker = fs.readFileSync(path.join(root, 'public/service-worker.js'), 'utf8');

const roadBiomes = ['neon', 'tropical', 'ice', 'emerald', 'inferno', 'portal', 'desert', 'moonlight', 'cosmic'];

test('high-quality map surface pack contains every biome albedo and normal texture', () => {
  for (const biome of roadBiomes) {
    assert.equal(fs.existsSync(path.join(root, 'public/textures', `road-${biome}.jpg`)), true, `missing road texture: ${biome}`);
    assert.equal(fs.existsSync(path.join(root, 'public/textures', `normal-${biome}.jpg`)), true, `missing normal map: ${biome}`);
    assert.equal(serviceWorker.includes(`'./textures/road-${biome}.jpg'`), true);
    assert.equal(serviceWorker.includes(`'./textures/normal-${biome}.jpg'`), true);
  }
});

test('three-dimensional surfaces use tiled local textures, normal mapping and roughness detail', () => {
  assert.match(builder, /roadMat\.map = loadSurfaceTexture/);
  assert.match(builder, /roadMat\.normalMap = loadSurfaceTexture/);
  assert.match(builder, /roadMat\.roughnessMap = loadSurfaceTexture/);
  assert.match(builder, /TextureLoader\(\)\.load/);
  assert.match(builder, /textures\.forEach\(\(texture\) => texture\.dispose\(\)\)/);
  assert.match(builder, /shadow\.mapSize\.set\(quality === 'high' \? 2048 : 1024/);
});

test('high graphics profile enables soft shadows and higher render resolution on desktop', () => {
  assert.match(game, /toneMappingExposure = 1\.12/);
  assert.match(game, /THREE\.PCFSoftShadowMap/);
  assert.match(game, /deviceCap = this\.mobileRuntime \? 1\.65 : 2\.25/);
  assert.match(game, /\? 'medium' : 'high'/);
});

test('all local texture assets are explicitly included in offline app-shell precache', () => {
  const textureFiles = fs.readdirSync(path.join(root, 'public/textures')).filter((f) => f.endsWith('.jpg'));
  assert.equal(textureFiles.length, 24);
  for (const file of textureFiles) assert.equal(serviceWorker.includes(`'./textures/${file}'`), true, `not precached: ${file}`);
});
