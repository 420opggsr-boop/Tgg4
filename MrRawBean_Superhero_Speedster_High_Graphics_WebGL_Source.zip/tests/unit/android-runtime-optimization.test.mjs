import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const game = fs.readFileSync('src/game/Game.ts', 'utf8');
const cap = fs.readFileSync('capacitor.config.ts', 'utf8');

test('Android runtime uses mobile GPU-safe renderer settings', () => {
  assert.match(game, /antialias: !this\.mobileRuntime/);
  assert.match(game, /preserveDrawingBuffer: false/);
  assert.match(game, /deviceCap = this\.mobileRuntime \? 1\.65 : 2\.25/);
});

test('Android runtime has adaptive render scaling and object caps', () => {
  assert.match(game, /this\.perfFrameMs > 27/);
  assert.match(game, /this\.renderScale = 0\.72/);
  assert.match(game, /hardCap = this\.settings\.quality === 'low'/);
});

test('Capacitor remains configured for offline local web assets', () => {
  assert.match(cap, /webDir: 'dist'/);
  assert.match(cap, /appId: 'com\.mrrawbean\.speedster'/);
});
