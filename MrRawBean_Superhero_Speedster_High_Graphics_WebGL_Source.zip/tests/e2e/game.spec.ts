import { test, expect } from '@playwright/test';

test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => { try { localStorage.clear(); } catch { /* storage may be unavailable before navigation */ } });
  await page.goto('/?test=1');
  await expect(page.getByRole('heading', { name: /MRRAWBEAN/i })).toBeVisible({ timeout: 20_000 });
});

test('home menu exposes all seven working destinations and a start control', async ({ page }) => {
  for (const action of ['maps', 'records', 'shop', 'missions', 'settings', 'name', 'start', 'exit']) {
    await expect(page.locator(`[data-action="${action}"]`).first()).toBeVisible();
  }
  await page.locator('[data-action="maps"]').click();
  await expect(page.getByRole('heading', { name: 'MAP SELECTION' })).toBeVisible();
  await expect(page.locator('[data-map-id]')).toHaveCount(9);
});

test('all map selections load their matching procedural environment', async ({ page }) => {
  await page.locator('[data-action="maps"]').click();
  for (const id of ['MAP_01','MAP_02','MAP_03','MAP_04','MAP_05','MAP_06','MAP_07','MAP_08','MAP_09']) {
    await page.locator(`[data-map-id="${id}"]`).click();
    const result = await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__?.getSceneInfo()?.sceneId);
    expect(result).toBe(id);
  }
});

test('run controls, collision scenarios and pause/restart states are connected', async ({ page }) => {
  await page.locator('[data-action="start"]').click();
  await expect(page.locator('.game-hud')).toBeVisible();
  await page.waitForFunction(() => (window as any).__MRRAWBEAN_TEST__?.getState() === 'running');
  await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.action('left'));
  expect(await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.getStats().lane)).toBe(0);
  await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.action('right'));
  expect(await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.getStats().lane)).toBe(1);
  const lives = await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.getStats().lives);
  await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.collect('grey'));
  expect(await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.getStats().lives)).toBe(lives);
  await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.collect('heart-life'));
  expect(await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.getStats().lives)).toBe(Math.min(5, lives + 1));
  await page.locator('[data-action="pause"]').click();
  await expect(page.getByRole('heading', { name: 'TAKE A BREATHER' })).toBeVisible();
  await page.locator('[data-action="resume"]').click();
  await expect(page.locator('.game-hud')).toBeVisible();
  await page.locator('[data-action="pause"]').click();
  await page.locator('[data-action="restart"]').click();
  await expect(page.locator('.game-hud')).toBeVisible();
});

test('red obstacle collision can end a run, results persist, and retry starts fresh', async ({ page }) => {
  await page.locator('[data-action="start"]').click();
  await page.evaluate(() => { const api = (window as any).__MRRAWBEAN_TEST__; api.setLives(1); api.collect('red-black'); });
  await expect(page.getByRole('heading', { name: /HERO DOWN|GREAT RUN, HERO/i })).toBeVisible();
  const records = await page.evaluate(() => JSON.parse(localStorage.getItem('mrrawbean.speedster.save') || '{}').records || []);
  expect(records.length).toBe(1);
  await page.locator('[data-action="retry"]').click();
  expect(await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.getStats().distance)).toBeLessThan(20);
});

test('name validation, corrupted-save recovery and local reload persistence', async ({ page }) => {
  await page.locator('[data-action="name"]').click();
  await page.locator('#player-name').fill('x');
  await page.locator('#name-form button[type="submit"]').click();
  await expect(page.locator('#name-error')).toContainText('3–16');
  await page.locator('#player-name').fill('Speed Hero');
  await page.locator('#name-form button[type="submit"]').click();
  await expect(page.locator('[data-profile-name]')).toHaveText('Speed Hero');
  await page.reload();
  await expect(page.locator('[data-profile-name]')).toHaveText('Speed Hero');
  await page.evaluate(() => localStorage.setItem('mrrawbean.speedster.save', '{bad json'));
  await page.reload();
  await expect(page.locator('[data-profile-name]')).toHaveText('MrRawBean');
});

test('mobile layout has nine maps and tap controls do not require desktop input', async ({ page, isMobile }) => {
  test.skip(!isMobile, 'Mobile emulation project only.');
  await page.locator('[data-action="maps"]').click();
  await expect(page.locator('[data-map-id]')).toHaveCount(9);
  await page.locator('[data-action="start"]').click();
  await expect(page.locator('.touch-pad button')).toHaveCount(4);
  await page.locator('[data-action="jump"]').tap();
  await page.locator('[data-action="pause"]').tap();
  await expect(page.getByRole('heading', { name: 'TAKE A BREATHER' })).toBeVisible();
});


test('three hearts activate their configured powers and enforce the life cap', async ({ page }) => {
  await page.locator('[data-action="start"]').click();
  await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.collect('heart-flight'));
  await expect.poll(async () => page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.getStats().activePower)).toBe('flight');
  await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.collect('heart-speed'));
  await expect.poll(async () => page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.getStats().speed)).toBeGreaterThan(20);
  await page.evaluate(() => { const api = (window as any).__MRRAWBEAN_TEST__; api.setLives(5); api.collect('heart-life'); });
  expect(await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.getStats().lives)).toBe(5);
});

test('checkpoint crossing announces the 2 km milestone and rescue awards once per civilian', async ({ page }) => {
  await page.locator('[data-action="start"]').click();
  await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.setDistance(1999));
  await expect(page.locator('.game-toast')).toContainText('2000 M CHECKPOINT', { timeout: 5_000 });
  const before = await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.getStats());
  await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.collect('civilian'));
  const after = await page.evaluate(() => (window as any).__MRRAWBEAN_TEST__.getStats());
  expect(after.rescues).toBe(before.rescues + 1);
  expect(after.coins).toBe(before.coins + 15);
  await expect(page.locator('.game-toast')).toContainText(/thank you/i);
});

test('overhead truck collision can end a run with one life remaining', async ({ page }) => {
  await page.locator('[data-action="start"]').click();
  await page.evaluate(() => { const api = (window as any).__MRRAWBEAN_TEST__; api.setLives(1); api.scenario('truck', 1, 2); });
  await page.waitForFunction(() => (window as any).__MRRAWBEAN_TEST__?.getState() === 'gameover', { timeout: 5_000 });
  await expect(page.getByRole('heading', { name: /HERO DOWN/i })).toBeVisible();
});
